#CI 103
#Name: main.py
#purpose: Our complete product of Where's my money the game
#Version: 5.0
#Author: Robert Silver, Mark O'Donnell, Duke Bozikowski
#Date: 5/31/2021
#Dependencies: Photos form directories, Pygame, pymunk

import pygame, sys, pymunk 
from pygame.locals import *
import pygame as pg

# Stack Overflow User Rabbid76
# 12/19/2020
# DropDown
# Source Code
# https://stackoverflow.com/questions/59236523/trying-creating-dropdown-menu-pygame-but-got-stuck
class DropDown():

    def __init__(self, color_menu, color_option, x, y, w, h, font, main, options):
        self.color_menu = color_menu
        self.color_option = color_option
        self.rect = pg.Rect(x, y, w, h)
        self.font = font
        self.main = main
        self.options = options
        self.draw_menu = False
        self.menu_active = False
        self.active_option = -1

    def draw(self, surf):
        pg.draw.rect(surf, self.color_menu[self.menu_active], self.rect, 0)
        msg = self.font.render(self.main, 1, (0, 0, 0))
        surf.blit(msg, msg.get_rect(center = self.rect.center))

        if self.draw_menu:
            for i, text in enumerate(self.options):
                rect = self.rect.copy()
                rect.y += (i+1) * self.rect.height
                pg.draw.rect(surf, self.color_option[1 if i == self.active_option else 0], rect, 0)
                msg = self.font.render(text, 1, (0, 0, 0))
                surf.blit(msg, msg.get_rect(center = rect.center))

    def update(self, event_list):
        mpos = pg.mouse.get_pos()
        self.menu_active = self.rect.collidepoint(mpos)
        
        self.active_option = -1
        for i in range(len(self.options)):
            rect = self.rect.copy()
            rect.y += (i+1) * self.rect.height
            if rect.collidepoint(mpos):
                self.active_option = i
                break

        if not self.menu_active and self.active_option == -1:
            self.draw_menu = False

        for event in event_list:
            if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                if self.menu_active:
                    self.draw_menu = not self.draw_menu
                elif self.draw_menu and self.active_option >= 0:
                    self.draw_menu = False
                    return self.active_option
        return -1

class Level():
    
    def __init__(self, coinsNeeded): # contructor method for the level class
        self.__coinsEarned = 0 #coins earned per level
        self.__coinsNeeded = coinsNeeded #coins needed per level (given at end of program per level in the levels list)
        self.__coinsGiven = 0 # amount of coins given
        self.__multiply = 1 #coin multiplier for the game
        self.__completed = False  #is level completed?
        self.__mover = False #is character able to move?
        self.__flag = 0 #flag variable used in powerup function
    
    def setCoinsEarned(self, coins): #set coins earned
        self.__coinsEarned = coins * self.__multiply #new
    
    def getCoinsEarned(self): #get the value of coins earned
        return self.__coinsEarned 
    
    def setCoinsGiven(self, given): #set coins given 
        self.__coinsGiven = given 
    
    def getCoinsGiven(self): #get coins given value
        return self.__coinsGiven
    
    def getCompleted(self): #get the value of level completion 
        return self.__completed
    
    def setCompleted(self, value): #set the value of level completion
        self.__completed = value
    
    def getCoinsNeeded(self): #get coins needed value
        return self.__coinsNeeded
    
    def isCompleted(self): #check if level is completed
        if (self.__coinsNeeded) == self.__coinsEarned:
            return True
        else:
            return False
    def fullGiven(self): #is the full amount of coins given for that particular level
        if self.__coinsGiven == (self.__coinsNeeded * self.__multiply):
            return True
        else:
            return False
        
    def multiplier(self, shop): #get the multipier from the shop
        self.__multiply = shop.getMulti()
        
    def coins(self): #rewards coins based on completetion of level and multiplier
        if self.__completed != True:
            return self.__coinsNeeded * self.__multiply
        
    def Mover(self): #checks if the user has any character movers in the inventory, if so its true
        if purchases.getUses() >= 1:
            return True
        else:
            return False
        
    def setMover(self, value): #set mover value
        self.__mover = value
        
    def getMover(self): #get mover value
        return self.__mover 
    
    def setFlag(self, value): #set flag value
        self.__flag = value
        
    def getFlag(self): #get flag value
        return self.__flag
    
class Shop():
    
    def __init__(self):
        self.__pos1 = 0 #knight skin
        self.__pos2 = 0 #wizard skin
        self.__pos3 = 0 # basketball skin
        self.__pos4 = 0 # spiderman skin
        self.__bonus = 0 # bonus skin
        self.__multiply = 1 #nin game multiplier 
        self.__uses = 0 #uses of character movers
    
    def setPos1(self, pos1): #set the value  of pos1
        self.__pos1 = pos1
    
    def setPos2(self, pos2): #set the value  of pos2
        self.__pos2 = pos2
    
    def setPos3(self, pos3): #set the value  of pos3
        self.__pos3 = pos3
    
    def setPos4(self, pos4): #set the value  of pos4
        self.__pos4 = pos4
    
    def setBonus(self, bonus): #set the value  of bonus
        self.__bonus = bonus
    
    def getPos1(self): #get the value  of pos1
        return self.__pos1 
    
    def getPos2(self): #get the value  of pos2
        return self.__pos2
    
    def getPos3(self): #get the value  of pos3
        return self.__pos3 
    
    def getPos4(self): #get the value  of pos4
        return self.__pos4
    
    def getBonus(self): #get the value  of pos4
        return self.__bonus
    
    def getMulti(self):#get the multiplier
        return self.__multiply
    
    def shopMulti(self, multiplier): #set the multiplier value
        self.__multiply = multiplier
    
    def characterMover(self): #adds one character mover to inventory
        self.__uses += 1
        
    def getUses(self): #get value uses
        return self.__uses
    
    def setUses(self): #set value of uses
        self.__uses -= 1 
#Main funciton, our home screen
def main(coins, purchases, levels):
    
    #Initializes pygame
    pygame.init()

    # set up the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #Background image
    background = pygame.image.load('menu_background.png')
    #Title image and coordinates
    title = pygame.image.load('title.png')
    titlex = 50
    titley = 0
    #Start button image and coordinates
    startButton = pygame.image.load('startbutton.png')
    startx = 240
    starty = 350
    #Levels button image and coordinates
    levelsButton = pygame.image.load('levels_start.png')
    levelsx = 240
    levelsy = 450
    #Shop button image and coordinates
    shopButton = pygame.image.load('shop.png')
    shopx = 240
    shopy = 550
    #Instructions button image and coordinates
    insbutton = pygame.image.load('instructionsbutton.png')
    insx = 240
    insy = 650
    
    # Display Loop
    while True: 
        #Displaying the buttons on the screen
        DISPLAYSURF.blit(background, (0, 0))
        DISPLAYSURF.blit(startButton, (startx, starty))
        DISPLAYSURF.blit(levelsButton, (levelsx, levelsy))
        DISPLAYSURF.blit(title, (titlex, titley))
        DISPLAYSURF.blit(shopButton, (shopx, shopy))
        DISPLAYSURF.blit(insbutton, (insx, insy))
        

        #While pygame is running
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                mousex, mousey = event.pos
                print(mousex, mousey)
                
                
                #testing if the user clicked the start button
                if 280 <= mousex <= 502 and 440 <= mousey <= 510:
                    
                    #Testing to see what levels have been completed so that when the start button is clicked it takes you to the correct level
                    if levels[7].getCompleted():
                        levelEight(coins, purchases, levels)
                    elif levels[6].getCompleted():
                        levelEight(coins, purchases, levels)
                    elif levels[5].getCompleted():
                        levelSeven(coins, purchases, levels)
                    elif levels[4].getCompleted():
                         levelSix(coins, purchases, levels)
                    elif levels[3].getCompleted():
                        levelFive(coins, purchases, levels)
                    elif levels[2].getCompleted():
                        levelFour(coins, purchases, levels)
                    elif levels[1].getCompleted():
                        levelThree(coins, purchases, levels)
                    elif levels[0].getCompleted():
                        levelTwo(coins, purchases, levels)
                    else:
                        levelOne(coins, purchases, levels)
                
                #Testing to see if the levels button was clicked
                elif 297 <= mousex <= 486 and 549 <= mousey <= 598:
                    levelScreen(coins, purchases, levels)
                
                #Testing to see if the shop button was clicked
                elif 295 <= mousex <= 485 and 648 <= mousey <= 701:
                    shopScreen(coins, purchases, levels)
                
                #Testing to see if the instructions button was clicked
                elif 295 <= mousex <= 485 and 736 <= mousey <= 810:
                    instructions(coins, purchases, levels)
             
            #Updating the display
            pygame.display.update()

#Instructions Screen
def instructions(coins, purchases, levels):
    
    #Initializes pygame
    pygame.init()

    # set up the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #Variables for our button pictures and placements
    background = pygame.image.load('instructions_screen.png')
    while True: 
        #Displaying the background
        DISPLAYSURF.blit(background, (0, 0))
        
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                mousex, mousey = event.pos
                #tests to see if the home button was pressed, if so it calls the main function
                if 308 <= mousex <= 442 and 861 <= mousey <= 980:
                    main(coins, purchases, levels)
        pygame.display.update()

#Level selection screen
def levelScreen(coins, purchases, levels):
    
    #Initializes pygame
    pg.init()
    
    #Display Screen
    screen = pg.display.set_mode((750, 1000))
    
    #Colors for the menu
    COLOR_INACTIVE = (100, 80, 255)
    COLOR_ACTIVE = (100, 200, 255)
    COLOR_LIST_INACTIVE = (100, 200, 255)
    COLOR_LIST_ACTIVE = (255, 150, 150)

    #Depending on what levels have been completed, there are three different possible lists for the drop down menu
    if (levels[7].isCompleted() and levels[8].isCompleted()) or levels[9].isCompleted():
        #Cresting a dropdown object
        list1 = DropDown(
            [COLOR_INACTIVE, COLOR_ACTIVE],
            [COLOR_LIST_INACTIVE, COLOR_LIST_ACTIVE],
            275, 50, 200, 50, 
            pg.font.SysFont(None, 30), 
            "Select Level", ["Level 1", "level 2", "Level 3", "Level 4", "Level 5", "Level 6", "Level 7", "Level 8", "Bonus One", "Bonus Two"])
    elif levels[7].isCompleted() or levels[8].isCompleted():
        #Cresting a dropdown object
        list1 = DropDown(
            [COLOR_INACTIVE, COLOR_ACTIVE],
            [COLOR_LIST_INACTIVE, COLOR_LIST_ACTIVE],
            275, 50, 200, 50, 
            pg.font.SysFont(None, 30), 
            "Select Level", ["Level 1", "level 2", "Level 3", "Level 4", "Level 5", "Level 6", "Level 7", "Level 8", "Bonus One"])
    else:
        #Cresting a dropdown object
        list1 = DropDown(
            [COLOR_INACTIVE, COLOR_ACTIVE],
            [COLOR_LIST_INACTIVE, COLOR_LIST_ACTIVE],
            275, 50, 200, 50, 
            pg.font.SysFont(None, 30), 
            "Select Level", ["Level 1", "level 2", "Level 3", "Level 4", "Level 5", "Level 6", "Level 7", "Level 8"])
    
    #Display Loop
    run = True
    while run:
        #Setting the background image
        background = pygame.image.load("actualbackground.png")

        event_list = pg.event.get()
        for event in event_list:
            if event.type == pg.QUIT:
                run = False
        #Depending on what option is pickedl, that function will be called
        selected_option = list1.update(event_list)
        if selected_option == 0:
            levelOne(coins, purchases, levels)
        
        elif selected_option == 1:
            if levels[0].getCompleted():
                levelTwo(coins, purchases, levels)
        
        elif selected_option == 2:
            if levels[1].getCompleted():
                levelThree(coins, purchases, levels)
        
        elif selected_option == 3:
            if levels[2].getCompleted():
                levelFour(coins, purchases, levels)
        
        elif selected_option == 4:
            if levels[3].getCompleted():
                levelFive(coins, purchases, levels)
                
        elif selected_option == 5:
            if levels[4].getCompleted():
                levelSix(coins, purchases, levels)
                
        elif selected_option == 6:
            if levels[5].getCompleted():
                levelSeven(coins, purchases, levels)
        
        elif selected_option == 7:
#             if levels[6].getCompleted(): 
                bonusTwo(coins, purchases, levels)
        
        if levels[7].getCompleted() or levels[8].getCompleted():
            if selected_option == 8:
                bonusOne(coins, purchases, levels)
        
        if levels[7].getCompleted() and levels[8].getCompleted():
            if selected_option == 9:
                bonusTwo(coins, purchases, levels)
        
        #Displayes the background
        screen.blit(background, (0,0))
        
        #Displays the dropdown object 
        list1.draw(screen)
        pg.display.flip()

def powerUp(coins, purchases, levels, level):
    pygame.init() #initialise pygame

    select = pygame.image.load("select_button.png") #select button image
    
    
    # set up the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #Variables for our button pictures and placements
    background = pygame.image.load('powerup_screen.png')
    while True: #main loop
        if levels[level - 1].getMover() == True: #sets the select button  x and y coords depending on if mover is selected
            selectX = 225
            selectY = 550
        else:
            selectX = 247
            selectY = 645
            
        DISPLAYSURF.blit(background, (0, 0)) #background image
        DISPLAYSURF.blit(select, (selectX, selectY)) #loading select button
        for event in pygame.event.get():
            if event.type == QUIT: #quitting pygame when pressing x
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN: #mouse down is left or right click    
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 64 <= mousex <= 190 and 854 <= mousey <= 965: # main button code
                    main(coins, purchases, levels)
                if 312 <= mousex <= 436 and 854 <= mousey <= 965: #back to shop screen code
                    shopScreen(coins, purchases, levels)
                if 553 <= mousex <= 676 and 854<= mousey <= 965: #chooses level depending on what level the user is about to play next (from level parameter)
                    if level == 1:
                        levelOne(coins, purchases, levels)
                    if level == 2:
                        levelTwo(coins, purchases, levels)
                    if level == 3:
                        levelThree(coins, purchases, levels)
                    if level == 4:
                        levelFour(coins, purchases, levels)
                    if level == 5:
                        levelFive(coins, purchases, levels)
                    if level == 6:
                        levelSix(coins, purchases, levels)
                    if level == 7:
                        levelSeven(coins, purchases, levels)
                    if level == 8:
                        levelEight(coins, purchases, levels)
                    if level == 9:
                        bonusOne(coins, purchases, levels)
                    if level == 10:
                        bonusTwo(coins, purchases, levels)
                if 258 <= mousex <= 507 and 653 <= mousey <= 696:
                    select = pygame.image.load('selected.png')
                    levels[level - 1].setMover(True)
                        
        pygame.display.update()


#Our first level screen
def levelOne(coins, purchases, levels):
    
    if levels[0].Mover() and levels[0].getFlag() == 0: #talk about
        levels[0].setFlag(1) 
        powerUp(coins, purchases, levels, 1) 
    #Creates a new dynamic object body
    def createFallingObject(space, startingPoint, cOrL):
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        body.position = (startingPoint, 50)
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    #Drawa the object
    def drawFallingObject(objects):
        counter = 0
        for ob in objects:
            body, cOrL = ob
            if cOrL == 0:
                screen.blit(lavaImg, body.body.position)

            else:
                screen.blit(coinsImg, body.body.position)

    #Creates a new static object body
    def createRamp(space, positions):
        body = pymunk.Body(body_type = pymunk.Body.STATIC)
        shape = pymunk.Poly(body, positions)
        space.add(body, shape)
        return shape
    
    
    pygame.init()
    
    #Variables
    characterX = 100
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock()
    space  = pymunk.Space()
    space.gravity = (0, 25)
    rightRampImg = pygame.image.load('rampToTheRight.png')
    leftRampImg = pygame.image.load('rampToTheLeft.png')
    lavaImg = pygame.image.load('lava.png')
    coinsImg = pygame.image.load('coin.png')
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelava.png')
    coinsCage = pygame.image.load('cagecoins.png')
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = -150
    retryy = 675
    earned = 0
    
    if purchases.getPos1() == 2:
        character = pygame.image.load('knight.png')
        background = pygame.image.load('medieval_level.png')
    elif purchases.getPos2() == 2:
        character = pygame.image.load('wizard.png')
        background = pygame.image.load('magical_forrest_level.png')
    elif purchases.getPos3() == 2:
        character = pygame.image.load('basketball_playerc.png')
        background = pygame.image.load('basketball_level_background.png')
    elif purchases.getPos4() == 2:
        character = pygame.image.load('spiderman_character.png')
        background = pygame.image.load('spidey_level_background.png')
    elif purchases.getBonus() == 2:
        character = pygame.image.load('donkey_kong_character.png')
        background = pygame.image.load('donkey_kong.png')
    else:
        character = pygame.image.load('character.png')
        background = pygame.image.load('level_1_with_lava.png')
        
    dropped = False
    objects = []
    
    positionsRamp1Right = [(25, 250), (25, 250), (143, 338), (143, 338)]
    positionsRamp1Left = [(8, 336), (8, 336), (125, 250), (125, 250)]
    positionsRamp2Left = [(609, 337), (609, 337), (724, 249), (724, 249)]
    positionsRamp2Right = [(626, 249), (626, 249), (744, 336), (744, 366)]
    positionsRamp3Right = [(223, 500), (223, 500), (344, 588), (344, 588)]
    positionsRamp3Left = [(209, 583), (209, 583), (325, 498), (325, 498)]
    positionsRamp4Left = [(411, 584), (411, 584), (525, 499), (525, 499)]
    positionsRamp4Right = [(424, 500), (424, 500), (541, 587), (541, 587)]

    ramps = [createRamp(space, positionsRamp1Right), createRamp(space, positionsRamp2Left), createRamp(space, positionsRamp3Right), createRamp(space, positionsRamp4Left)]
    rOrL = [0, 1, 0, 1]
   

    counter = 6000 
    font = pygame.font.SysFont('Consolas', 50)

    #Display Loop
    cmove = 0
    while True:
        if counter > 0:
            counter -= 1    
        elif counter == 0 and dropped == False:
            dropped = True
            objects.append(createFallingObject(space, 50, 1))
            objects.append(createFallingObject(space, 650, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 50, 1))
                        objects.append(createFallingObject(space, 650, 0))
                        dropped = True
                if 4 <= mousex <= 146 and 251 <= mousey <= 350:
                    if rOrL[0] ==  0:
                        rOrL[0] = 1
                        space.remove(ramps[0])
                        ramps[0] = (createRamp(space, positionsRamp1Left))
                        
                    else:
                        rOrL[0] = 0
                        space.remove(ramps[0])
                        ramps[0] = (createRamp(space, positionsRamp1Right))
                        
                if 604 <= mousex <= 743 and 243 <= mousey <= 347:
                
                    if rOrL[1] == 0:
                        rOrL[1] = 1
                        space.remove(ramps[1])
                        ramps[1] = (createRamp(space, positionsRamp2Left))
                        
                    else:
                        rOrL[1] = 0
                        space.remove(ramps[1])
                        ramps[1] = (createRamp(space, positionsRamp2Right))
                        
                if 214 <= mousex <= 342 and 500 <= mousey <= 593:
                    if rOrL[2] == 0:
                        rOrL[2] = 1
                        space.remove(ramps[2])
                        ramps[2] = (createRamp(space, positionsRamp3Left))
                        
                    else:
                        rOrL[2] = 0
                        space.remove(ramps[2])
                        ramps[2] = (createRamp(space, positionsRamp3Right))
                        
                     
                if 403 <= mousex <= 544 and 503 <= mousey <= 593:
 
                    if rOrL[3] == 0:
                        rOrL[3] = 1
                        space.remove(ramps[3])
                        ramps[3] = (createRamp(space, positionsRamp4Left))
                        
                    else:
                        rOrL[3] = 0
                        space.remove(ramps[3])
                        ramps[3] = (createRamp(space, positionsRamp4Right))
                
                if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                    levelOne(coins, purchases, levels)
                    
                    
            elif event.type == KEYDOWN:
                mouse = pygame.mouse.get_pos()
                if (event.key == K_LEFT):
                    if (49 + cmove) <= mouse[0] <= (215 + cmove) and 659 <= mouse[1] <= 783:
                        if levels[0].getMover():
                            if characterX >= 0:
                                characterX -= 10 
                                cmove -= 10
        
                if (event.key == K_RIGHT):
                    if (91 + cmove) <= mouse[0] <= (210 + cmove) and 663 <= mouse[1] <= 798:
                        if levels[0].getMover():
                            if characterX <= 650:
                                characterX += 10 
                                cmove += 10      
        
        screen.blit(background, (0, 0))
        screen.blit(retryLevelButton, (retryx, retryy))
        
        #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left
        
        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(coinsCage, (50, 0))
            screen.blit(lavaCage, (450, 0))
            
        location = 0
        #talk about poping coins on multi coin levels and the deleting of coins and lava on x/y borders
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position
            if (49 + cmove) <= bodyx <= (215 + cmove) and 659 <= bodyy <= 783:
                if cOrL == 1:
                    earned += 1
                    levels[0].setCoinsEarned(1)
                    objects.pop(location)
                    if earned == 1:
                        if counter >= 4500:
                            endLevel(3, coins, 1, purchases, levels)
                        elif counter >= 3000:
                            endLevel(2, coins, 1, purchases, levels)
                        elif counter >= 1500:
                            endLevel(1, coins, 1, purchases, levels)
                        elif bodyy >= 750 or counter == 0:
                            endLevel(0, coins, 1, purchases, levels)
                else:
                    endLevel(0, coins, 1, purchases, levels)
            elif bodyy > 1000:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 1, purchases, levels)
            elif bodyx > 730 or bodyx < 20:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 1, purchases, levels)
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 1, purchases, levels)
            location += 1

        
        #Depending on the value in rOrL, the ramp is placed at different heights
        if rOrL[0] == 0:
            screen.blit(rightRampImg, (0, 250))
        else:
            screen.blit(leftRampImg, (0, 250))
        if rOrL[1] == 0:
            screen.blit(rightRampImg, (600, 250))
        else:
            screen.blit(leftRampImg, (600, 250))
        if rOrL[2] == 0:
            screen.blit(rightRampImg, (200, 500))
        else:
            screen.blit(leftRampImg, (200, 500))
        if rOrL[3] == 0:
            screen.blit(rightRampImg, (400, 500))
        else:
            screen.blit(leftRampImg, (400, 500))
    
        screen.blit(dropLever, (330, 85))
        screen.blit(character, (characterX, 650))
    
        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)                  

#End of the level screen

def levelTwo(coins, purchases, levels):
    if levels[1].Mover() and levels[1].getFlag() == 0:
        levels[1].setFlag(1) 
        powerUp(coins, purchases, levels, 2) 
    #Creates a new dynamic object body
    def createFallingObject(space, startingPoint, cOrL):
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        body.position = (startingPoint, 50)
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    #Drawa the object
    def drawFallingObject(objects):
        for ob in objects:
            body, cOrL = ob
            if cOrL == 0:
                screen.blit(lavaImg, body.body.position)
            else:
                screen.blit(coinsImg, body.body.position)

    #Creates a new static object body
    def createRamp(space, positions):
        body = pymunk.Body(body_type = pymunk.Body.STATIC)
        shape = pymunk.Poly(body, positions)
        space.add(body, shape)
        return shape


    pygame.init()

    #Variables
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock()
    space = pymunk.Space()
    space.gravity = (0, 25)
    rightRampImg = pygame.image.load('smallRampToTheRight.png')
    leftRampImg = pygame.image.load('smallRampToTheLeft.png')
    specialRampImg = pygame.image.load('move_ramp_triangle.png')
    specialRampx = 230
    specialRampy = 225
    earned = 0
    lavaImg = pygame.image.load('lava.png')
    coinsImg = pygame.image.load('coin.png')
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelava.png')
    coinsCage = pygame.image.load('cagecoins.png')
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = -150
    retryy = 675
    dropped = False
    objects = []
    
    if purchases.getPos1() == 2:
        character = pygame.image.load('knight.png')
        background = pygame.image.load('medieval_level.png')
    elif purchases.getPos2() == 2:
        character = pygame.image.load('wizard.png')
        background = pygame.image.load('magical_forrest_level.png')
    elif purchases.getPos3() == 2:
        character = pygame.image.load('basketball_playerc.png')
        background = pygame.image.load('basketball_level_background.png')
    elif purchases.getPos4() == 2:
        character = pygame.image.load('spiderman_character.png')
        background = pygame.image.load('spidey_level_background.png')
    else:
        character = pygame.image.load('character2.png')
        background = pygame.image.load('level_2.png')
    

    ramp1PositionsRight = [(67, 196), (67, 196), (150, 258), (150, 258)]
    ramp1PositionsLeft = [(50, 258), (50, 258), (137, 193), (137, 193)]
    
    ramp2PositionsRight = [(612, 192), (612, 192), (704, 260), (704, 260)]
    ramp2PositionsLeft = [(602, 258), (602, 258), (683, 194), (683, 194)]
    
    ramp3PositionsRight = [(120, 392), (120, 392), (201, 459), (201, 459)]
    ramp3PositionsLeft = [(98, 458), (95, 458), (186, 395), (186, 395)]
    
    ramp4PositionsRight = [(567, 392), (567, 392), (657, 458), (657, 458)]
    ramp4PositionsLeft = [(549, 456), (549, 456), (634, 396), (634, 396)]
    
    ramp5PositionsRight = [(216, 593), (216, 593), (301, 659), (301, 659)]
    ramp5PositionsLeft = [(203, 657), (203, 657), (280, 594), (280, 594)]
    
    ramp6PositionsRight = [(469, 591), (469, 591), (556, 661), (556, 661)]
    ramp6PositionsLeft = [(451, 659), (451, 659), (531, 597), (531, 597)]
 
    specialRampLeft = [(230, 405), (230, 405), (380, 270), (380, 270)]
    specialRampRight = [(380, 270), (380, 270), (513, 408), (513, 408)]

    specialRamps = [createRamp(space, specialRampLeft), createRamp(space, specialRampRight)]
    rOrL = [0, 1, 0, 1, 0, 1]
    ramps = [createRamp(space, ramp1PositionsRight), createRamp(space, ramp2PositionsLeft), createRamp(space, ramp3PositionsRight), createRamp(space, ramp4PositionsLeft), createRamp(space, ramp5PositionsRight), createRamp(space, ramp6PositionsLeft)]

    counter = 6000 
    font = pygame.font.SysFont('Consolas', 50)
    cmove = 0
    characterX = 350
    specialSelected = False
    characterSelected = False
    #Display Loop
    while True:
        if dropped == False:
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 75, 1))
                objects.append(createFallingObject(space, 625, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                if 336 <= mousex <= 431 and 88 <= mousey <= 159:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 75, 1))
                        objects.append(createFallingObject(space, 625, 0))
                        dropped = True
                
                if 47 <= mousex <= 150 and 201 <= mousey <= 269:
                    if rOrL[0] == 0:
                        rOrL[0] = 1
                        space.remove(ramps[0])
                        ramps[0] = createRamp(space, ramp1PositionsLeft)
                        
                    else:
                        rOrL[0] = 0
                        space.remove(ramps[0])
                        ramps[0] = createRamp(space, ramp1PositionsRight)
                        
                if 597 <= mousex <= 700 and 199 <= mousey <= 270:
                    if rOrL[1] == 0:
                        rOrL[1] = 1
                        space.remove(ramps[1])
                        ramps[1] = createRamp(space, ramp2PositionsLeft)
                        
                    else:
                        rOrL[1] = 0
                        space.remove(ramps[1])
                        ramps[1] = createRamp(space, ramp2PositionsRight)
                if 103 <= mousex <= 200 and 400 <= mousey <= 469:
                    if rOrL[2] == 0:
                        rOrL[2] = 1
                        space.remove(ramps[2])
                        ramps[2] = createRamp(space, ramp3PositionsLeft)
                        
                    else:
                        rOrL[2] = 0
                        space.remove(ramps[2])
                        ramps[2] = createRamp(space, ramp3PositionsRight)
                if 551 <= mousex <= 649 and 400 <= mousey <= 471:
                    if rOrL[3] == 0:
                        rOrL[3] = 1
                        space.remove(ramps[3])
                        ramps[3] = createRamp(space, ramp4PositionsLeft)
                        
                    else:
                        rOrL[3] = 0
                        space.remove(ramps[3])
                        ramps[3] = createRamp(space, ramp4PositionsRight)
                if 202 <= mousex <= 298 and 601 <= mousey <= 667:
                    if rOrL[4] == 0:
                        rOrL[4] = 1
                        space.remove(ramps[4])
                        ramps[4] = createRamp(space, ramp5PositionsLeft)
                        
                    else:
                        rOrL[4] = 0
                        space.remove(ramps[4])
                        ramps[4] = createRamp(space, ramp5PositionsRight)
                if 454 <= mousex <= 551 and 597 <= mousey <= 669:
                    if rOrL[5] == 0:
                        rOrL[5] = 1
                        space.remove(ramps[5])
                        ramps[5] = createRamp(space, ramp6PositionsLeft)
                   
                    else:
                        rOrL[5] = 0
                        space.remove(ramps[5])
                        ramps[5] = createRamp(space, ramp6PositionsRight)
                
                if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                    levelTwo(coins, purchases, levels)
                    
                if specialRampx <= mousex <= specialRampx+300 and specialRampy <= mousey <= specialRampy+200:
                    specialSelected = True
                    characterSelected = False
                if characterX <= mousex <= characterX+100 and 700 <= mousey <= 800 and levels[1].getMover():
                     specialSelected = False
                     characterSelected = True 
                        
            elif event.type == KEYDOWN:
                if (event.key == K_LEFT):
                    if characterSelected:
                        if characterX >= 0:
                            characterX -= 10 
                            cmove -= 10
                    else:
                        if specialRampx >= 0:
                            space.remove(specialRamps[0])
                            
                            for i in range(0,4):
                                x, y = specialRampLeft[i]
                                x -= 10
                                specialRampLeft[i] = (x,y)
                            
                            specialRamps[0] = createRamp(space, specialRampLeft)
                            space.remove(specialRamps[1])
                            
                            for i in range(0,4):
                                x, y = specialRampRight[i]
                                x -= 10
                                specialRampRight[i] = (x,y)
                            
                            specialRamps[1] = createRamp(space, specialRampRight)
                            specialRampx -= 8
                    
                elif (event.key == K_RIGHT):
                    if characterSelected:
                        if characterX >= 0:
                            characterX += 10 
                            cmove += 10
                    else:
                        if specialRampx <= 650:
                        
                            space.remove(specialRamps[0])
                            
                            for i in range(0,4):
                                x, y = specialRampLeft[i]
                                x += 10
                                specialRampLeft[i] = (x,y)
                            
                            specialRamps[0] = createRamp(space, specialRampLeft)
                            space.remove(specialRamps[1])
                            
                            for i in range(0,4):
                                x, y = specialRampRight[i]
                                x += 10
                                specialRampRight[i] = (x,y)
                            
                            specialRamps[1] = createRamp(space, specialRampRight)
                            specialRampx += 8
                         
        screen.blit(background, (0, 0))
                         
        screen.blit(background, (0, 0))
        screen.blit(retryLevelButton, (retryx, retryy))

        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(coinsCage, (0, 0))
            screen.blit(lavaCage, (500, 0))
        
        #Depending on the value in rOrL, the ramp is placed at different heights
        if rOrL[0] == 0:
            screen.blit(rightRampImg, (50, 200))
        else:
            screen.blit(leftRampImg, (50, 200))
        
        if rOrL[1] == 0:
            screen.blit(rightRampImg, (600, 200))
        else:
            screen.blit(leftRampImg, (600, 200))
        
        if rOrL[2] == 0:
            screen.blit(rightRampImg, (100, 400))
        else:
            screen.blit(leftRampImg, (100, 400))
        
        if rOrL[3] == 0:
            screen.blit(rightRampImg, (550, 400))
        else:
            screen.blit(leftRampImg, (550, 400))
        
        if rOrL[4] == 0:
            screen.blit(rightRampImg, (200, 600))
        else:
            screen.blit(leftRampImg, (200, 600))
        
        if rOrL[5] == 0:
            screen.blit(rightRampImg, (450, 600))
        else:
            screen.blit(leftRampImg, (450, 600))
            

        screen.blit(dropLever, (335, 85))
        screen.blit(character, (characterX, 700))
        screen.blit(specialRampImg, (specialRampx, specialRampy))
        

        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (305, 25))
        
        location = 0
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position
            if 340 <= bodyx <= 410 and 700 <= bodyy <= 780:
                if cOrL == 1:
                    earned += 1
                    levels[1].setCoinsEarned(1)
                    objects.pop(location)
                    if earned == 1:
                        if counter >= 4500:
                            endLevel(3, coins, 2, purchases, levels)
                        elif counter >= 3000:
                            endLevel(2, coins, 2, purchases, levels)
                        elif counter >= 1500:
                            endLevel(1, coins, 2, purchases, levels)
                        elif bodyy >= 750 or counter == 0:
                            endLevel(0, coins, 2, purchases, levels)
                else:
                    endLevel(0, coins, 2, purchases, levels)
            elif bodyy > 1000:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 2, purchases, levels)
            elif bodyx > 730 or bodyx < 20:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 2, purchases, levels)
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 2, purchases, levels)
            location += 1
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)                                   


def levelThree(coins, purchases, levels):
    
    if levels[2].Mover() and levels[2].getFlag() == 0:
        levels[2].setFlag(1) 
        powerUp(coins, purchases, levels, 3)
    def createRamp(space, positions):
        body = pymunk.Body(body_type = pymunk.Body.STATIC)
        shape = pymunk.Poly(body, positions)
        space.add(body, shape)
        return shape      

    def createFallingObject(space, startingPoint, cOrL):
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        body.position = (startingPoint, 50)
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    def drawFallingObject(objects):
        for ob in objects:
            body, cOrL = ob
            if cOrL == 0:
                screen.blit(lavaImg, body.body.position)
            else:
                screen.blit(coinImg, body.body.position)

    pygame.init()
        
    #Variables
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock()
    space  = pymunk.Space()
    space.gravity = (0, 25)
    ramp0 = pygame.image.load('ramprotate0degrees.png')
    ramp30 = pygame.image.load('ramprotate30degrees.png')
    ramp60 = pygame.image.load('ramprotate60degrees.png')
    ramp90 = pygame.image.load('ramprotate90degrees.png')
    ramp120 = pygame.image.load('ramprotate120degrees.png')
    ramp150 = pygame.image.load('ramprotate150degrees.png')
    moveableRampRight = pygame.image.load('ramp2.0mover.png')
    moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
    rampRight = pygame.image.load('smallRampToTheRight.png')
    rampLeft = pygame.image.load('smallRampToTheLeft.png')
    rotatedramp = ramp0
    rotatedrampBackwards = ramp0
    lavaImg = pygame.image.load('lava.png')
    coinImg = pygame.image.load('coin.png')
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelavaSmall.png')
    coinsCage = pygame.image.load('cagecoinsSmall.png')
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = -150
    retryy = 675
    earned = 0
    
    if purchases.getPos1() == 2:
        character = pygame.image.load('knight.png')
        background = pygame.image.load('medieval_level.png')
    elif purchases.getPos2() == 2:
        character = pygame.image.load('wizard.png')
        background = pygame.image.load('magical_forrest_level.png')
    elif purchases.getPos3() == 2:
        character = pygame.image.load('basketball_playerc.png')
        background = pygame.image.load('basketball_level_background.png')
    elif purchases.getPos4() == 2:
        character = pygame.image.load('spiderman_character.png')
        background = pygame.image.load('spidey_level_background.png')
    elif purchases.getBonus() == 2:
        character = pygame.image.load('donkey_kong_character.png')
        background = pygame.image.load('donkey_kong.png')
    else:
        character = pygame.image.load('character2.png')
        background = pygame.image.load('level_3.png')
        
    dropped = False
    objects = []
    
    moveableRampRightx = 150
    moveableRampRighty = 550
    moveableRampLeftx = 500
    moveableRampLefty = 550

    positionsRamp1Right = [(97, 198), (97, 198), (171, 255), (171, 255)]
    positionsRamp1Left = [(81, 254), (81, 254), (157, 195), (157, 195)]
    positionsRamp2Right = [(247, 198), (247, 198), (320, 256), (320, 256)]
    positionsRamp2Left = [(228, 253), (228, 253), (306, 193), (306, 193)]
    positionsRamp3Right = [(446, 199), (446, 199), (524, 257), (524, 257)]
    positionsRamp3Left = [(425, 257), (425, 257), (505, 197), (505, 197)]
    positionsRamp4Right = [(595, 199), (595, 199), (671, 255), (671, 255)]
    positionsRamp4Left = [(579, 257), (579, 257), (655, 196), (655, 196)]
    
    posititionsRampMoverRight = [(176, 546), (176, 546), (254, 605), (254, 605)]
    posititionsRampMoverLeft = [(501, 606), (501, 606), (583, 546), (583, 546)]
    
    positionsSpinningRampOne0 = [(207, 413), (207, 413), (300, 413), (300, 413)]
    positionsSpinningRampOne30 = [(220, 390), (220, 390), (300, 437), (300, 437)]
    positionsSpinningRampOne60 = [(240, 380), (240, 380), (286, 462), (286, 462)]
    positionsSpinningRampOne90 = [(241, 374), (241, 374), (261, 379), (261, 379)]
    positionsSpinningRampOne120 = [(219, 458), (219, 458), (264, 379), (264, 379)]
    positionsSpinningRampOne150 = [(207, 437), (207, 437), (287, 391), (287, 391)]
    positionsSpinningRampTwo0 = [(456, 413), (456, 413), (551, 413), (551, 413)]
    positionsSpinningRampTwo30 = [(458, 435), (458, 435), (537, 390), (537, 390)]
    positionsSpinningRampTwo60 = [(513, 378), (513, 378), (468, 457), (468, 457)]
    positionsSpinningRampTwo90 = [(491, 375), (491, 375), (510, 378), (510, 378)]
    positionsSpinningRampTwo120 = [(487, 382), (487, 382), (534, 461), (534, 461)]
    positionsSpinningRampTwo150 = [(467, 394), (467, 394), (550, 441), (550, 441)]


    clickables = [createRamp(space, positionsRamp1Right), createRamp(space, positionsRamp2Left), createRamp(space, positionsRamp3Right), createRamp(space, positionsRamp4Left)]
    moveables = [createRamp(space, posititionsRampMoverRight), createRamp(space, posititionsRampMoverLeft)]
    spinners = [createRamp(space, positionsSpinningRampOne30), createRamp(space, positionsSpinningRampTwo30)]
    rOrL = [0, 1, 0, 1]
    rotateNum = 0
    rightSelected = False
    leftSelected = False

    counter = 6000 
    font = pygame.font.SysFont('Consolas', 50)

    #Display Loop
    cmove = 0
    characterX = 350
    while True:
        rotateNum += 1
        if dropped == False:
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 100, 0))
                objects.append(createFallingObject(space, 600, 0))
                objects.append(createFallingObject(space, 250, 1))
                objects.append(createFallingObject(space, 450, 1))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 100, 0))
                        objects.append(createFallingObject(space, 600, 0))
                        objects.append(createFallingObject(space, 250, 1))
                        objects.append(createFallingObject(space, 450, 1))
                        dropped = True
                if 74 <= mousex <= 171 and 205 <= mousey <= 270:
                    if rOrL[0] ==  0:
                        rOrL[0] = 1
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Left))
                    
                    else:
                        rOrL[0] = 0
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Right))
                        
                if 232 <= mousex <= 328 and 203 <= mousey <= 267:
                    if rOrL[1] ==  0:
                        rOrL[1] = 1
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Left))
                    
                    else:
                        rOrL[1] = 0
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Right))
                if 423 <= mousex <= 517 and 208 <= mousey <= 267:
                    if rOrL[2] ==  0:
                        rOrL[2] = 1
                        space.remove(clickables[2])
                        clickables[2] = (createRamp(space, positionsRamp3Left))
                    
                    else:
                        rOrL[2] = 0
                        space.remove(clickables[2])
                        clickables[2] = (createRamp(space, positionsRamp3Right))
                if 578 <= mousex <= 678 and 207 <= mousey <= 265:
                    if rOrL[3] ==  0:
                        rOrL[3] = 1
                        space.remove(clickables[3])
                        clickables[3] = (createRamp(space, positionsRamp4Left))
                    
                    else:
                        rOrL[3] = 0
                        space.remove(clickables[3])
                        clickables[3] = (createRamp(space, positionsRamp4Right))
                
                if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                    levelThree(coins, purchases, levels)
                    
                if moveableRampRightx <= mousex <= moveableRampRightx+100 and moveableRampRighty <= mousey <= moveableRampRighty+100:
                    rightSelected = True
                    leftSelected = False
                if moveableRampLeftx <= mousex <= moveableRampLeftx+100 and moveableRampLefty <= mousey <= moveableRampLefty+100:
                     leftSelected = True
                     rightSelected = False

            elif event.type == KEYDOWN:
                if (event.key == K_LEFT):
                     mouse = pygame.mouse.get_pos()
                     if 344 + cmove <= mouse[0] <= 404 + cmove and 655 <= mouse[1] <= 722:
                         if levels[2].getMover():
                             if characterX >= 0:
                                  characterX -= 10 
                                  cmove -= 10
                     
                     
                     if rightSelected:
                         space.remove(moveables[0])
                         for i in range(0,4):
                             x, y = posititionsRampMoverRight[i]
                             x -= 10
                             posititionsRampMoverRight[i] = (x,y)
                         moveables[0] = createRamp(space, posititionsRampMoverRight)
                         moveableRampRightx -= 8
                     if leftSelected:
                         space.remove(moveables[1])
                         for i in range(0,4):
                             x, y = posititionsRampMoverLeft[i]
                             x -= 10
                             posititionsRampMoverLeft[i] = (x,y)
                         moveables[1] = createRamp(space, posititionsRampMoverLeft)
                         moveableRampLeftx -= 8
                     
                elif (event.key == K_RIGHT):
                    mouse = pygame.mouse.get_pos()
                    if 344 + cmove <= mouse[0] <= 404 + cmove and 655 <= mouse[1] <= 722:
                        if levels[2].getMover():
                            if characterX <= 650:
                                characterX += 10 
                                cmove += 10
                     
                    if rightSelected:
                        space.remove(moveables[0])
                        for i in range(0,4):
                            x, y = posititionsRampMoverRight[i]
                            x += 10
                            posititionsRampMoverRight[i] = (x,y)
                        moveables[0] = createRamp(space, posititionsRampMoverRight)
                        moveableRampRightx += 8
                    if leftSelected:
                         space.remove(moveables[1])
                         for i in range(0,4):
                             x, y = posititionsRampMoverLeft[i]
                             x += 10
                             posititionsRampMoverLeft[i] = (x,y)
                         moveables[1] = createRamp(space, posititionsRampMoverLeft)
                         moveableRampLeftx += 8
        
        screen.blit(background, (0, 0))
        screen.blit(retryLevelButton, (retryx, retryy))
        
        #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position

        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(lavaCage, (50, 0))
            screen.blit(coinsCage, (200, 0))
            screen.blit(lavaCage, (550, 0))
            screen.blit(coinsCage, (400, 0))
        
        #Depending on the value in rOrL, the ramp is placed at different heights
        
        if rotateNum == 0 :
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp0
            rotatedrampBackwards = ramp0
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
        elif rotateNum == 3:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp30
            rotatedrampBackwards = ramp150
            spinners[0] = createRamp(space, positionsSpinningRampOne30)
            spinners[1] = createRamp(space, positionsSpinningRampTwo150)
        elif rotateNum == 6:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp60
            rotatedrampBackwards = ramp120
            spinners[0] = createRamp(space, positionsSpinningRampOne60)
            spinners[1] = createRamp(space, positionsSpinningRampTwo120)
        elif rotateNum == 9:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp90
            rotatedrampBackwards = ramp90
            spinners[0] = createRamp(space, positionsSpinningRampOne90)
            spinners[1] = createRamp(space, positionsSpinningRampTwo90)
        elif rotateNum == 12:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp120
            rotatedrampBackwards = ramp60
            spinners[0] = createRamp(space, positionsSpinningRampOne120)
            spinners[1] = createRamp(space, positionsSpinningRampTwo60)
        elif rotateNum == 15:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp150
            rotatedrampBackwards = ramp30
            spinners[0] = createRamp(space, positionsSpinningRampOne150)
            spinners[1] = createRamp(space, positionsSpinningRampTwo30)
        elif rotateNum == 18:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp0
            rotatedrampBackwards = ramp0
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            rotateNum = 0
        
        if rOrL[0] == 0:
            screen.blit(rampRight, (75, 200))
        else:
            screen.blit(rampLeft, (75, 200))
        
        if rOrL[1] == 0:
            screen.blit(rampRight, (225, 200))
        else:
            screen.blit(rampLeft, (225, 200))
        
        if rOrL[2] == 0:
            screen.blit(rampRight, (425, 200))
        else:
            screen.blit(rampLeft, (425, 200))
        
        if rOrL[3] == 0:
            screen.blit(rampRight, (575, 200))
        else:
            screen.blit(rampLeft, (575, 200))
        
        screen.blit(moveableRampRight, (moveableRampRightx, moveableRampRighty))
        screen.blit(moveableRampLeft, (moveableRampLeftx, moveableRampLefty))
        screen.blit(rotatedramp, (150, 350))
        screen.blit(rotatedrampBackwards, (400, 350))


        screen.blit(dropLever, (330, 85))
        screen.blit(character, (characterX, 650))
        
        location = 0
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position
            if 340 <= bodyx <= 420 and 650 <= bodyy <= 730:
                if cOrL == 1:
                    earned += 1
                    if levels[2].getCoinsEarned() < 2:
                        levels[2].setCoinsEarned(levels[2].getCoinsEarned()+1)
                    objects.pop(location)
                    if earned == 2:
                        if counter >= 4500:
                            endLevel(3, coins, 3, purchases, levels)
                        elif counter >= 3000:
                            endLevel(2, coins, 3, purchases, levels)
                        elif counter >= 1500:
                            endLevel(1, coins, 3, purchases, levels)
                        elif bodyy >= 750 or counter == 0:
                            endLevel(0, coins, 3, purchases, levels)
                else:
                    endLevel(0, coins, 3, purchases, levels)
            elif bodyy > 1000:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 3, purchases, levels)
            elif bodyx > 730 or bodyx < 20:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 3, purchases, levels)
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 3, purchases, levels)
            location += 1

        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)

def levelFour(coins, purchases, levels):
    
    if levels[3].Mover() and levels[3].getFlag() == 0:
        levels[3].setFlag(1) 
        powerUp(coins, purchases, levels, 4)
        
    def createRamp(space, positions):
            body = pymunk.Body(body_type = pymunk.Body.STATIC)
            shape = pymunk.Poly(body, positions)
            space.add(body, shape)
            return shape      

    def createFallingObject(space, startingPoint, cOrL):
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        body.position = (startingPoint, 50)
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    def drawFallingObject(objects):
        for ob in objects:
            body, cOrL = ob
            if cOrL == 0:
                screen.blit(lavaImg, body.body.position)
            else:
                screen.blit(coinImg, body.body.position)

    pygame.init()
        
    #Variables
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock()
    space  = pymunk.Space()
    space.gravity = (0, 25)
    ramp0 = pygame.image.load('ramprotate0degrees.png')
    ramp30 = pygame.image.load('ramprotate30degrees.png')
    ramp60 = pygame.image.load('ramprotate60degrees.png')
    ramp90 = pygame.image.load('ramprotate90degrees.png')
    ramp120 = pygame.image.load('ramprotate120degrees.png')
    ramp150 = pygame.image.load('ramprotate150degrees.png')
    moveableRampRight = pygame.image.load('ramp2.0mover.png')
    moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
    rampRight = pygame.image.load('smallRampToTheRight.png')
    rampLeft = pygame.image.load('smallRampToTheLeft.png')
    specialRampImg = pygame.image.load('double_triangle.png')
    rotatedramp = ramp0
    rotatedrampBackwards = ramp0
    lavaImg = pygame.image.load('lava.png')
    coinImg = pygame.image.load('coin.png')
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelavaSmall.png')
    coinsCage = pygame.image.load('cagecoinsSmall.png')
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = -150
    retryy = 675
    earned = 0
    if purchases.getPos1() == 2:
        character = pygame.image.load('knight.png')
        background = pygame.image.load('medieval_level.png')
    elif purchases.getPos2() == 2:
        character = pygame.image.load('wizard.png')
        background = pygame.image.load('magical_forrest_level.png')
    elif purchases.getPos3() == 2:
        character = pygame.image.load('basketball_playerc.png')
        background = pygame.image.load('basketball_level_background.png')
    elif purchases.getPos4() == 2:
        character = pygame.image.load('spiderman_character.png')
        background = pygame.image.load('spidey_level_background.png')
    elif purchases.getBonus() == 2:
        character = pygame.image.load('donkey_kong_character.png')
        background = pygame.image.load('donkey_kong.png')
    else:
        character = pygame.image.load('character2.png')
        background = pygame.image.load('level_4.png')
        
    dropped = False
    objects = []

    moveableRampRightx = 150
    moveableRampRighty = 550
    moveableRampLeftx = 500
    moveableRampLefty = 550

    specialRampx = 220
    specialRampy = 200

    positionsRamp1Right = [(220, 421), (220, 421), (297, 484), (297, 484)]
    positionsRamp1Left = [(204, 481), (204, 481), (281, 422), (281, 422)]
    
    positionsRamp2Right = [(470, 424), (470, 424), (549, 483), (549, 483)]
    positionsRamp2Left = [(453, 481), (453, 481), (532, 422), (532, 422)]
    
    posititionsRampMoverRight = [(177, 548), (177, 548), (254, 608), (254, 608)]
    posititionsRampMoverLeft = [(502, 607), (502, 607), (586, 547), (586, 547)]

    positionsSpinningRampOne0 = [(131, 337), (131, 337), (225, 337), (225, 337)]
    positionsSpinningRampOne30 = [(143, 317), (143, 317), (227, 365), (227, 365)]
    positionsSpinningRampOne60 = [(166, 308), (166, 308), (213, 388), (213, 388)]
    positionsSpinningRampOne90 = [(169, 298), (169, 298), (186, 304), (186, 304)]
    positionsSpinningRampOne120 = [(141, 384), (141, 384), (188, 300), (188, 300)]
    positionsSpinningRampOne150 = [(130, 358), (130, 358), (213, 314), (213, 314)]
    positionsSpinningRampTwo0 = [(529, 337), (529, 337), (626, 337), (626, 337)]
    positionsSpinningRampTwo30 = [(528, 362), (528, 362), (612, 313), (612, 313)]
    positionsSpinningRampTwo60 = [(540, 383), (540, 383), (588, 302), (588, 302)]
    positionsSpinningRampTwo90 = [(566, 297), (566, 297), (586, 305), (586, 305)]
    positionsSpinningRampTwo120 = [(561, 305), (561, 305), (612, 388), (612, 388)]
    positionsSpinningRampTwo150 = [(544, 316), (544, 316), (627, 364), (627, 364)]

    specialRampLeft = [(221, 286), (221, 286), (305, 195), (305, 195)] #-------------------------------------------------------
    specialRampMiddleLeft = [(305, 195), (305, 195), (380, 281), (380, 281)] #-------------------------------------------------------
    specialRampMiddleRight = [(380, 281), (380, 281), (457, 197), (457, 197)]#-------------------------------------------------------
    specialRampRight = [(457, 197), (457, 197), (536, 286), (536, 286)]#-------------------------------------------------------

    clickables = [createRamp(space, positionsRamp1Right), createRamp(space, positionsRamp2Left)]
    moveables = [createRamp(space, posititionsRampMoverRight), createRamp(space, posititionsRampMoverLeft)]
    spinners = [createRamp(space, positionsSpinningRampOne30), createRamp(space, positionsSpinningRampTwo30)]

    specialRamps = [createRamp(space, specialRampLeft), createRamp(space, specialRampMiddleLeft), createRamp(space, specialRampMiddleRight), createRamp(space, specialRampRight)]

    rOrL = [0, 1]
    rotateNum = 0
    rightSelected = False
    leftSelected = False
    specialSelected = False
    characterSelected = False

    counter = 6000 
    font = pygame.font.SysFont('Consolas', 50)

    #Display Loop
    cmove = 0
    characterX = 200
    while True:
        rotateNum += 1
        if dropped == False:
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 100, 1))
                objects.append(createFallingObject(space, 600, 0))
                objects.append(createFallingObject(space, 250, 0))
                objects.append(createFallingObject(space, 450, 1))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 100, 1))
                        objects.append(createFallingObject(space, 600, 0))
                        objects.append(createFallingObject(space, 250, 0))
                        objects.append(createFallingObject(space, 450, 1))
                        dropped = True
                if 197 <= mousex <= 298 and 431 <= mousey <= 498:
                    if rOrL[0] ==  0:
                        rOrL[0] = 1
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Left))
                    
                    else:
                        rOrL[0] = 0
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Right))
                        
                if 449 <= mousex <= 556 and 431 <= mousey <= 493:
                    if rOrL[1] ==  0:
                        rOrL[1] = 1
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Left))
                    
                    else:
                        rOrL[1] = 0
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Right))
                
                if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                    levelFour(coins, purchases, levels)
                    
                if moveableRampRightx <= mousex <= moveableRampRightx+100 and moveableRampRighty <= mousey <= moveableRampRighty+100:
                    rightSelected = True
                    leftSelected = False
                    specialSelected = False
                if moveableRampLeftx <= mousex <= moveableRampLeftx+100 and moveableRampLefty <= mousey <= moveableRampLefty+100:
                     leftSelected = True
                     rightSelected = False
                     specialSelected = False
                if specialRampx <= mousex <= specialRampx + 510 and specialRampy <= mousey <= specialRampy + 149:
                    rightSelected = False
                    leftSelected = False
                    specialSelected = True
                



            elif event.type == KEYDOWN:
                if (event.key == K_LEFT):
                    if rightSelected:
                        if moveableRampRightx >= 0:
                            space.remove(moveables[0])
                            for i in range(0,4):
                                x, y = posititionsRampMoverRight[i]
                                x -= 10
                                posititionsRampMoverRight[i] = (x,y)
                            moveables[0] = createRamp(space, posititionsRampMoverRight)
                            moveableRampRightx -= 8
                    if leftSelected:
                        if moveableRampLeftx >= 0:
                            space.remove(moveables[1])
                            for i in range(0,4):
                                x, y = posititionsRampMoverLeft[i]
                                x -= 10
                                posititionsRampMoverLeft[i] = (x,y)
                            moveables[1] = createRamp(space, posititionsRampMoverLeft)
                            moveableRampLeftx -= 8
                    if specialSelected:
                        if specialRampx >= 0:
                            for i in range(0, 4):
                                space.remove(specialRamps[i])
                            for i in range(0,4):
                                x, y = specialRampLeft[i]
                                x -= 10
                                specialRampLeft[i] = (x,y)
                            specialRamps[0] = createRamp(space, specialRampLeft)
                            for i in range(0,4):
                                x, y = specialRampMiddleLeft[i]
                                x -= 10
                                specialRampMiddleLeft[i] = (x,y)
                            specialRamps[1] = createRamp(space, specialRampMiddleLeft)
                            for i in range(0,4):
                                x, y = specialRampMiddleRight[i]
                                x -= 10
                                specialRampMiddleRight[i] = (x,y)
                            specialRamps[2] = createRamp(space, specialRampMiddleRight)
                            for i in range(0,4):
                                x, y = specialRampRight[i]
                                x -= 10
                                specialRampRight[i] = (x,y)
                            specialRamps[3] = createRamp(space, specialRampRight)
                            specialRampx -= 8
                     
                 #special double triangle ramp ------------------------------------------------------------------->    
                elif (event.key == K_RIGHT):
                    mouse = pygame.mouse.get_pos()
                    if rightSelected:
                        if moveableRampRightx <= 650:
                            space.remove(moveables[0])
                            for i in range(0,4):
                                x, y = posititionsRampMoverRight[i]
                                x += 10
                                posititionsRampMoverRight[i] = (x,y)
                            moveables[0] = createRamp(space, posititionsRampMoverRight)
                            moveableRampRightx += 8
                    if leftSelected:
                        if moveableRampLeftx <= 650:
                            space.remove(moveables[1])
                            for i in range(0,4):
                                x, y = posititionsRampMoverLeft[i]
                                x += 10
                                posititionsRampMoverLeft[i] = (x,y)
                            moveables[1] = createRamp(space, posititionsRampMoverLeft)
                            moveableRampLeftx += 8
                         
                    if specialSelected:
                        if specialRampx <= 650:
                            for i in range(0, 4):
                                space.remove(specialRamps[i])
                            for i in range(0,4):
                                 x, y = specialRampLeft[i]
                                 x += 10
                                 specialRampLeft[i] = (x,y)
                            specialRamps[0] = createRamp(space, specialRampLeft)
                            for i in range(0,4):
                                 x, y = specialRampMiddleLeft[i]
                                 x += 10
                                 specialRampMiddleLeft[i] = (x,y)
                            specialRamps[1] = createRamp(space, specialRampMiddleLeft)
                            for i in range(0,4):
                                 x, y = specialRampMiddleRight[i]
                                 x += 10
                                 specialRampMiddleRight[i] = (x,y)
                            specialRamps[2] = createRamp(space, specialRampMiddleRight)
                            for i in range(0,4):
                                 x, y = specialRampRight[i]
                                 x += 10
                                 specialRampRight[i] = (x,y)
                            specialRamps[3] = createRamp(space, specialRampRight)
                            specialRampx += 8
                if (event.key == K_LEFT):
                    mouse = pygame.mouse.get_pos()
                    if 200 + cmove <= mouse[0] <= 257 + cmove and 704 <= mouse[1] <= 773:
                        if levels[3].getMover():
                            if characterX >= 0:
                                characterX -= 10 
                                cmove -= 10
    
                if (event.key == K_RIGHT):
                    mouse = pygame.mouse.get_pos()
                    if 200 + cmove <= mouse[0] <= 257 + cmove and 704 <= mouse[1] <= 773:
                        if levels[3].getMover():
                            if characterX <= 650:
                                characterX += 10 
                                cmove += 10
                         
                         
            
        
        screen.blit(background, (0, 0))
        screen.blit(retryLevelButton, (retryx, retryy))
        
        #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position

        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(coinsCage, (50, 0))
            screen.blit(lavaCage, (200, 0))
            screen.blit(lavaCage, (550, 0))
            screen.blit(coinsCage, (400, 0))
        
        #Depending on the value in rOrL, the ramp is placed at different heights
        
        if rotateNum == 0 :
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp0
            rotatedrampBackwards = ramp0
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
        elif rotateNum == 3:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp30
            rotatedrampBackwards = ramp150
            spinners[0] = createRamp(space, positionsSpinningRampOne30)
            spinners[1] = createRamp(space, positionsSpinningRampTwo150)
        elif rotateNum == 6:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp60
            rotatedrampBackwards = ramp120
            spinners[0] = createRamp(space, positionsSpinningRampOne60)
            spinners[1] = createRamp(space, positionsSpinningRampTwo120)
        elif rotateNum == 9:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp90
            rotatedrampBackwards = ramp90
            spinners[0] = createRamp(space, positionsSpinningRampOne90)
            spinners[1] = createRamp(space, positionsSpinningRampTwo90)
        elif rotateNum == 12:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp120
            rotatedrampBackwards = ramp60
            spinners[0] = createRamp(space, positionsSpinningRampOne120)
            spinners[1] = createRamp(space, positionsSpinningRampTwo60)
        elif rotateNum == 15:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp150
            rotatedrampBackwards = ramp30
            spinners[0] = createRamp(space, positionsSpinningRampOne150)
            spinners[1] = createRamp(space, positionsSpinningRampTwo30)
        elif rotateNum == 18:
            space.remove(spinners[0])
            space.remove(spinners[1])
            rotatedramp = ramp0
            rotatedrampBackwards = ramp0
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            rotateNum = 0
        
        screen.blit(specialRampImg, (specialRampx, specialRampy)) # ------------------------------------------
        
        
        if rOrL[0] == 0:
            screen.blit(rampRight, (200, 425))
        else:
            screen.blit(rampLeft, (200, 425))
        
        if rOrL[1] == 0:
            screen.blit(rampRight, (450, 425))
        else:
            screen.blit(rampLeft, (450, 425))
            
        screen.blit(moveableRampRight, (moveableRampRightx, moveableRampRighty))
        screen.blit(moveableRampLeft, (moveableRampLeftx, moveableRampLefty))
        screen.blit(rotatedramp, (75, 275))
        screen.blit(rotatedrampBackwards, (475, 275))


        screen.blit(dropLever, (330, 85))
        screen.blit(character, (characterX, 700))
        
        location = 0
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position
            if 180 <= bodyx <= 270 and 680 <= bodyy <= 780:
                if cOrL == 1:
                    earned += 1
                    if levels[3].getCoinsEarned() < 2:
                        levels[3].setCoinsEarned(levels[3].getCoinsEarned() + 1)
                    objects.pop(location)
                    if earned == 2:
                        if counter >= 4500:
                            endLevel(3, coins, 4, purchases, levels)
                        elif counter >= 3000:
                            endLevel(2, coins, 4, purchases, levels)
                        elif counter >= 1500:
                            endLevel(1, coins, 4, purchases, levels)
                        elif bodyy >= 750 or counter == 0:
                            endLevel(0, coins, 4, purchases, levels)
                else:
                    endLevel(0, coins, 4, purchases, levels)
            if 320 <= bodyx <= 540 and 685 <= bodyy <= 730:
                if cOrL == 1:
                    endLevel(0, coins, 4, purchases, levels)
                else:
                    objects.pop(location)
            elif bodyy > 1000:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 4, purchases, levels)
            elif bodyx > 730 or bodyx < 20:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 4, purchases, levels)
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 4, purchases, levels)
            location += 1

        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)

                      

def levelFive(coins, purchases, levels):
    if levels[4].Mover() and levels[4].getFlag() == 0:
        levels[4].setFlag(1) 
        powerUp(coins, purchases, levels, 5) 
    def createRamp(space, positions):
            body = pymunk.Body(body_type = pymunk.Body.STATIC)
            shape = pymunk.Poly(body, positions)
            space.add(body, shape)
            return shape      

    def createFallingObject(space, startingPoint, cOrL):
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        if cOrL == 1:
            body.position = (startingPoint, 50)
        else:
             body.position = (startingPoint, 150)
            
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    def drawFallingObject(objects):
        for ob in objects:
            body, cOrL = ob
            if cOrL == 1:
                screen.blit(coinImg, body.body.position)
            else:
                screen.blit(lavaImg, body.body.position)

    pygame.init()
        
    #Variables
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock()
    space  = pymunk.Space()
    space.gravity = (0, 25)
    ramp0 = pygame.image.load('ramprotate0degrees.png')
    ramp30 = pygame.image.load('ramprotate30degrees.png')
    ramp60 = pygame.image.load('ramprotate60degrees.png')
    ramp90 = pygame.image.load('ramprotate90degrees.png')
    ramp120 = pygame.image.load('ramprotate120degrees.png')
    ramp150 = pygame.image.load('ramprotate150degrees.png')
    moveableRampRight = pygame.image.load('ramp2.0mover.png')
    moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
    rampRight = pygame.image.load('smallRampToTheRight.png')
    rampLeft = pygame.image.load('smallRampToTheLeft.png')
    rotatedRampLeft = ramp0
    rotatedRampMiddle = ramp90
    rotatedRampRight = ramp0
    lavaImg = pygame.image.load('lava.png')
    coinImg = pygame.image.load('coin.png')
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelavaSmall.png')
    coinsCage = pygame.image.load('cagecoins.png')
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = -150
    retryy = 675
    earned = 0
    
    if purchases.getPos1() == 2:
        character = pygame.image.load('knight.png')
        background = pygame.image.load('medieval_level.png')
    elif purchases.getPos2() == 2:
        character = pygame.image.load('wizard.png')
        background = pygame.image.load('magical_forrest_level.png')
    elif purchases.getPos3() == 2:
        character = pygame.image.load('basketball_playerc.png')
        background = pygame.image.load('basketball_level_background.png')
    elif purchases.getPos4() == 2:
        character = pygame.image.load('spiderman_character.png')
        background = pygame.image.load('spidey_level_background.png')
    elif purchases.getBonus() == 2:
        character = pygame.image.load('donkey_kong_character.png')
        background = pygame.image.load('donkey_kong.png')
    else:
        character = pygame.image.load('character2.png')
        background = pygame.image.load('level_5.png')
    
    dropped = False
    objects = []
    coinsGotten = 0
    
    moveableRampRightx = 125
    moveableRampRighty = 450
    moveableRampLeftx = 525
    moveableRampLefty = 450

    positionsRamp1Right = [(19, 322), (19, 322), (98, 383), (98, 383)]
    positionsRamp1Left = [(5, 379), (5, 379), (83, 322), (105, 322)]
    
    positionsRamp2Right = [(146, 323), (146, 323), (222, 381), (222, 381)]
    positionsRamp2Left = [(131, 378), (131, 378), (206, 320), (206, 320)]
    
    positionsRamp3Right = [(299, 323), (299, 323), (373, 379), (373, 379)]
    positionsRamp3Left = [(278, 378), (278, 378), (357, 320), (357, 320)]
    
    positionsRamp4Right = [(399, 323), (399, 323), (473, 382), (473, 382)]
    positionsRamp4Left = [(378, 381), (378, 381), (452, 322), (452, 322)]
    
    positionsRamp5Right = [(549, 321), (549, 321), (621, 379), (621, 379)]
    positionsRamp5Left = [(531, 379), (531, 379), (607, 322), (607, 322)]
    
    positionsRamp6Right = [(669, 322), (669, 322), (746, 381), (746, 381)]
    positionsRamp6Left = [(653, 380), (653, 380), (733, 320), (733, 320)]
    
    positionsRamp7Right = [(248, 598), (248, 598), (324, 655), (324, 655)]
    positionsRamp7Left = [(227, 653), (227, 653), (307, 597), (307, 597)]
    
    positionsRamp8Right = [(444, 596), (444, 596), (522, 657), (522, 657)]
    positionsRamp8Left = [(428, 656), (428, 656), (505, 597), (505, 597)]
    
    posititionsRampMoverRight = [(154, 448), (154, 448), (228, 503), (228, 503)]
    posititionsRampMoverLeft = [(530, 504), (530, 504), (606, 447), (606, 447)]
    
    positionsSpinningRampLeft0 = [(104, 212), (104, 212), (200, 212), (200, 212)]
    positionsSpinningRampLeft30 = [(119, 192), (119, 192), (199, 237), (199, 237)]
    positionsSpinningRampLeft60 = [(138, 181), (138, 181), (186, 259), (186, 259)]
    positionsSpinningRampLeft90 = [(140, 171), (140, 171), (160, 176), (160, 176)]
    positionsSpinningRampLeft120 = [(117, 255), (117, 255), (164, 178), (164, 178)]
    positionsSpinningRampLeft150 = [(107, 235), (107, 235), (186, 190), (186, 190)]
    
    positionsSpinningRampMiddle0 = [(330, 460), (330, 460), (425, 460), (425, 460)]
    positionsSpinningRampMiddle30 = [(344, 444), (344, 444), (422, 484), (422, 484)]
    positionsSpinningRampMiddle60 = [(365, 433), (365, 433), (412, 513), (412, 513)]
    positionsSpinningRampMiddle90 = [(364, 421), (364, 421), (386, 429), (386, 429)]
    positionsSpinningRampMiddle120 = [(339, 506), (339, 506), (388, 427), (388, 427)]
    positionsSpinningRampMiddle150 = [(332, 485), (332, 485), (414, 441), (414, 441)]
    
    positionsSpinningRampRight0 = [(552, 213), (552, 213), (653, 213), (653, 213)]
    positionsSpinningRampRight30 = [(556, 234), (556, 234), (634, 189), (634, 189)]
    positionsSpinningRampRight60 = [(568, 257), (568, 257), (615, 177), (615, 177)]
    positionsSpinningRampRight90 = [(588, 171), (588, 171), (608, 178), (608, 178)]
    positionsSpinningRampRight120 = [(590, 183), (590, 183), (635, 260), (635, 260)]
    positionsSpinningRampRight150 = [(567, 193), (567, 193), (650, 237), (650, 237)]
    
    

    clickables = [createRamp(space, positionsRamp1Right), createRamp(space, positionsRamp2Left), createRamp(space, positionsRamp3Right), createRamp(space, positionsRamp4Left), createRamp(space, positionsRamp5Right), createRamp(space, positionsRamp6Left), createRamp(space, positionsRamp7Right), createRamp(space, positionsRamp8Left)]
    moveables = [createRamp(space, posititionsRampMoverRight), createRamp(space, posititionsRampMoverLeft)]
    spinners = [createRamp(space, positionsSpinningRampLeft30), createRamp(space, positionsSpinningRampMiddle120), createRamp(space, positionsSpinningRampRight150)]
    rOrL = [0, 1, 0, 1, 0, 1, 0, 1]
    rotateNum = 3
    rightSelected = False
    leftSelected = False

    counter = 6000 
    font = pygame.font.SysFont('Consolas', 50)

    #Display Loop
    characterX = 350
    cmove = 0
    while True:
        rotateNum += 1 
        if dropped == False:
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 125, 1))
                objects.append(createFallingObject(space, 375, 0))
                objects.append(createFallingObject(space, 575, 1))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 125, 1))
                        objects.append(createFallingObject(space, 375, 0))
                        objects.append(createFallingObject(space, 575, 1))
                        dropped = True
                if 5 <= mousex <= 98 and 320 <= mousey <= 385:
                    if rOrL[0] ==  0:
                        rOrL[0] = 1
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Left))
                    
                    else:
                        rOrL[0] = 0
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Right))
                        
                if 132 <= mousex <= 222 and 327 <= mousey <= 390:
                    if rOrL[1] ==  0:
                        rOrL[1] = 1
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Left))
                    
                    else:
                        rOrL[1] = 0
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Right))
                if 264 <= mousex <= 361 and 319 <= mousey <= 397:
                    if rOrL[2] ==  0:
                        rOrL[2] = 1
                        space.remove(clickables[2])
                        clickables[2] = (createRamp(space, positionsRamp3Left))
                    
                    else:
                        rOrL[2] = 0
                        space.remove(clickables[2])
                        clickables[2] = (createRamp(space, positionsRamp3Right))
                if 394 <= mousex <= 464 and 322 <= mousey <= 397:
                    if rOrL[3] ==  0:
                        rOrL[3] = 1
                        space.remove(clickables[3])
                        clickables[3] = (createRamp(space, positionsRamp4Left))
                    
                    else:
                        rOrL[3] = 0
                        space.remove(clickables[3])
                        clickables[3] = (createRamp(space, positionsRamp4Right))
                if 525 <= mousex <= 617 and 322 <= mousey <= 386:
                    if rOrL[4] ==  0:
                        rOrL[4] = 1
                        space.remove(clickables[4])
                        clickables[4] = (createRamp(space, positionsRamp5Left))
                    
                    else:
                        rOrL[4] = 0
                        space.remove(clickables[4])
                        clickables[4] = (createRamp(space, positionsRamp5Right))
                        
                if 653 <= mousex <= 746 and 320 <= mousey <= 380:
                    if rOrL[5] ==  0:
                        rOrL[5] = 1
                        space.remove(clickables[5])
                        clickables[1] = (createRamp(space, positionsRamp6Left))
                    
                    else:
                        rOrL[5] = 0
                        space.remove(clickables[5])
                        clickables[5] = (createRamp(space, positionsRamp6Right))
                if 218 <= mousex <= 324 and 607 <= mousey <= 667:
                    if rOrL[6] ==  0:
                        rOrL[6] = 1
                        space.remove(clickables[6])
                        clickables[6] = (createRamp(space, positionsRamp7Left))
                    
                    else:
                        rOrL[6] = 0
                        space.remove(clickables[6])
                        clickables[6] = (createRamp(space, positionsRamp7Right))
                if 424 <= mousex <= 526 and 604 <= mousey <= 668:
                    if rOrL[7] ==  0:
                        rOrL[7] = 1
                        space.remove(clickables[7])
                        clickables[7] = (createRamp(space, positionsRamp8Left))
                    
                    else:
                        rOrL[7] = 0
                        space.remove(clickables[7])
                        clickables[7] = (createRamp(space, positionsRamp8Right))
                
                if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                    levelFive(coins, purchases, levels)
                
                if moveableRampRightx <= mousex <= moveableRampRightx+100 and moveableRampRighty <= mousey <= moveableRampRighty+100:
                     rightSelected = True
                     leftSelected = False
                if moveableRampLeftx <= mousex <= moveableRampLeftx+100 and moveableRampLefty <= mousey <= moveableRampLefty+100:
                    leftSelected = True
                    rightSelected = False

            elif event.type == KEYDOWN:
                if (event.key == K_LEFT):
                    if rightSelected:
                        space.remove(moveables[0])
                        for i in range(0,4):
                            x, y = posititionsRampMoverRight[i]
                            x -= 10
                            posititionsRampMoverRight[i] = (x,y)
                        moveables[0] = createRamp(space, posititionsRampMoverRight)
                        moveableRampRightx -= 8
                    if leftSelected:
                        space.remove(moveables[1])
                        for i in range(0,4):
                            x, y = posititionsRampMoverLeft[i]
                            x -= 10
                            posititionsRampMoverLeft[i] = (x,y)
                        moveables[1] = createRamp(space, posititionsRampMoverLeft)
                        moveableRampLeftx -= 8
                    
                elif (event.key == K_RIGHT):
                    
                    if rightSelected:
                        space.remove(moveables[0])
                        for i in range(0,4):
                            x, y = posititionsRampMoverRight[i]
                            x += 10
                            posititionsRampMoverRight[i] = (x,y)
                        moveables[0] = createRamp(space, posititionsRampMoverRight)
                        moveableRampRightx += 8
                    if leftSelected:
                        space.remove(moveables[1])
                        for i in range(0,4):
                            x, y = posititionsRampMoverLeft[i]
                            x += 10
                            posititionsRampMoverLeft[i] = (x,y)
                        moveables[1] = createRamp(space, posititionsRampMoverLeft)
                        moveableRampLeftx += 8
                
                mouse = pygame.mouse.get_pos()
                if (event.key == K_LEFT):
                    if 330 + cmove <= mouse[0] <= 410 + cmove and 670 <= mouse[1] <= 750:
                        if levels[4].getMover():
                            if characterX >= 0:
                                characterX -= 10 
                                cmove -= 10
    
                if (event.key == K_RIGHT):
                    if 330 + cmove <= mouse[0] <= 410 + cmove and 670 <= mouse[1] <= 750:
                        if levels[4].getMover():
                            if characterX <= 650:
                                characterX += 10 
                                cmove += 10
        
        screen.blit(background, (0, 0))
        screen.blit(retryLevelButton, (retryx, retryy))
        
        #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left
        for body in objects:
            body, cOrL = body
                        

        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(coinsCage, (25, 0))
            screen.blit(lavaCage, (300, 150))
            screen.blit(coinsCage, (475, 0))
        
        #Depending on the value in rOrL, the ramp is placed at different heights
        
        if rotateNum == 0 :
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampLeft = ramp0
            rotatedRampMiddle = ramp90
            rotatedRampRight = ramp0
            spinners[0] = createRamp(space, positionsSpinningRampLeft0)
            spinners[1] = createRamp(space, positionsSpinningRampMiddle90)
            spinners[2] = createRamp(space, positionsSpinningRampRight0)
        elif rotateNum == 3:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampLeft = ramp30
            rotatedRampMiddle = ramp120
            rotatedRampRight = ramp150
            spinners[0] = createRamp(space, positionsSpinningRampLeft30)
            spinners[1] = createRamp(space, positionsSpinningRampMiddle120)
            spinners[2] = createRamp(space, positionsSpinningRampRight150)
            
        elif rotateNum == 6:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampLeft = ramp60
            rotatedRampMiddle = ramp150
            rotatedRampRight = ramp120
            spinners[0] = createRamp(space, positionsSpinningRampLeft60)
            spinners[1] = createRamp(space, positionsSpinningRampMiddle150)            
            spinners[2] = createRamp(space, positionsSpinningRampRight120)
        elif rotateNum == 9:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampLeft = ramp90
            rotatedRampMiddle = ramp0
            rotatedRampRight = ramp90
            spinners[0] = createRamp(space, positionsSpinningRampLeft90)
            spinners[1] = createRamp(space, positionsSpinningRampMiddle0)
            spinners[2] = createRamp(space, positionsSpinningRampRight90)
        elif rotateNum == 12:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampLeft = ramp120
            rotatedRampMiddle = ramp30
            rotatedRampRight = ramp60
            spinners[0] = createRamp(space, positionsSpinningRampLeft120)
            spinners[1] = createRamp(space, positionsSpinningRampMiddle30)
            spinners[2] = createRamp(space, positionsSpinningRampRight60)
        elif rotateNum == 15:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampLeft = ramp150
            rotatedRampMiddle = ramp60
            rotatedRampRight = ramp30
            spinners[0] = createRamp(space, positionsSpinningRampLeft150)
            spinners[1] = createRamp(space, positionsSpinningRampMiddle60)
            spinners[2] = createRamp(space, positionsSpinningRampRight30)
        elif rotateNum == 18:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampLeft = ramp0
            rotatedRampMiddle = ramp90
            rotatedRampRight = ramp0
            spinners[0] = createRamp(space, positionsSpinningRampLeft0)
            spinners[1] = createRamp(space, positionsSpinningRampMiddle90)
            spinners[2] = createRamp(space, positionsSpinningRampRight0)
            rotateNum = 0
        
        if rOrL[0] == 0:
            screen.blit(rampRight, (0, 325))
        else:
            screen.blit(rampLeft, (0, 325))
        
        if rOrL[1] == 0:
            screen.blit(rampRight, (125, 325))
        else:
            screen.blit(rampLeft, (125, 325))
        
        if rOrL[2] == 0:
            screen.blit(rampRight, (275, 325))
        else:
            screen.blit(rampLeft, (275, 325))
        
        if rOrL[3] == 0:
            screen.blit(rampRight, (375, 325))
        else:
            screen.blit(rampLeft, (375, 325))
        if rOrL[4] == 0:
            screen.blit(rampRight, (525, 325))
        else:
            screen.blit(rampLeft, (525, 325))
        if rOrL[5] == 0:
            screen.blit(rampRight, (650, 325))
        else:
            screen.blit(rampLeft, (650, 325))
        if rOrL[6] == 0:
            screen.blit(rampRight, (225, 600))
        else:
            screen.blit(rampLeft, (225, 600))
        if rOrL[7] == 0:
            screen.blit(rampRight, (425, 600))
        else:
            screen.blit(rampLeft, (425, 600))
        
        screen.blit(moveableRampRight, (moveableRampRightx, moveableRampRighty))
        screen.blit(moveableRampLeft, (moveableRampLeftx, moveableRampLefty))
        screen.blit(rotatedRampLeft, (50, 150))
        screen.blit(rotatedRampMiddle, (275, 400))
        screen.blit(rotatedRampRight, (500, 150))


        screen.blit(dropLever, (325, 85))
        screen.blit(character, (characterX, 675))
        
        location = 0
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position
            if 330 <= bodyx <= 410 and 670 <= bodyy <= 750:
                if cOrL == 1:
                    earned += 1
                    if levels[4].getCoinsEarned() < 2:
                        levels[4].setCoinsEarned(levels[4].getCoinsEarned()+1)
                    objects.pop(location)
                    if earned == 2:
                        if counter >= 4500:
                            endLevel(3, coins, 5, purchases, levels)
                        elif counter >= 3000:
                            endLevel(2, coins, 5, purchases, levels)
                        elif counter >= 1500:
                            endLevel(1, coins, 5, purchases, levels)
                        elif bodyy >= 750 or counter == 0:
                            endLevel(0, coins, 5, purchases, levels)
                else:
                    endLevel(0, coins, 5, purchases, levels)
            elif bodyy > 1000:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 5, purchases, levels)
            elif bodyx > 730 or bodyx < 20:
                objects.pop(location)
            if objects == []:
                endLevel(0, coins, 5, purchases, levels)
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 5, purchases, levels)
            location += 1



        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)
def levelSix(coins, purchases, levels):
    
    if levels[5].Mover() and levels[5].getFlag() == 0:
        levels[5].setFlag(1) 
        powerUp(coins, purchases, levels, 6)
    
    def createFallingObject(space, startingPoint, cOrL): #starting point is x value
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        body.position = (startingPoint, 85)
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    #Draws the object
    def drawFallingObject(objects):
        for ob in objects:
            body, cOrL = ob
            if cOrL == 0:
                screen.blit(lavaImg, body.body.position)
            else:
                screen.blit(coinsImg, body.body.position)
                
    #draws reg ramps
    def drawregramps(poslist, ramplist):
        for p in range(0, len(ramplist)):
            if rOrL[p] == 0:
                screen.blit(rampRight, poslist[p])
            else:
                screen.blit(rampLeft, poslist[p])
                
    def drawspecialramps(poslist, ramplist):
        for p in range(0, len(ramplist)):
            if srOrL[p] == 0:
                screen.blit(moveableRampRight, poslist[p])
            else:
                screen.blit(moveableRampLeft, poslist[p])
                
    def drawrotationalramps(poslist, ramplist, rampimg):
        for p in range(0, len(ramplist)):
            screen.blit(rampimg[p], poslist[p])
            
    #Creates a new static object body
    def createRamp(space, positions):
        body = pymunk.Body(body_type = pymunk.Body.STATIC)
        shape = pymunk.Poly(body, positions)
        space.add(body, shape)
        return shape


    pygame.init()

    #Variables
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock()
    space  = pymunk.Space()
    space.gravity = (0, 25)
    ramp0 = pygame.image.load('ramprotate0degrees.png')
    ramp30 = pygame.image.load('ramprotate30degrees.png')
    ramp60 = pygame.image.load('ramprotate60degrees.png')
    ramp90 = pygame.image.load('ramprotate90degrees.png')
    ramp120 = pygame.image.load('ramprotate120degrees.png')
    ramp150 = pygame.image.load('ramprotate150degrees.png')
    moveableRampRight = pygame.image.load('ramp2.0mover.png')
    moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
    rampRight = pygame.image.load('smallRampToTheRight.png')
    rampLeft = pygame.image.load('smallRampToTheLeft.png')
    rotatedramp = ramp0
    rotatedrampBackwards = ramp0
    lavaImg = pygame.image.load('lava.png')
    coinsImg = pygame.image.load('coin.png')
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelavaSmall.png')
    coinsCage = pygame.image.load('cagecoinsSmall.png')
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = -150
    retryy = 675
    earned = 0
    
    if purchases.getPos1() == 2:
        character = pygame.image.load('knight.png')
        background = pygame.image.load('medieval_level.png')
    elif purchases.getPos2() == 2:
        character = pygame.image.load('wizard.png')
        background = pygame.image.load('magical_forrest_level.png')
    elif purchases.getPos3() == 2:
        character = pygame.image.load('basketball_playerc.png')
        background = pygame.image.load('basketball_level_background.png')
    elif purchases.getPos4() == 2:
        character = pygame.image.load('spiderman_character.png')
        background = pygame.image.load('spidey_level_background.png')
    elif purchases.getBonus() == 2:
        character = pygame.image.load('donkey_kong_character.png')
        background = pygame.image.load('donkey_kong.png')
    else:
        character = pygame.image.load('character2.png')
        background = pygame.image.load('level_6_background.png')

    dropped = False
    objects = []

    #Ramp position template
    ramp1PositionsRight = [((52),(251)), ((52),(251)), ((139),(316)), ((139),(316))]
    rpos1r = (50, 250)
    ramp1PositionsLeft = [((59),(318)), ((59),(318)), ((143),(246)), ((143),(246))]
    rpos1l = (50, 250)

    ramp2PositionsRight = [((228),(250)), ((228),(250)), ((325),(316)), ((325),(316))]
    rpos2r = (225, 250)
    ramp2PositionsLeft = [((231),(315)), ((231),(315)), ((317),(247)), ((318),(250))]
    rpos2l = (225, 250)

    ramp3PositionsRight = [((403),(253)), ((403),(253)), ((487),(316)), ((487),(316))]
    rpos3r = (400, 250)
    ramp3PositionsLeft = [((407),(315)), ((407),(315)), ((490),(247)), ((490),(247))]
    rpos3l = (400, 250)

    ramp4PositionsLeft = [((583),(315)), ((583),(315)), ((666),(248)), ((666),(248))]
    rpos4r = (575, 250)
    ramp4PositionsRight = [((577),(251)), ((577),(251)), ((662),(316)), ((662),(316))]
    rpos4l = (575, 250)

    positionslist = [rpos1r, rpos2r, rpos3r, rpos4l]

    special1RampRight = [((57),(423)), ((57),(423)), ((142),(491)), ((142),(491))]
    spos1r = (50, 425)


    special2RampLeft = [((408),(490)), ((408),(490)), ((493),(423)), ((493),(423))]
    spos2l = (400, 425)

    special3RampLeft = [((584),(615)), ((584),(615)), ((669),(550)), ((669),(550))]
    spos3l = (575, 550)

    specialpositionslist = [spos1r, spos2l, spos3l]

    rotational1Ramp0 = [((199),(620)), ((199),(620)), ((299),(620)), ((299),(620))]
    rotational1Ramp30 = [((204),(596)), ((204),(596)), ((291),(646)), ((291),(646))]
    rotational1Ramp60 = [((223),(577)), ((223),(577)), ((276),(666)), ((276),(666))]
    rotational1Ramp90 = [((248),(570)), ((248),(570)), ((248),(672)), ((248),(672))]
    rotational1Ramp120 = [((272),(577)), ((272),(577)), ((222),(665)), ((222),(665))]
    rotational1Ramp150 = [((291),(596)), ((291),(596)), ((205),(646)), ((205),(646))]

    rpos1 = (150, 550)

    rotational2Ramp0 = [((449),(721)), ((449),(721)), ((549),(721)), ((549),(721))]
    rotational2Ramp30 = [((455),(694)), ((455),(694)), ((542),(747)), ((542),(747))]
    rotational2Ramp60 = [((475),(679)), ((475),(679)), ((526),(765)), ((526),(765))]
    rotational2Ramp90 = [((498),(671)), ((498),(671)), ((498),(771)), ((498),(771))]
    rotational2Ramp120 = [((522),(678)), ((522),(678)), ((471),(764)), ((471),(764))]
    rotational2Ramp150 = [((541),(696)), ((541),(696)), ((455),(745)), ((455),(745))]
    rpos2 = (400, 650)

    rotationalpositionslist = [rpos1, rpos2]

    #Ramp body creation template
    ramps = [createRamp(space, ramp1PositionsRight), createRamp(space, ramp2PositionsRight), createRamp(space, ramp3PositionsRight), createRamp(space, ramp4PositionsLeft) ]
    specialRamps = [createRamp(space, special1RampRight), createRamp(space, special2RampLeft),  createRamp(space, special3RampLeft)]
    rotationalRamps = [createRamp(space, rotational1Ramp0), createRamp(space, rotational2Ramp0)]

    #Right or left list
    rOrL = [0, 0, 0 ,1]
    srOrL = [0, 1, 1]


    counter = 6000 
    font = pygame.font.SysFont('Consolas', 50)

    #Display Loop
    cmove = 0
    rotateNum = 0
    movex = 0
    move2x = 0
    move3x = 0
    rorampImg = [ramp0, ramp0]
    characterX = 100
    while True:
        rotateNum += 1
        if dropped == False:
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 75, 1))
                objects.append(createFallingObject(space, 250, 0))
                objects.append(createFallingObject(space, 425, 1))
                objects.append(createFallingObject(space, 600, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 75, 1))
                        objects.append(createFallingObject(space, 250, 0))
                        objects.append(createFallingObject(space, 425, 1))
                        objects.append(createFallingObject(space, 600, 0))
                        dropped = True
                
                #Example of how to make a hit box, including removing the ramps out of the space
                # and then adding a new one where the new position of the ramp is based off of
                # the positions above that you set by seeing the exact coordinated by clicking
                #THIS IS FOR THE REGULAR RAMPS ONLY
                
                if 48 <= mousex <= 139 and 246 <= mousey <= 320: #1
                    if rOrL[0] ==  0:
                        rOrL[0] = 1
                        space.remove(ramps[0])
                        ramps[0] = (createRamp(space, ramp1PositionsLeft))
                        
                    else:
                        rOrL[0] = 0
                        space.remove(ramps[0])
                        ramps[0] = (createRamp(space, ramp1PositionsRight))
                        
                if 224 <= mousex <= 315 and 248 <= mousey <= 321: #2
                    if rOrL[1] ==  0:
                        rOrL[1] = 1
                        space.remove(ramps[1])
                        ramps[1] = (createRamp(space, ramp2PositionsLeft))
                        
                    else:
                        rOrL[1] = 0
                        space.remove(ramps[1])
                        ramps[1] = (createRamp(space, ramp2PositionsRight))
                        
                if 397 <= mousex <= 488 and 244 <= mousey <= 320:#3
                    if rOrL[2] ==  0:
                        rOrL[2] = 1
                        space.remove(ramps[2])
                        ramps[2] = (createRamp(space, ramp3PositionsLeft))
                        
                    else:
                        rOrL[2] = 0
                        space.remove(ramps[2])
                        ramps[2] = (createRamp(space, ramp3PositionsRight))
                        
                if 574 <= mousex <= 669 and 246 <= mousey <= 319:#4
                    if rOrL[3] ==  0:
                        rOrL[3] = 1
                        space.remove(ramps[3])
                        ramps[3] = (createRamp(space, ramp4PositionsLeft))
                        
                    else:
                        rOrL[3] = 0
                        space.remove(ramps[3])
                        ramps[3] = (createRamp(space, ramp4PositionsRight))
                
                if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                    levelSix(coins, purchases, levels)
                
            
            # Example of how to make the object move by the arrow keys. It goes through the four positions in the list
            # and adds 10 or removes 10 depending on if you press the right or left key
            
            elif event.type == KEYDOWN:
                if (event.key == K_LEFT): #1 left movement
                    mouse = pygame.mouse.get_pos()
                    if (53 + movex) <= mouse[0] <= (149 + movex) and 420 <= mouse[1] <= 494:
                        if spos1r[0] >= 0:
                            space.remove(specialRamps[0])
                            x, y = spos1r
                            x -= 10
                            movex -= 10
                            spos1r = x, y
                            
                            specialRamps[0] = createRamp(space, special1RampRight)
                            specialpositionslist[0] = spos1r
                            for i in range(0,4):
                                x, y = special1RampRight[i]
                                x -= 10
                                special1RampRight[i] = (x,y)
            
                elif (event.key == K_RIGHT): #1 right movement
                    mouse = pygame.mouse.get_pos()
                    if (53 + movex) <= mouse[0] <= (149 + movex) and 420 <= mouse[1] <= 494:
                        if spos1r[0] <= 650:
                            space.remove(specialRamps[0])
                            x, y = spos1r
                            x += 10
                            movex += 10
                            spos1r = x, y
                            
                            specialRamps[0] = createRamp(space, special1RampRight)
                            specialpositionslist[0] = spos1r
                            for i in range(0,4):
                                x, y = special1RampRight[i]
                                x += 10
                                special1RampRight[i] = (x,y)
                            
                if (event.key == K_LEFT): #2 left movement
                    mouse = pygame.mouse.get_pos()
                    if (401 + move2x) <= mouse[0] <= (495 + move2x) and 420 <= mouse[1] <= 494:
                        if spos2l[0] >= 0:
                            space.remove(specialRamps[1])
                            x, y = spos2l
                            x -= 10
                            move2x -= 10
                            spos2l = x, y
                            
                            specialRamps[1] = createRamp(space, special2RampLeft)
                            specialpositionslist[1] = spos2l
                            for i in range(0,4):
                                x, y = special2RampLeft[i]
                                x -= 10
                                special2RampLeft[i] = (x,y)
            
                elif (event.key == K_RIGHT): #2 right movement
                    mouse = pygame.mouse.get_pos()
                    if (401 + move2x) <= mouse[0] <= (495 + move2x) and 420 <= mouse[1] <= 494:
                        if spos2l[0] <= 650:
                            space.remove(specialRamps[1])
                            x, y = spos2l
                            x += 10
                            move2x += 10
                            spos2l = x, y
                            
                            specialRamps[1] = createRamp(space, special2RampLeft)
                            specialpositionslist[1] = spos2l
                            for i in range(0,4):
                                x, y = special2RampLeft[i]
                                x += 10
                                special2RampLeft[i] = (x,y)

                if (event.key == K_LEFT): #3 left movement
                    mouse = pygame.mouse.get_pos()
                    if (574 + move3x) <= mouse[0] <= (671 + move3x) and 547 <= mouse[1] <= 619:
                        if spos3l[0] >= 0:
                            space.remove(specialRamps[2])
                            x, y = spos3l
                            x -= 10
                            move3x -= 10
                            spos3l = x, y
                            
                            specialRamps[2] = createRamp(space, special3RampLeft)
                            specialpositionslist[2] = spos3l
                            for i in range(0,4):
                                x, y = special3RampLeft[i]
                                x -= 10
                                special3RampLeft[i] = (x,y)
            
                elif (event.key == K_RIGHT): #3 right movement
                    mouse = pygame.mouse.get_pos()
                    if (574 + move3x) <= mouse[0] <= (671 + move3x) and 547 <= mouse[1] <= 619:
                        if spos3l[0] <= 650:
                            space.remove(specialRamps[2])
                            x, y = spos3l
                            x += 10
                            move3x += 10
                            spos3l = x, y
                            
                            specialRamps[2] = createRamp(space, special3RampLeft)
                            specialpositionslist[2] = spos3l
                            for i in range(0,4):
                                x, y = special3RampLeft[i]
                                x += 10
                                special3RampLeft[i] = (x,y)
                                
                if (event.key == K_LEFT):
                    mouse = pygame.mouse.get_pos()
                    if 80 + cmove <= mouse[0] <= 170 + cmove and 640 <= mouse[1] <= 730:
                        if levels[5].getMover():
                            if characterX >= 0:
                                characterX -= 10 
                                cmove -= 10
    
                if (event.key == K_RIGHT):
                    mouse = pygame.mouse.get_pos()
                    if 80 + cmove <= mouse[0] <= 170 + cmove and 640 <= mouse[1] <= 730:
                        if levels[5].getMover():
                            if characterX <= 650:
                                characterX += 10 
                                cmove += 10
                    
                    
                    
        
        screen.blit(background, (0, 0))
        screen.blit(retryLevelButton, (retryx, retryy))
        
        #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left
        location = 0
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position
            if 80 <= bodyx <= 170 and 640 <= bodyy <= 730:
                if cOrL == 1:
                    earned += 1
                    if levels[5].getCoinsEarned() < 2:
                        levels[5].setCoinsEarned(levels[5].getCoinsEarned()+1)
                    objects.pop(location)
                    if earned == 2:
                        if counter >= 4500:
                            endLevel(3, coins, 6, purchases, levels)
                        elif counter >= 3000:
                            endLevel(2, coins, 6, purchases, levels)
                        elif counter >= 1500:
                            endLevel(1, coins, 6, purchases, levels)
                        elif bodyy >= 750 or counter == 0:
                            endLevel(0, coins, 6, purchases, levels)
                else:
                    endLevel(0, coins, 6, purchases, levels)
            elif bodyy > 1000:
                objects.pop(location)
            if objects == []:
                endLevel(0, coins, 6, purchases, levels)
            elif bodyx > 730 or bodyx < 20:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 6, purchases, levels)
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 6, purchases, levels)
            location += 1

        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(coinsCage, (50, 85))
            screen.blit(lavaCage, (202, 85))
            screen.blit(coinsCage, (400, 85))
            screen.blit(lavaCage, (600, 85))
        
        #Example of the rotation, at the top you would add one to rotateNum and
        # then after the rotation is over it restarts.
        
        
        if rotateNum == 0 :
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            rotatedramp1 = ramp0
            rotatedramp2 = ramp0
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            rotationalRamps[0] = createRamp(space, rotational1Ramp0)
            rotationalRamps[1] = createRamp(space, rotational2Ramp0)
            
        elif rotateNum == 3:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            rotatedramp1 = ramp30
            rotatedramp2 = ramp30
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            rotationalRamps[0] = createRamp(space, rotational1Ramp30)
            rotationalRamps[1] = createRamp(space, rotational2Ramp30)
            
        elif rotateNum == 6:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            rotatedramp1 = ramp60
            rotatedramp2 = ramp60
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            rotationalRamps[0] = createRamp(space, rotational1Ramp60)
            rotationalRamps[1] = createRamp(space, rotational2Ramp60)
            
        elif rotateNum == 9:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            rotatedramp1 = ramp90
            rotatedramp2 = ramp90
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            rotationalRamps[0] = createRamp(space, rotational1Ramp90)
            rotationalRamps[1] = createRamp(space, rotational2Ramp90)
            
        elif rotateNum == 12:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            rotatedramp1 = ramp120
            rotatedramp2 = ramp120
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            rotationalRamps[0] = createRamp(space, rotational1Ramp120)
            rotationalRamps[1] = createRamp(space, rotational2Ramp120)
            
        elif rotateNum == 15:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            rotatedramp1 = ramp150
            rotatedramp2 = ramp150
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            rotationalRamps[0] = createRamp(space, rotational1Ramp150)
            rotationalRamps[1] = createRamp(space, rotational2Ramp150)
            
        elif rotateNum == 18:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            rotatedramp1 = ramp0
            rotatedramp2 = ramp0
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            rotationalRamps[0] = createRamp(space, rotational1Ramp0)
            rotationalRamps[1] = createRamp(space, rotational2Ramp0)
            rotateNum = 0

        screen.blit(dropLever, (330, 85))
        screen.blit(character, (characterX, 650))
        
        #Depending on the value in rOrL, the ramp is placed at different heights
        drawregramps(positionslist, ramps)
        drawspecialramps(specialpositionslist, specialRamps)
        drawrotationalramps(rotationalpositionslist, rotationalRamps, rorampImg)
        

        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)

#Level Seven of where;s my money
def levelSeven(coins, purchases, levels):
   #Tests to see if the user had bought a character mover powerup and if they do have one, tests to see if they decided to use it.
    if levels[6].Mover() and levels[6].getFlag() == 0:
        levels[6].setFlag(1) 
        powerUp(coins, purchases, levels, 7)
    
    #Creates the body for the ramps in the space provided
    def createRamp(space, positions):
            #creating the body for the ramp
            body = pymunk.Body(body_type = pymunk.Body.STATIC)
            #Creating the shape for the ramp
            shape = pymunk.Poly(body, positions)
            #Adding the ramp's body into the space
            space.add(body, shape)
            #return the shape
            return shape      
    #Creates a falling object(Lava or Coin)
    def createFallingObject(space, startingPoint, cOrL):
        #creates the body for the object
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        #Sets the position to a specific spot as given from the parameter
        body.position = (startingPoint, 0)    
        #Creates the shape for the object
        shape = pymunk.Circle(body, 25)
        #Adds the objects body into the space
        space.add(body, shape)
        #Sets the variable to either 0 or 1 depending on if it is a coin or a level ball
        cOrL = cOrL
        #returns the shape and the cOrL
        return shape, cOrL
    #Displays the falling objects on the screen
    def drawFallingObject(objects):
        #For loop going through all the objects in the objects list
        for ob in objects:
            #Getting the body and cOrL of the object
            body, cOrL = ob
            #Displays either a coin or a lava ball depending on the value of the objects cOrL value
            if cOrL == 1:
                #Displays the object at the bodie's certain position on the screen
                screen.blit(coinImg, body.body.position)
            else:
                #Displays the object at the bodie's certain position on the screen
                screen.blit(lavaImg, body.body.position)

    pygame.init()
        
    #Variables
    
    #Screen for the level
    screen = pygame.display.set_mode((750,1000), 0, 32)
    
    #Clock for the level
    clock = pygame.time.Clock()
    
    #space for the level, where all the bodies will be put into
    space  = pymunk.Space()
    
    #setting the gravity in the space created
    space.gravity = (0, 25)
    
    #Images for the spinning ramps
    ramp0 = pygame.image.load('ramprotate0degrees.png')
    ramp30 = pygame.image.load('ramprotate30degrees.png')
    ramp60 = pygame.image.load('ramprotate60degrees.png')
    ramp90 = pygame.image.load('ramprotate90degrees.png')
    ramp120 = pygame.image.load('ramprotate120degrees.png')
    ramp150 = pygame.image.load('ramprotate150degrees.png')
    
    #Images for the moveable ramps
    moveableRampRight = pygame.image.load('ramp2.0mover.png')
    moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
    
    #Images for the clickable ramps
    rampRight = pygame.image.load('smallRampToTheRight.png')
    rampLeft = pygame.image.load('smallRampToTheLeft.png')
    
    #Starting points for the spinning ramps
    rotatedRampLeftTop = ramp0
    rotatedRampLeftBottom = ramp0
    rotatedRampRightTop = ramp0
    rotatedRampRightBottom = ramp0
    
    #Lava ball image
    lavaImg = pygame.image.load('lava.png')
    
    #Coin image
    coinImg = pygame.image.load('coin.png')
    
    #Drop lever image
    dropLever = pygame.image.load('drop_lever_off.png')
    
    #Lava and Coin cage images
    lavaCage = pygame.image.load('cagelavaSmall.png')
    coinsCage = pygame.image.load('cagecoinsSmall.png')
    
    #Retry level button image and coordinates
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = -150
    retryy = 675
    earned = 0
    
    #Depending on if any of the skins were selected, the background and character images vary
    if purchases.getPos1() == 2:
        character = pygame.image.load('knight.png')
        background = pygame.image.load('medieval_level.png')
    elif purchases.getPos2() == 2:
        character = pygame.image.load('wizard.png')
        background = pygame.image.load('magical_forrest_level.png')
    elif purchases.getPos3() == 2:
        character = pygame.image.load('basketball_playerc.png')
        background = pygame.image.load('basketball_level_background.png')
    elif purchases.getPos4() == 2:
        character = pygame.image.load('spiderman_character.png')
        background = pygame.image.load('spidey_level_background.png')
    elif purchases.getBonus() == 2:
        character = pygame.image.load('donkey_kong_character.png')
        background = pygame.image.load('donkey_kong.png')
    else:
        character = pygame.image.load('character2.png')
        background = pygame.image.load('level_7.png')
    
    #Variable to see if the objects were dropped
    dropped = False
    
    #Droppable object list
    objects = []
    
    #Coordintes for the moveables
    moveableRampRightTopx = 25
    moveableRampRightTopy = 150
    moveableRampRightBottomx = 235
    moveableRampRightBottomy = 600
    moveableRampLeftTopx = 625
    moveableRampLeftTopy = 150
    moveableRampLeftBottomx = 405
    moveableRampLeftBottomy = 600
    
    #Positions for the first clickable ramp's body
    positionsRamp1Right = [(45, 346), (45, 346), (123, 406), (123, 406)]
    positionsRamp1Left = [(26, 406), (26, 406), (109, 343), (109, 343)]
    
    #Positions for the second clickable ramp's body
    positionsRamp2Right = [(246, 348), (246, 348), (324, 407), (324, 407)]
    positionsRamp2Left = [(225, 407), (225, 407), (307, 347), (307, 347)]
    
    #Positions for the third clickable ramp's body
    positionsRamp3Right = [(448, 349), (488, 349), (525, 406), (525, 406)]
    positionsRamp3Left = [(429, 406), (429, 406), (507, 348), (507, 348)]
    
    #Positions for the fourth clickable ramp's body
    positionsRamp4Right = [(645, 348), (645, 348), (723, 407), (723, 407)]
    positionsRamp4Left = [(630, 405), (630, 405), (705, 346), (705, 346)]
    
    #Positions for the moveable ramp bodies
    posititionsRampMoverRightTop = [(49, 147), (49, 147), (129, 208), (129, 208)]
    posititionsRampMoverRightBottom = [(259, 597), (259, 597), (341, 659), (341, 659)]
    posititionsRampMoverLeftBottom = [(406, 659), (406, 659), (492, 598), (492, 598)]
    posititionsRampMoverLeftTop = [(624, 208), (624, 208), (710, 146), (710, 146)]
    
    #Positions for the first rotational ramp's body
    positionsSpinningRampOne0 = [(79, 511), (79, 511), (173, 511), (173, 511)]
    positionsSpinningRampOne30 = [(93, 492), (93, 492), (175, 539), (175, 539)]
    positionsSpinningRampOne60 = [(114, 483), (114, 483), (160, 562), (160, 562)]
    positionsSpinningRampOne90 = [(114, 472), (114, 472), (137, 479), (137, 479)]
    positionsSpinningRampOne120 = [(90, 557), (90, 557), (142, 474), (142, 474)]
    positionsSpinningRampOne150 = [(82, 537), (82, 537), (162, 489), (162, 489)]
    
    #Positions for the second rotational ramp's body
    positionsSpinningRampTwo0 = [(180, 260), (180, 260), (275, 260), (275, 260)]
    positionsSpinningRampTwo30 = [(193, 242), (193, 242), (275, 286), (275, 286)]
    positionsSpinningRampTwo60 = [(216, 231), (216, 231), (262, 314), (262, 314)]
    positionsSpinningRampTwo90 = [(216, 222), (216, 222), (234, 228), (234, 228)]
    positionsSpinningRampTwo120 = [(191, 304), (191, 304), (242, 222), (242, 222)]
    positionsSpinningRampTwo150 = [(181, 285), (181, 285), (260, 242), (260, 242)]
    
    #Positions for the third rotational ramp's body
    positionsSpinningRampThree0 = [(480, 263), (480, 263), (576, 263), (576, 263)]
    positionsSpinningRampThree30 = [(492, 241), (492, 241), (576, 288), (576, 288)]
    positionsSpinningRampThree60 = [(515, 231), (515, 231), (563, 312), (563, 312)]
    positionsSpinningRampThree90 = [(518, 221), (518, 221), (537, 226), (537, 226)]
    positionsSpinningRampThree120 = [(488, 309), (488, 309), (537, 223), (537, 223)]
    positionsSpinningRampThree150 = [(479, 286), (479, 286), (562, 240), (562, 240)]
    
    #Positions for the fourth rotational ramp's body
    positionsSpinningRampFour0 = [(580, 509), (580, 509), (674, 512), (674, 512)]
    positionsSpinningRampFour30 = [(594, 493), (594, 493), (674, 537), (674, 537)]
    positionsSpinningRampFour60 = [(615, 482), (615, 482), (662, 561), (662, 561)]
    positionsSpinningRampFour90 = [(616, 469), (616, 469), (634, 476), (634, 476)]
    positionsSpinningRampFour120 = [(591, 555), (591, 555), (638, 475), (638, 475)]
    positionsSpinningRampFour150 = [(580, 538), (580, 538), (662, 488), (662, 488)]
    
    #Clickable ramp object list
    clickables = [createRamp(space, positionsRamp1Right), createRamp(space, positionsRamp2Left), createRamp(space, positionsRamp3Right), createRamp(space, positionsRamp4Left)]
    #Moveable ramp object list
    moveables = [createRamp(space, posititionsRampMoverRightTop), createRamp(space, posititionsRampMoverRightBottom),
                 createRamp(space, posititionsRampMoverLeftTop), createRamp(space, posititionsRampMoverLeftBottom)]
    #Spinnable ramp object list
    spinners = [createRamp(space, positionsSpinningRampOne30), createRamp(space, positionsSpinningRampTwo30), createRamp(space, positionsSpinningRampThree150), createRamp(space, positionsSpinningRampFour150)]
    #List to set if the clickable ramp is facing left or right, 0 for facing right and 1 for facing left
    rOrL = [0, 1, 0, 1]
    #Counter to create the illusion of the ramps spinning
    rotateNum = 3
    #Booleans for what moveable ramp was selected
    rightTopSelected = False
    rightBottomSelected = False
    leftTopSelected = False
    leftBottomSelected = False
    #Timer for the level
    counter = 6000 
    #Font of the timer
    font = pygame.font.SysFont('Consolas', 50)

    #Character x coordinate
    characterX = 350
    #The value being added or substracted from the characters x value, as well as the range for where the mouse would need to be for the character
    cmove = 0
    #Display Loop
    while True:
        #Adding 1 to the rotateNum to cycle through all the images to create the illusion of spinning
        rotateNum += 1 
        #Tests to see if the objects have been dropped
        if dropped == False:
            #Tests to make the sure the user hadn't used all the time alloted to complete the level
            if counter > 0:
                counter -= 1
            #If the objects have not been dropped, once the counter reaches 0 it automatically drops them
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 50, 1))
                objects.append(createFallingObject(space, 225, 0))
                objects.append(createFallingObject(space, 475, 1))
                objects.append(createFallingObject(space, 650, 0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                print(mousex, mousey)
                #If the drop lever was clicked
                if 323 <= mousex <= 425 and 85 <= mousey <= 156:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    #Drops the objects if they have not been already
                    if dropped == False:
                        objects.append(createFallingObject(space, 50, 1))
                        objects.append(createFallingObject(space, 225, 0))
                        objects.append(createFallingObject(space, 475, 1))
                        objects.append(createFallingObject(space, 650, 0))
                        dropped = True
                #tests to see if the first clickable ramp was clicked on
                if 20 <= mousex <= 127 and 353 <= mousey <= 420:
                    #Tests to see if it is facing right or left
                    if rOrL[0] ==  0:
                        #Changes it to left
                        rOrL[0] = 1
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Left))
                    
                    else:
                        #Changes it to right
                        rOrL[0] = 0
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Right))
                
                #tests to see if the second clickable ramp was clicked on       
                if 226 <= mousex <= 327 and 354 <= mousey <= 420:
                    #Tests to see if it is facing right or left
                    if rOrL[1] ==  0:
                        #Changes it to left
                        rOrL[1] = 1
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Left))
                    
                    else:
                        #Changes it to right
                        rOrL[1] = 0
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp2Right))
                
                #tests to see if the third clickable ramp was clicked on 
                if 421 <= mousex <= 520 and 353 <= mousey <= 417:
                    #Tests to see if it is facing right or left
                    if rOrL[2] ==  0:
                        #Changes it to left
                        rOrL[2] = 1
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[2])
                        clickables[2] = (createRamp(space, positionsRamp3Left))
                    
                    else:
                        #Changes it to right
                        rOrL[2] = 0
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[2])
                        clickables[2] = (createRamp(space, positionsRamp3Right))
                
                #tests to see if the fourth clickable ramp was clicked on 
                if 627 <= mousex <= 730 and 354 <= mousey <= 417:
                    #Tests to see if it is facing right or left
                    if rOrL[3] ==  0:
                        #Changes it to left
                        rOrL[3] = 1
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[3])
                        clickables[3] = (createRamp(space, positionsRamp4Left))
                    
                    else:
                        #Changes it to right
                        rOrL[3] = 0
                        #removes the current ramp body and replaces it with the body of the oppposite facing positions
                        space.remove(clickables[3])
                        clickables[3] = (createRamp(space, positionsRamp4Right))
                
                #Tests to see if the replay button was pressed
                if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                    #Calls the same level function, resetting the level
                    levelSeven(coins, purchases, levels)
                
                #Tests to see which moveable ramp was clicked, and then sets that particular one;s boolean variable to true and the rest to false
                if moveableRampRightTopx <= mousex <= moveableRampRightTopx+100 and moveableRampRightTopy <= mousey <= moveableRampRightTopy+100:
                    rightTopSelected = True
                    rightBottomSelected = False
                    leftTopSelected = False
                    leftBottomSelected = False
                if moveableRampRightBottomx <= mousex <= moveableRampRightBottomx+100 and moveableRampRightBottomy <= mousey <= moveableRampRightBottomy+100:
                    rightTopSelected = False
                    rightBottomSelected = True
                    leftTopSelected = False
                    leftBottomSelected = False
                if moveableRampLeftTopx <= mousex <= moveableRampLeftTopx+100 and moveableRampLeftTopy <= mousey <= moveableRampLeftTopy+100:
                    rightTopSelected = False
                    rightBottomSelected = False
                    leftTopSelected = True
                    leftBottomSelected = False
                if moveableRampLeftBottomx <= mousex <= moveableRampLeftBottomx+100 and moveableRampLeftBottomy <= mousey <= moveableRampLeftBottomy+100:
                    rightTopSelected = False
                    rightBottomSelected = False
                    leftTopSelected = False
                    leftBottomSelected = True

            #Tests to see if a key from the keyboard was pressed
            elif event.type == KEYDOWN:
                #If the key is the left arrow key
                if (event.key == K_LEFT):
                    #Tests to see if the right top moveable was selected
                    if rightTopSelected:
                        #removes the current body from the space
                        space.remove(moveables[0])
                        #Goes through the positions list and subtracts 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverRightTop[i]
                            x -= 10
                            posititionsRampMoverRightTop[i] = (x,y)
                        #Creates a new ramp body with the new coordinates
                        moveables[0] = createRamp(space, posititionsRampMoverRightTop)
                        #Subtracts 8 from the x coordiante of the image for the ramp
                        moveableRampRightTopx -= 8
                    #tests to see if the right bottom moveable ramp was selected
                    if rightBottomSelected:
                        #removes the current body from the space
                        space.remove(moveables[1])
                        #Goes through the positions list and subtracts 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverRightBottom[i]
                            x -= 10
                            posititionsRampMoverRightBottom[i] = (x,y)
                        #Creates a new ramp body with the new coordinates
                        moveables[1] = createRamp(space, posititionsRampMoverRightBottom)
                        #Subtracts 8 from the x coordiante of the image for the ramp
                        moveableRampRightBottomx -= 8
                    
                    #Tests to see if the left top moveable ramp was selected
                    if leftTopSelected:
                        #removes the current body from the space
                        space.remove(moveables[2])
                        #Goes through the positions list and subtracts 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverLeftTop[i]
                            x -= 10
                            posititionsRampMoverLeftTop[i] = (x,y)
                        #Creates a new ramp body with the new coordinates
                        moveables[2] = createRamp(space, posititionsRampMoverLeftTop)
                        #Subtracts 8 from the x coordiante of the image for the ramp
                        moveableRampLeftTopx -= 8
                    
                    #Tests to see if the left bottom moveable ramp was selected
                    if leftBottomSelected:
                        #removes the current body from the space
                        space.remove(moveables[3])
                        #Goes through the positions list and subtracts 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverLeftBottom[i]
                            x -= 10
                            posititionsRampMoverLeftBottom[i] = (x,y)
                       #Creates a new ramp body with the new coordinates
                        moveables[3] = createRamp(space, posititionsRampMoverLeftBottom)
                        #Subtracts 8 from the x coordiante of the image for the ramp
                        moveableRampLeftBottomx -= 8
                    
                #tests to see if the key pressed was the right arrow key    
                elif (event.key == K_RIGHT):
                    
                    #Tests to see if the right top moveable ramp was selected
                    if rightTopSelected:
                        #removes the current body from the space
                        space.remove(moveables[0])
                        #Goes through the positions list and adds 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverRightTop[i]
                            x += 10
                            posititionsRampMoverRightTop[i] = (x,y)
                        #Creates a new ramp body with the new coordinates
                        moveables[0] = createRamp(space, posititionsRampMoverRightTop)
                        #Adds 8 from the x coordiante of the image for the ramp
                        moveableRampRightTopx += 8
                    #tests to see if the right bottom moveable ramp was selected
                    if rightBottomSelected:
                        #removes the current body from the space
                        space.remove(moveables[1])
                        #Goes through the positions list and adds 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverRightBottom[i]
                            x += 10
                            posititionsRampMoverRightBottom[i] = (x,y)
                        #Creates a new ramp body with the new coordinates
                        moveables[1] = createRamp(space, posititionsRampMoverRightBottom)
                        #Adds 8 from the x coordiante of the image for the ramp
                        moveableRampRightBottomx += 8
                    #tests to see if the left top moveable ramp was selected
                    if leftTopSelected:
                        #removes the current body from the space
                        space.remove(moveables[2])
                        #Goes through the positions list and adds 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverLeftTop[i]
                            x += 10
                            posititionsRampMoverLeftTop[i] = (x,y)
                        #Creates a new ramp body with the new coordinates
                        moveables[2] = createRamp(space, posititionsRampMoverLeftTop)
                        #Adds 8 from the x coordiante of the image for the ramp
                        moveableRampLeftTopx += 8
                    #Tests to see if the left bottom moveable ramp was selected
                    if leftBottomSelected:
                        #removes the current body from the space
                        space.remove(moveables[3])
                        #Goes through the positions list and adds 10 from all the x values
                        for i in range(0,4):
                            x, y = posititionsRampMoverLeftBottom[i]
                            x += 10
                            posititionsRampMoverLeftBottom[i] = (x,y)
                        #Creates a new ramp body with the new coordinates
                        moveables[3] = createRamp(space, posititionsRampMoverLeftBottom)
                        #Adds 8 from the x coordiante of the image for the ramp
                        moveableRampLeftBottomx += 8
                #gets the mouse's coordiantes for the character movement
                mouse = pygame.mouse.get_pos()
                
                #If the left key was pressed
                if (event.key == K_LEFT):
                    #If the mouse is hovering over the character
                    if 333 + cmove <= mouse[0] <= 421 + cmove and 669 <= mouse[1] <= 753:
                        #If the user is using the character mover powerup
                        if levels[6].getMover():
                            #As long as the character's x value is above 0  # If the rotational counter is at 0#removes the bodies for the rotational ramps
            #updates the image for all the roational ramps to 0
            #Updates all the bodies for the roational ramps
            # If the rotational counter is at 0 
        #removes the bodies for the rotational ramps
            #updates the image for all the roational ramps to either 30 or 150 depending on whihc side of the screen they are on
            
            #it subtracts 10 from the character's x value
                            if characterX >= 0:
                                characterX -= 10 
                                cmove -= 10

                #If the right key was pressed
                if (event.key == K_RIGHT):
                    #If the mouse is hovering over the character
                    if 333 + cmove <= mouse[0] <= 421 + cmove and 669 <= mouse[1] <= 753:
                        #If the user is using the character mover powerup
                        if levels[6].getMover():
                            #As long as the character's x value is below 650 it adds 10 from the character's x value
                            if characterX <= 650:
                                characterX += 10 
                                cmove += 10
        
        #Displays the background and retry button
        screen.blit(background, (0, 0))
        screen.blit(retryLevelButton, (retryx, retryy))

        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(coinsCage, (0, 0))
            screen.blit(lavaCage, (175, 0))
            screen.blit(coinsCage, (425, 0))
            screen.blit(lavaCage, (600, 0))
        
        
        #If the rotational counter is 0
        if rotateNum == 0 :
            #Removes the current body for all the rotational ramps
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            space.remove(spinners[3])
            #Updates the image for the roational ramps to image for 0 degrees
            rotatedRampLeftTop = ramp0
            rotatedRampLeftBottom = ramp0
            rotatedRampRightTop = ramp0
            rotatedRampRightBottom = ramp0
            #Updates the bodies for all the rotational ramps
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
            spinners[3] = createRamp(space, positionsSpinningRampFour0)

        #If the rotational counter is 3
        elif rotateNum == 3:
            #Removes the current body for all the rotational ramps
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            space.remove(spinners[3])
            #Updates the image for the roational ramps to image to either 30 degrees or 150 degrees
            rotatedRampLeftTop = ramp0
            rotatedRampLeftTop = ramp30
            rotatedRampLeftBottom = ramp30
            rotatedRampRightTop = ramp150
            rotatedRampRightBottom = ramp150
            #Updates the bodies for all the rotational ramps
            spinners[0] = createRamp(space, positionsSpinningRampOne30)
            spinners[1] = createRamp(space, positionsSpinningRampTwo30)
            spinners[2] = createRamp(space, positionsSpinningRampThree150)
            spinners[3] = createRamp(space, positionsSpinningRampFour150)

        #If the rotational counter is 6    
        elif rotateNum == 6:
            #Removes the current body for all the rotational ramps
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            space.remove(spinners[3])
            #Updates the image for the roational ramps to image to either 60 degrees or 120 degrees
            rotatedRampLeftTop = ramp60
            rotatedRampLeftBottom = ramp60
            rotatedRampRightTop = ramp120
            rotatedRampRightBottom = ramp120
            #Updates the bodies for all the rotational ramps
            spinners[0] = createRamp(space, positionsSpinningRampOne60)
            spinners[1] = createRamp(space, positionsSpinningRampTwo60)
            spinners[2] = createRamp(space, positionsSpinningRampThree120)
            spinners[3] = createRamp(space, positionsSpinningRampFour120)
        #If the rotational counter is 9      
        elif rotateNum == 9:
            #Removes the current body for all the rotational ramps
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            space.remove(spinners[3])
            #Updates the image for the roational ramps to image to either 90 degrees
            rotatedRampLeftTop = ramp90
            rotatedRampLeftBottom = ramp90
            rotatedRampRightTop = ramp90
            rotatedRampRightBottom = ramp90
            #Updates the bodies for all the rotational ramps
            spinners[0] = createRamp(space, positionsSpinningRampOne90)
            spinners[1] = createRamp(space, positionsSpinningRampTwo90)
            spinners[2] = createRamp(space, positionsSpinningRampThree90)
            spinners[3] = createRamp(space, positionsSpinningRampFour90)
        #If the rotational counter is 12       
        elif rotateNum == 12:
            #Removes the current body for all the rotational ramps
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            space.remove(spinners[3])
            #Updates the image for the roational ramps to image to either 120 degrees or 60 degrees
            rotatedRampLeftTop = ramp120
            rotatedRampLeftBottom = ramp120
            rotatedRampRightTop = ramp60
            rotatedRampRightBottom = ramp60
            #Updates the bodies for all the rotational ramps
            spinners[0] = createRamp(space, positionsSpinningRampOne120)
            spinners[1] = createRamp(space, positionsSpinningRampTwo120)
            spinners[2] = createRamp(space, positionsSpinningRampThree60)
            spinners[3] = createRamp(space, positionsSpinningRampFour60)
        #If the rotational counter is 15      
        elif rotateNum == 15:
            #Removes the current body for all the rotational ramps
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            space.remove(spinners[3])
            #Updates the image for the roational ramps to image to either 150 degrees or 30 degrees
            rotatedRampLeftTop = ramp150
            rotatedRampLeftBottom = ramp150
            rotatedRampRightTop = ramp30
            rotatedRampRightBottom = ramp30
            #Updates the bodies for all the rotational ramps
            spinners[0] = createRamp(space, positionsSpinningRampOne150)
            spinners[1] = createRamp(space, positionsSpinningRampTwo150)
            spinners[2] = createRamp(space, positionsSpinningRampThree30)
            spinners[3] = createRamp(space, positionsSpinningRampFour30)
        #If the rotational counter is 15    
        elif rotateNum == 18:
           #Removes the current body for all the rotational ramps
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            space.remove(spinners[3])
            #Updates the image for the roational ramps to image to 0 degrees
            rotatedRampLeftTop = ramp0
            rotatedRampLeftBottom = ramp0
            rotatedRampRightTop = ramp0
            rotatedRampRightBottom = ramp0
            #Updates the bodies for all the rotational ramps
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
            spinners[3] = createRamp(space, positionsSpinningRampFour0)
            #resets the cycle
            rotateNum = 0
        
        #Tests to see the value for the first clickable ramp and displays the correct image accordingly
        if rOrL[0] == 0:
            screen.blit(rampRight, (25, 350))
        else:
            screen.blit(rampLeft, (25, 350))
        
         #Tests to see the value for the second clickable ramp and displays the correct image accordingly
        if rOrL[1] == 0:
            screen.blit(rampRight, (225, 350))
        else:
            screen.blit(rampLeft, (225, 350))
        
         #Tests to see the value for the third clickable ramp and displays the correct image accordingly
        if rOrL[2] == 0:
            screen.blit(rampRight, (425, 350))
        else:
            screen.blit(rampLeft, (425, 350))
        
         #Tests to see the value for the fourth clickable ramp and displays the correct image accordingly
        if rOrL[3] == 0:
            screen.blit(rampRight, (625, 350))
        else:
            screen.blit(rampLeft, (625, 350))
        
        #Displays all of the moveable ramps
        screen.blit(moveableRampRight, (moveableRampRightTopx, moveableRampRightTopy))
        screen.blit(moveableRampRight, (moveableRampRightBottomx, moveableRampRightBottomy))
        screen.blit(moveableRampLeft, (moveableRampLeftTopx, moveableRampLeftTopy))
        screen.blit(moveableRampLeft, (moveableRampLeftBottomx, moveableRampLeftBottomy))
        
        #Displays all the rotational ramps
        screen.blit(rotatedRampLeftTop, (125, 200))
        screen.blit(rotatedRampLeftBottom, (25, 450))
        screen.blit(rotatedRampRightTop, (425, 200))
        screen.blit(rotatedRampRightBottom, (525, 450))

        #Displays the droplever and the character
        screen.blit(dropLever, (325, 85))
        screen.blit(character, (characterX, 675))
        
        #Location in the object list
        location = 0
        #goes through the entire object list to see if the object is in certain areas of the screen
        for ob in objects:
            #Gets the body from the object
            body, cOrL = ob
            #Gets the XY coordinates from the body
            bodyx, bodyy = body.body.position
            #If the object is in the area where the character is
            if 333+cmove <= bodyx <= 421+cmove and 669 <= bodyy <= 753:
                #If the object is a coin
                if cOrL == 1:
                    #Adds one to the earned variable
                    earned += 1
                    #If the amount of coins earned is less than 2, then it adds the coin to coins earned
                    if levels[6].getCoinsEarned() < 2:
                        levels[6].setCoinsEarned(levels[6].getCoinsEarned()+1)
                    #removes object from the list
                    objects.pop(location)
                    #If earned equal 2 
                    if earned == 2:
                        #if the user completed the level within 15 seconds they get 3 stars, and endlevel is called with the user getting 3 stars
                        if counter >= 4500:
                            endLevel(3, coins, 7, purchases, levels)
                        #if the user completed the level within 30 seconds they get 2 stars, and endlevel is called with the user getting 2 stars
                        elif counter >= 3000:
                            endLevel(2, coins, 7, purchases, levels)
                        #if the user completed the level within 45 seconds they get 1 stars, and endlevel is called with the user getting 1 star
                        elif counter >= 1500:
                            endLevel(1, coins, 7, purchases, levels)
                #otherwise if the object is lava, endlevel is called giving the user 0 stars
                else:
                    endLevel(0, coins, 7, purchases, levels)
            #If the object's y value is greater than the screens size
            elif bodyy > 1000:
                #removes the object from the object list
                objects.pop(location)
                #If the list is then empty the endLevel function is called with 0 stars
                if objects == []:
                    endLevel(0, coins, 7, purchases, levels)
            #If the objects's x value is above 730 or below 20 
            elif bodyx > 730 or bodyx < 20:
                #removes the object from the object list
                objects.pop(location)
                #If the list is then empty the endLevel function is called with 0 stars
                if objects == []:
                    endLevel(0, coins, 7, purchases, levels)
            #If the coin or lava reach the lava pit
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                #removes the object from the object list
                objects.pop(location)
                #If the list is then empty the endLevel function is called with 0 stars
                if objects == []:
                    endLevel(0, coins, 7, purchases, levels)
            #Adds one to the location variable
            location += 1



        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)


def levelEight(coins, purchases, levels):
  if levels[7].Mover() and levels[7].getFlag() == 0:
      levels[7].setFlag(1) 
      powerUp(coins, purchases, levels, 8) 
    
    #Creates a new dynamic object body 
  def createFallingObject(space, startingPointx, startingPointy, cOrL): #starting point is x value
      body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
      body.position = (startingPointx, startingPointy)
      shape = pymunk.Circle(body, 25)
      space.add(body, shape)
      cOrL = cOrL
      return shape, cOrL

  #Drawa the object
  def drawFallingObject(objects):
      for ob in objects:
          body, cOrL = ob
          if cOrL == 0:
              screen.blit(lavaImg, body.body.position)
          else:
              screen.blit(coinsImg, body.body.position)
              
  #draws reg ramps
  def drawregramps(poslist, ramplist):
      for p in range(0, len(ramplist)):
          if rOrL[p] == 0:
              screen.blit(rampRight, poslist[p])
          else:
              screen.blit(rampLeft, poslist[p])
              
  def drawspecialramps(poslist, ramplist):
      for p in range(0, len(ramplist)):
          if srOrL[p] == 0:
              screen.blit(moveableRampRight, poslist[p])
          else:
              screen.blit(moveableRampLeft, poslist[p])
              
  def drawrotationalramps(poslist, ramplist, rampimg):
      for p in range(0, len(ramplist)):
          screen.blit(rampimg[p], poslist[p])
          
  #Creates a new static object body
  def createRamp(space, positions):
      body = pymunk.Body(body_type = pymunk.Body.STATIC)
      shape = pymunk.Poly(body, positions)
      space.add(body, shape)
      return shape


  pygame.init()

  #Variables
  screen = pygame.display.set_mode((750,1000), 0, 32)
  clock = pygame.time.Clock()
  space  = pymunk.Space()
  space.gravity = (0, 25)
  ramp0 = pygame.image.load('ramprotate0degrees.png')
  ramp30 = pygame.image.load('ramprotate30degrees.png')
  ramp60 = pygame.image.load('ramprotate60degrees.png')
  ramp90 = pygame.image.load('ramprotate90degrees.png')
  ramp120 = pygame.image.load('ramprotate120degrees.png')
  ramp150 = pygame.image.load('ramprotate150degrees.png')
  moveableRampRight = pygame.image.load('ramp2.0mover.png')
  moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
  rampRight = pygame.image.load('smallRampToTheRight.png')
  rampLeft = pygame.image.load('smallRampToTheLeft.png')
  rotatedramp = ramp0
  rotatedrampBackwards = ramp0
  lavaImg = pygame.image.load('lava.png')
  coinsImg = pygame.image.load('coin.png')
  dropLever = pygame.image.load('drop_lever_off.png')
  lavaCage = pygame.image.load('cagelavasmall.png')
  coinsCage = pygame.image.load('cagecoinssmall.png')
  retryLevelButton = pygame.image.load('retry_button.png')
  retryx = -150
  retryy = 675
  if purchases.getPos1() == 2:
    character = pygame.image.load('knight.png')
    background = pygame.image.load('medieval_level.png')
  elif purchases.getPos2() == 2:
    character = pygame.image.load('wizard.png')
    background = pygame.image.load('magical_forrest_level.png')
  elif purchases.getPos3() == 2:
    character = pygame.image.load('basketball_playerc.png')
    background = pygame.image.load('basketball_level_background.png')
  elif purchases.getPos4() == 2:
    character = pygame.image.load('spiderman_character.png')
    background = pygame.image.load('spidey_level_background.png')
  elif purchases.getBonus() == 2:
    character = pygame.image.load('donkey_kong_character.png')
    background = pygame.image.load('donkey_kong.png')
  else:
    character = pygame.image.load('character2.png')
    background = pygame.image.load('level_8.png')

  dropped = False
  objects = []

  #Ramp position template
  ramp1PositionsRight = [((491),(298)), ((491),(298)), ((578),(364)), ((578),(364))]
  rpos1r = (488, 299)
  ramp1PositionsLeft = [((495),(367)), ((495),(367)), ((579),(296)), ((579),(296))]
  rpos1l = (488, 299)
  ramp2PositionsRight = [((126),(439)), ((126),(439)), ((216),(507)), ((216),(507))]
  rpos2r = (125, 481)
  ramp2PositionsLeft = [((216),(437)), ((216),(437)), ((131),(506)), ((131),(506))]
  rpos2l = (125, 481)
  ramp3PositionsRight = [((224),(598)), ((224),(598)), ((310),(667)), ((310),(667))]
  rpos3r = (220, 601)
  ramp3PositionsLeft = [((310),(597)), ((310),(597)), ((227),(665)), ((227),(665))]
  rpos3l = (220, 601)
  ramp4PositionsRight = [((527),(567)), ((527),(567)), ((613),(630)), ((613),(630))]
  rpos4r = (523, 566)
  ramp4PositionsLeft = [((613),(567)), ((613),(567)), ((532),(632)), ((532),(632))]
  rpos4l = (523, 566)
  ramp5PositionsRight = [((434),(726)), ((434),(726)), ((519),(656)), ((519),(656))]
  rpos5r = (428, 658)
  ramp5PositionsLeft = [((433),(723)), ((433),(723)), ((518),(654)), ((518),(654))]
  rpos5l = (428, 658)

  positionslist = [rpos1r, rpos2l, rpos3r, rpos4r, rpos5l]

  special1Ramp = [((222),(272)), ((222),(272)), ((305),(207)), ((305),(207))]
  spos1 = (214, 210)
  special2Ramp = [((463),(293)), ((463),(293)), ((378),(360)), ((378),(360))]
  spos2 = (372, 297)
  special3Ramp = [((610),(251)), ((610),(251)), ((693),(185)), ((693),(185))]
  spos3 = (602, 188)
  special4Ramp = [((321),(518)), ((321),(518)), ((402),(452)), ((402),(452))]
  spos4 = (314, 455)


  specialpositionslist = [spos1, spos2, spos3, spos4]

  rotational1Ramp0 = [((75),(264)), ((75),(264)), ((176),(266)), ((176),(266))]
  rotational1Ramp30 = [((81),(238)), ((81),(238)), ((171),(288)), ((171),(288))]
  rotational1Ramp60 = [((102),(221)), ((102),(221)), ((152),(309)), ((152),(309))]
  rotational1Ramp90 = [((126),(212)), ((126),(212)), ((123),(316)), ((123),(316))]
  rotational1Ramp120 = [((147),(218)), ((147),(218)), ((97),(306)), ((97),(306))]
  rotational1Ramp150 = [((168),(235)), ((168),(235)), ((83),(285)), ((83),(285))]
  rpos1 = (27,193)
  rotational2Ramp0 = [((95),(393)), ((95),(393)), ((199),(394)), ((199),(394))]
  rotational2Ramp30 = [((102),(370)), ((102),(370)), ((191),(419)), ((191),(419))]
  rotational2Ramp60 = [((124),(349)), ((124),(349)), ((173),(441)), ((173),(441))]
  rotational2Ramp90 = [((146),(342)), ((146),(342)), ((146),(445)), ((146),(445))]
  rotational2Ramp120 = [((170),(248)), ((170),(248)), ((120),(437)), ((120),(437))]
  rotational2Ramp150 = [((104),(416)), ((104),(416)), ((189),(368)), ((189),(368))]
  rpos2 = (48,323)
  rotational3Ramp0 = [((347),(573)), ((347),(573)), ((448),(577)), ((448),(577))]
  rotational3Ramp30 = [((354),(548)), (((354),(548))), ((444),(600)), ((444),(600))]
  rotational3Ramp60 = [((375),(532)), ((375),(532)), ((426),(619)), ((426),(619))]
  rotational3Ramp90 = [((397),(524)), ((397),(524)), ((398),(628)), ((398),(628))]
  rotational3Ramp120 = [((420),(529)), ((420),(529)), ((369),(617)), ((369),(617))]
  rotational3Ramp150 = [((441),(548)), ((441),(548)), ((354),(596)), ((354),(596))]
  rpos3 = (299,504)
  rotational4Ramp0 = [((419),(223)), ((419),(223)), ((520),(224)), ((520),(224))]
  rotational4Ramp30 = [((423),(199)), ((423),(199)), ((515),(249)), ((515),(249))]
  rotational4Ramp60 = [((444),(179)), ((444),(179)), ((496),(270)), ((496),(270))]
  rotational4Ramp90 = [((469),(173)), ((469),(173)), ((469),(276)), ((469),(276))]
  rotational4Ramp120 = [((491),(178)), ((491),(178)), ((441),(266)), ((441),(266))]
  rotational4Ramp150 = [((512),(197)), ((512),(197)), ((425),(247)), ((425),(247))]
  rpos4 = (370,153)
  rotational5Ramp0 = [((447),(460)), ((447),(460)), ((549),(460)), ((549),(460))]
  rotational5Ramp30 = [((456),(435)), ((456),(435)), ((545),(486)), ((545),(486))]
  rotational5Ramp60 = [((477),(417)), ((477),(417)), ((526),(507)), ((526),(507))]
  rotational5Ramp90 = [((499),(409)), ((499),(409)), ((499),(514)), ((499),(514))]
  rotational5Ramp120 = [((520),(416)), ((520),(416)), ((471),(504)), ((471),(504))]
  rotational5Ramp150 = [((453),(485)), ((453),(485)), ((540),(432)), ((540),(432))]
  rpos5 = (400,390)
  rotational6Ramp0 = [((588),(457)), ((588),(457)), ((691),(459)), ((691),(459))]
  rotational6Ramp30 = [((594),(436)), ((594),(436)), ((685),(486)), ((685),(486))]
  rotational6Ramp60 = [((616),(416)), ((616),(416)), ((665),(505)), ((665),(505))]
  rotational6Ramp90 = [((639),(409)), ((639),(409)), ((639),(514)), ((639),(514))]
  rotational6Ramp120 = [((661),(416)), ((661),(416)), ((610),(503)), ((610),(503))]
  rotational6Ramp150 = [((593),(484)), ((593),(484)), ((683),(435)), ((683),(435))]
  rpos6 = (540,390)


  rotationalpositionslist = [rpos1, rpos2, rpos3, rpos4, rpos5, rpos6]

  #Ramp body creation template
  ramps = [createRamp(space, ramp1PositionsRight), createRamp(space, ramp2PositionsLeft), createRamp(space, ramp3PositionsRight), createRamp(space, ramp4PositionsLeft), createRamp(space, ramp5PositionsLeft)]
  specialRamps = [createRamp(space, special1Ramp), createRamp(space, special2Ramp), createRamp(space, special3Ramp), createRamp(space, special4Ramp)]
  rotationalRamps = [createRamp(space, rotational1Ramp0), createRamp(space, rotational2Ramp0), createRamp(space, rotational3Ramp0), createRamp(space, rotational4Ramp0), createRamp(space, rotational5Ramp0), createRamp(space, rotational6Ramp0)]

  #Right or left list
  rOrL = [0, 1, 0 ,1, 1]
  srOrL = [1, 1, 1, 1]


  counter = 6000 
  font = pygame.font.SysFont('Consolas', 50)

  #Display Loop
  cmove = 0
  rotateNum = 0
  movex = 0
  move2x = 0
  move3x = 0
  move4x = 0
  rorampImg = [ramp0, ramp0, ramp0, ramp0, ramp0, ramp0]
  earned = 0
  characterX = 335
  while True:
      rotateNum += 1
      if dropped == False:
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 75, 85, 0))
                objects.append(createFallingObject(space, 250, 85, 1))
                objects.append(createFallingObject(space, 425, 85, 0))
                objects.append(createFallingObject(space, 600, 85, 1))
                objects.append(createFallingObject(space, 355, 416, 0))
      for event in pygame.event.get():
          if event.type == pygame.QUIT:
              pygame.quit()
              sys.exit()                
          #Checking where the mouse was clicked to decide which ramp is flipped    
          elif event.type == pygame.MOUSEBUTTONDOWN:
              mousex, mousey = event.pos
              if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                  dropLever = pygame.image.load('drop_lever_on.png')
                  if dropped == False:
                      objects.append(createFallingObject(space, 75, 85, 0))
                      objects.append(createFallingObject(space, 250, 85, 1))
                      objects.append(createFallingObject(space, 425, 85, 0))
                      objects.append(createFallingObject(space, 600, 85, 1))
                      objects.append(createFallingObject(space, 355, 416, 0))
                      dropped = True
              
              #Example of how to make a hit box, including removing the ramps out of the space
              # and then adding a new one where the new position of the ramp is based off of
              # the positions above that you set by seeing the exact coordinated by clicking
              #THIS IS FOR THE REGULAR RAMPS ONLY
              
              if 485 <= mousex <= 577 and 297 <= mousey <= 373: #1
                  if rOrL[0] ==  0:
                      rOrL[0] = 1
                      space.remove(ramps[0])
                      ramps[0] = (createRamp(space, ramp1PositionsLeft))
                      
                  else:
                      rOrL[0] = 0
                      space.remove(ramps[0])
                      ramps[0] = (createRamp(space, ramp1PositionsRight))
                      
              if 124 <= mousex <= 220 and 435 <= mousey <= 518: #3
                  if rOrL[1] ==  0:
                      rOrL[1] = 1
                      space.remove(ramps[1])
                      ramps[1] = (createRamp(space, ramp2PositionsLeft))
                      
                  else:
                      rOrL[1] = 0
                      space.remove(ramps[1])
                      ramps[1] = (createRamp(space, ramp2PositionsRight))
                      
              if 523 <= mousex <= 615 and 604 <= mousey <= 685:#2
                  if rOrL[3] ==  0:
                      rOrL[3] = 1
                      space.remove(ramps[3])
                      ramps[3] = (createRamp(space, ramp4PositionsLeft))
                      
                  else:
                      rOrL[3] = 0
                      space.remove(ramps[3])
                      ramps[3] = (createRamp(space, ramp4PositionsRight))
                      
              if 218 <= mousex <= 310 and 597 <= mousey <= 671:#3
                  if rOrL[2] ==  0:
                      rOrL[2] = 1
                      space.remove(ramps[2])
                      ramps[2] = (createRamp(space, ramp3PositionsLeft))
                      
                  else:
                      rOrL[2] = 0
                      space.remove(ramps[2])
                      ramps[2] = (createRamp(space, ramp3PositionsRight))
                      
              if 426 <= mousex <= 526 and 656 <= mousey <= 735:#5
                  if rOrL[4] ==  0:
                      rOrL[4] = 1
                      space.remove(ramps[4])
                      ramps[4] = (createRamp(space, ramp5PositionsLeft))
                      
                  else:
                      rOrL[4] = 0
                      space.remove(ramps[4])
                      ramps[4] = (createRamp(space, ramp5PositionsRight))
              if 60 <= mousex <= 220 and 830 <= mousey <= 980:
                  levelEight(coins, purchases, levels)
              
          
          # Example of how to make the object move by the arrow keys. It goes through the four positions in the list
          # and adds 10 or removes 10 depending on if you press the right or left key
          
          elif event.type == KEYDOWN:
              if (event.key == K_LEFT): #1 left movement
                  mouse = pygame.mouse.get_pos()
                  if (218 + movex) <= mouse[0] <= (307 + movex) and 211 <= mouse[1] <= 280:
                      if spos1[0] >= 0:
                          space.remove(specialRamps[0])
                          x, y = spos1
                          x -= 10
                          movex -= 10
                          spos1 = x, y
                          
                          specialRamps[0] = createRamp(space, special1Ramp)
                          specialpositionslist[0] = spos1
                          for i in range(0,4):
                              x, y = special1Ramp[i]
                              x -= 10
                              special1Ramp[i] = (x,y)
          
              elif (event.key == K_RIGHT): #1 right movement
                  mouse = pygame.mouse.get_pos()
                  if (218 + movex) <= mouse[0] <= (307 + movex) and 211 <= mouse[1] <= 280:
                      if spos1[0] <= 650:
                          space.remove(specialRamps[0])
                          x, y = spos1
                          x += 10
                          movex += 10
                          spos1 = x, y
                          
                          specialRamps[0] = createRamp(space, special1Ramp)
                          specialpositionslist[0] = spos1
                          for i in range(0,4):
                              x, y = special1Ramp[i]
                              x += 10
                              special1Ramp[i] = (x,y)
                          
              if (event.key == K_LEFT): #2 left movement
                  mouse = pygame.mouse.get_pos()
                  if (375 + move2x) <= mouse[0] <= (464 + move2x) and 297 <= mouse[1] <= 363:
                      if spos2[0] >= 0:
                          space.remove(specialRamps[1])
                          x, y = spos2
                          x -= 10
                          move2x -= 10
                          spos2 = x, y
                          
                          specialRamps[1] = createRamp(space, special2Ramp)
                          specialpositionslist[1] = spos2
                          for i in range(0,4):
                              x, y = special2Ramp[i]
                              x -= 10
                              special2Ramp[i] = (x,y)
          
              elif (event.key == K_RIGHT): #2 right movement
                  mouse = pygame.mouse.get_pos()
                  if (375 + move2x) <= mouse[0] <= (464 + move2x) and 297 <= mouse[1] <= 363:
                      if spos2[0] <= 650:
                          space.remove(specialRamps[1])
                          x, y = spos2
                          x += 10
                          move2x += 10
                          spos2 = x, y
                          
                          specialRamps[1] = createRamp(space, special2Ramp)
                          specialpositionslist[1] = spos2
                          for i in range(0,4):
                              x, y = special2Ramp[i]
                              x += 10
                              special2Ramp[i] = (x,y)

              if (event.key == K_LEFT): #3 left movement
                  mouse = pygame.mouse.get_pos()
                  if (602 + move3x) <= mouse[0] <= (696 + move3x) and 192 <= mouse[1] <= 254:
                      if spos3[0] >= 0:
                          space.remove(specialRamps[2])
                          x, y = spos3
                          x -= 10
                          move3x -= 10
                          spos3 = x, y
                          
                          specialRamps[2] = createRamp(space, special3Ramp)
                          specialpositionslist[2] = spos3
                          for i in range(0,4):
                              x, y = special3Ramp[i]
                              x -= 10
                              special3Ramp[i] = (x,y)
          
              elif (event.key == K_RIGHT): #3 right movement
                  mouse = pygame.mouse.get_pos()
                  if (602 + move3x) <= mouse[0] <= (696 + move3x) and 192 <= mouse[1] <= 254:
                      if spos3[0] <= 650:
                          space.remove(specialRamps[2])
                          x, y = spos3
                          x += 10
                          move3x += 10
                          spos3 = x, y
                          
                          specialRamps[2] = createRamp(space, special3Ramp)
                          specialpositionslist[2] = spos3
                          for i in range(0,4):
                              x, y = special3Ramp[i]
                              x += 10
                              special3Ramp[i] = (x,y)
              if (event.key == K_LEFT): #4 left movement
                  mouse = pygame.mouse.get_pos()
                  if (310 + move4x) <= mouse[0] <= (400 + move4x) and 456 <= mouse[1] <= 530:
                      if spos4[0] >= 0:
                          space.remove(specialRamps[3])
                          x, y = spos4
                          x -= 10
                          move4x -= 10
                          spos4 = x, y
                          
                          specialRamps[3] = createRamp(space, special4Ramp)
                          specialpositionslist[3] = spos4
                          for i in range(0,4):
                              x, y = special4Ramp[i]
                              x -= 10
                              special4Ramp[i] = (x,y)
          
              elif (event.key == K_RIGHT): #4 right movement
                  mouse = pygame.mouse.get_pos()
                  if (310 + move4x) <= mouse[0] <= (400 + move4x) and 456 <= mouse[1] <= 530:
                      if spos2[0] <= 650:
                          space.remove(specialRamps[3])
                          x, y = spos4
                          x += 10
                          move4x += 10
                          spos4 = x, y
                          
                          specialRamps[3] = createRamp(space, special4Ramp)
                          specialpositionslist[3] = spos4
                          for i in range(0,4):
                              x, y = special4Ramp[i]
                              x += 10
                              special4Ramp[i] = (x,y)
                              
              mouse = pygame.mouse.get_pos()
              if (event.key == K_LEFT):
                  if 322 + cmove <= mouse[0] <= 411 + cmove and 729 <= mouse[1] <= 829:
                      if levels[7].getMover():
                          if characterX >= 0:
                              characterX -= 10 
                              cmove -= 10
    
              if (event.key == K_RIGHT):
                  if 322 + cmove <= mouse[0] <= 411 + cmove and 729 <= mouse[1] <= 829:
                      if levels[7].getMover():
                          if characterX <= 650:
                              characterX += 10 
                              cmove += 10        
                              
                
                              
      screen.blit(background, (0, 0))
      screen.blit(retryLevelButton, (retryx, retryy))
      
      #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left
      location = 0
      for body in objects:
          body, cOrL = body
          bodyx, bodyy = body.body.position
          if 322 + cmove <= bodyx <= 411 + cmove and 729 <= bodyy <= 829:
              if cOrL == 1:
                  earned += 1
                  objects.pop(location)
                  if earned == 2:
                      if counter >= 4500:
                          endLevel(3, coins, 8, purchases, levels)
                      elif counter >= 3000:
                          endLevel(2, coins, 8, purchases, levels)
                      elif counter >= 1500:
                          endLevel(1, coins, 8, purchases, levels)
                      elif bodyy >= 750:
                          endLevel(0, coins, 8, purchases, levels)
              else:
                  endLevel(0, coins, 8, purchases, levels)
          elif bodyy > 1000:
                objects.pop(location)
                if objects == []:
                    endLevel(0, coins, 8, purchases, levels)
          elif bodyx > 730 or bodyx < 20:
               objects.pop(location)
               if objects == []:
                    endLevel(0, coins, 8, purchases, levels)
          elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
               objects.pop(location)
               if objects == []:
                     endLevel(0, coins, 8, purchases, levels)
          location += 1
    
      # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
      if dropped:
          drawFallingObject(objects)
      else:
          screen.blit(lavaCage, (50, 85))
          screen.blit(coinsCage, (202, 85))
          screen.blit(lavaCage, (400, 85))
          screen.blit(coinsCage, (600, 85))
          screen.blit(lavaCage, (300, 350))
      
      #Example of the rotation, at the top you would add one to rotateNum and
      # then after the rotation is over it restarts.
      
      
      if rotateNum == 0 :
          space.remove(rotationalRamps[0])
          space.remove(rotationalRamps[1])
          space.remove(rotationalRamps[2])
          space.remove(rotationalRamps[3])
          space.remove(rotationalRamps[4])
          space.remove(rotationalRamps[5])
          
          rotatedramp1 = ramp0
          rotatedramp2 = ramp0
          rotatedramp3 = ramp0
          rotatedramp4 = ramp0
          rotatedramp5 = ramp0
          rotatedramp6 = ramp0
          
          rorampImg[0] = rotatedramp1
          rorampImg[1] = rotatedramp2
          rorampImg[2] = rotatedramp3
          rorampImg[3] = rotatedramp4
          rorampImg[4] = rotatedramp5
          rorampImg[5] = rotatedramp6
          
          rotationalRamps[0] = createRamp(space, rotational1Ramp0)
          rotationalRamps[1] = createRamp(space, rotational2Ramp0)
          rotationalRamps[2] = createRamp(space, rotational3Ramp0)
          rotationalRamps[3] = createRamp(space, rotational4Ramp0)
          rotationalRamps[4] = createRamp(space, rotational5Ramp0)
          rotationalRamps[5] = createRamp(space, rotational6Ramp0)
          
      elif rotateNum == 3:
          space.remove(rotationalRamps[0])
          space.remove(rotationalRamps[1])
          space.remove(rotationalRamps[2])
          space.remove(rotationalRamps[3])
          space.remove(rotationalRamps[4])
          space.remove(rotationalRamps[5])
          
          rotatedramp1 = ramp30
          rotatedramp2 = ramp30
          rotatedramp3 = ramp30
          rotatedramp4 = ramp30
          rotatedramp5 = ramp30
          rotatedramp6 = ramp30
          
          rorampImg[0] = rotatedramp1
          rorampImg[1] = rotatedramp2
          rorampImg[2] = rotatedramp3
          rorampImg[3] = rotatedramp4
          rorampImg[4] = rotatedramp5
          rorampImg[5] = rotatedramp6
          
          rotationalRamps[0] = createRamp(space, rotational1Ramp30)
          rotationalRamps[1] = createRamp(space, rotational2Ramp30)
          rotationalRamps[2] = createRamp(space, rotational3Ramp30)
          rotationalRamps[3] = createRamp(space, rotational4Ramp30)
          rotationalRamps[4] = createRamp(space, rotational5Ramp30)
          rotationalRamps[5] = createRamp(space, rotational6Ramp30)
          
          
      elif rotateNum == 6:
          space.remove(rotationalRamps[0])
          space.remove(rotationalRamps[1])
          space.remove(rotationalRamps[2])
          space.remove(rotationalRamps[3])
          space.remove(rotationalRamps[4])
          space.remove(rotationalRamps[5])
          
          rotatedramp1 = ramp60
          rotatedramp2 = ramp60
          rotatedramp3 = ramp60
          rotatedramp4 = ramp60
          rotatedramp5 = ramp60
          rotatedramp6 = ramp60
          
          rorampImg[0] = rotatedramp1
          rorampImg[1] = rotatedramp2
          rorampImg[2] = rotatedramp3
          rorampImg[3] = rotatedramp4
          rorampImg[4] = rotatedramp5
          rorampImg[5] = rotatedramp6
          
          rotationalRamps[0] = createRamp(space, rotational1Ramp60)
          rotationalRamps[1] = createRamp(space, rotational2Ramp60)
          rotationalRamps[2] = createRamp(space, rotational3Ramp60)
          rotationalRamps[3] = createRamp(space, rotational4Ramp60)
          rotationalRamps[4] = createRamp(space, rotational5Ramp60)
          rotationalRamps[5] = createRamp(space, rotational6Ramp60)
          
          
      elif rotateNum == 9:
          space.remove(rotationalRamps[0])
          space.remove(rotationalRamps[1])
          space.remove(rotationalRamps[2])
          space.remove(rotationalRamps[3])
          space.remove(rotationalRamps[4])
          space.remove(rotationalRamps[5])
          
          rotatedramp1 = ramp90
          rotatedramp2 = ramp90
          rotatedramp3 = ramp90
          rotatedramp4 = ramp90
          rotatedramp5 = ramp90
          rotatedramp6 = ramp90
          
          rorampImg[0] = rotatedramp1
          rorampImg[1] = rotatedramp2
          rorampImg[2] = rotatedramp3
          rorampImg[3] = rotatedramp4
          rorampImg[4] = rotatedramp5
          rorampImg[5] = rotatedramp6
          
          rotationalRamps[0] = createRamp(space, rotational1Ramp90)
          rotationalRamps[1] = createRamp(space, rotational2Ramp90)
          rotationalRamps[2] = createRamp(space, rotational3Ramp90)
          rotationalRamps[3] = createRamp(space, rotational4Ramp90)
          rotationalRamps[4] = createRamp(space, rotational5Ramp90)
          rotationalRamps[5] = createRamp(space, rotational6Ramp90)
          
          
      elif rotateNum == 12:
          space.remove(rotationalRamps[0])
          space.remove(rotationalRamps[1])
          space.remove(rotationalRamps[2])
          space.remove(rotationalRamps[3])
          space.remove(rotationalRamps[4])
          space.remove(rotationalRamps[5])
          
          rotatedramp1 = ramp120
          rotatedramp2 = ramp120
          rotatedramp3 = ramp120
          rotatedramp4 = ramp120
          rotatedramp5 = ramp120
          rotatedramp6 = ramp120
          
          rorampImg[0] = rotatedramp1
          rorampImg[1] = rotatedramp2
          rorampImg[2] = rotatedramp3
          rorampImg[3] = rotatedramp4
          rorampImg[4] = rotatedramp5
          rorampImg[5] = rotatedramp6
          
          rotationalRamps[0] = createRamp(space, rotational1Ramp120)
          rotationalRamps[1] = createRamp(space, rotational2Ramp120)
          rotationalRamps[2] = createRamp(space, rotational3Ramp120)
          rotationalRamps[3] = createRamp(space, rotational4Ramp120)
          rotationalRamps[4] = createRamp(space, rotational5Ramp120)
          rotationalRamps[5] = createRamp(space, rotational6Ramp120)
          
          
      elif rotateNum == 15:
          space.remove(rotationalRamps[0])
          space.remove(rotationalRamps[1])
          space.remove(rotationalRamps[2])
          space.remove(rotationalRamps[3])
          space.remove(rotationalRamps[4])
          space.remove(rotationalRamps[5])
          
          rotatedramp1 = ramp150
          rotatedramp2 = ramp150
          rotatedramp3 = ramp150
          rotatedramp4 = ramp150
          rotatedramp5 = ramp150
          rotatedramp6 = ramp150
          
          rorampImg[0] = rotatedramp1
          rorampImg[1] = rotatedramp2
          rorampImg[2] = rotatedramp3
          rorampImg[3] = rotatedramp4
          rorampImg[4] = rotatedramp5
          rorampImg[5] = rotatedramp6
          
          rotationalRamps[0] = createRamp(space, rotational1Ramp150)
          rotationalRamps[1] = createRamp(space, rotational2Ramp150)
          rotationalRamps[2] = createRamp(space, rotational3Ramp150)
          rotationalRamps[3] = createRamp(space, rotational4Ramp150)
          rotationalRamps[4] = createRamp(space, rotational5Ramp150)
          rotationalRamps[5] = createRamp(space, rotational6Ramp150)
          
          
      elif rotateNum == 18:
          space.remove(rotationalRamps[0])
          space.remove(rotationalRamps[1])
          space.remove(rotationalRamps[2])
          space.remove(rotationalRamps[3])
          space.remove(rotationalRamps[4])
          space.remove(rotationalRamps[5])
          
          rotatedramp1 = ramp0
          rotatedramp2 = ramp0
          rotatedramp3 = ramp0
          rotatedramp4 = ramp0
          rotatedramp5 = ramp0
          rotatedramp6 = ramp0
          
          rorampImg[0] = rotatedramp1
          rorampImg[1] = rotatedramp2
          rorampImg[2] = rotatedramp3
          rorampImg[3] = rotatedramp4
          rorampImg[4] = rotatedramp5
          rorampImg[5] = rotatedramp6
          
          rotationalRamps[0] = createRamp(space, rotational1Ramp0)
          rotationalRamps[1] = createRamp(space, rotational2Ramp0)
          rotationalRamps[2] = createRamp(space, rotational3Ramp0)
          rotationalRamps[3] = createRamp(space, rotational4Ramp0)
          rotationalRamps[4] = createRamp(space, rotational5Ramp0)
          rotationalRamps[5] = createRamp(space, rotational6Ramp0)
          
          rotateNum = 0
      
      screen.blit(dropLever, (330, 85))
      screen.blit(character, (characterX, 738))
      
      #Depending on the value in rOrL, the ramp is placed at different heights
      drawregramps(positionslist, ramps)
      drawspecialramps(specialpositionslist, specialRamps)
      drawrotationalramps(rotationalpositionslist, rotationalRamps, rorampImg)
      

      # Displays the counter if the items have not been dropped        
      if dropped == False:
          screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
      
      space.step(1/25)
      pygame.display.update()
      clock.tick(60)                  

def bonusOne(coins, purchases, levels):
    if levels[8].Mover() and levels[8].getFlag() == 0:
      levels[8].setFlag(1) 
      powerUp(coins, purchases, levels, 9) 
    def createFallingObject(space, startingPointx, startingPointy, cOrL): #starting point is x value
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        body.position = (startingPointx, startingPointy)
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    #Drawa the object
    def drawFallingObject(objects):
        for ob in objects:
            body, cOrL = ob
            if cOrL == 0:
                screen.blit(lavaImg, body.body.position)
            else:
                screen.blit(coinsImg, body.body.position)
                
    #draws reg ramps
    def drawregramps(poslist, ramplist):
        for p in range(0, len(ramplist)):
            if rOrL[p] == 0:
                screen.blit(rampRight, poslist[p])
            else:
                screen.blit(rampLeft, poslist[p])
                
    def drawspecialramps(poslist, ramplist):
        for p in range(0, len(ramplist)):
            if srOrL[p] == 0:
                screen.blit(moveableRampRight, poslist[p])
            else:
                screen.blit(moveableRampLeft, poslist[p])
                
    def drawrotationalramps(poslist, ramplist, rampimg):
        for p in range(0, len(ramplist)):
            screen.blit(rampimg[p], poslist[p])

    #Creates a new static object body
    def createRamp(space, positions):
        body = pymunk.Body(body_type = pymunk.Body.STATIC)
        shape = pymunk.Poly(body, positions)
        space.add(body, shape)
        return shape


    pygame.init()

    #Variables
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock()
    space  = pymunk.Space()
    space.gravity = (0, 25)
    ramp0 = pygame.image.load('ramprotate0degrees.png')
    ramp30 = pygame.image.load('ramprotate30degrees.png')
    ramp60 = pygame.image.load('ramprotate60degrees.png')
    ramp90 = pygame.image.load('ramprotate90degrees.png')
    ramp120 = pygame.image.load('ramprotate120degrees.png')
    ramp150 = pygame.image.load('ramprotate150degrees.png')
    moveableRampRight = pygame.image.load('ramp2.0mover.png')
    moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
    rampRight = pygame.image.load('smallRampToTheRight.png')
    rampLeft = pygame.image.load('smallRampToTheLeft.png')
    rotatedramp = ramp0
    rotatedrampBackwards = ramp0
    lavaImg = pygame.image.load('lava.png')
    coinsImg = pygame.image.load('coin.png')
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelavaSmall.png')
    coinsCage = pygame.image.load('cagecoinsSmall.png')
    character = pygame.image.load('donkey_kong_character.png')
    background = pygame.image.load('donkey_kong.png')
    earned = 0

    dropped = False
    objects = []

    #Ramp position template
    ramp1PositionsRight = [((64),(541)), ((64),(541)), ((150),(607)), ((150),(607))]
    ramp1PositionsLeft = [((68),(607)), ((68),(607)), ((152),(539)), ((152),(539))]
    rpos1r = (61, 541)
    rpos1l = (61, 541)

    ramp2PositionsRight = [((204),(543)), ((204),(543)), ((289),(606)), ((289),(606))]
    ramp2PositionsLeft = [((207),(604)), ((207),(604)), ((289),(539)), ((289),(539))]
    rpos2r = (200, 541)
    rpos2l = (200, 541)

    ramp3PositionsRight = [((415),(542)), ((415),(542)), ((498),(606)), ((498),(606))]
    ramp3PositionsLeft = [((418),(605)), ((418),(605)), ((501),(537)), ((501),(537))]
    rpos3r = (410, 541)
    rpos3l = (410, 541)
    [((604),(542)), ((604),(542)), ((687),(606)), ((687),(606))]
    ramp4PositionsRight = [((604),(542)), ((604),(542)), ((687),(606)), ((687),(606))]
    ramp4PositionsLeft = [((609),(604)), ((609),(604)), ((690),(539)), ((690),(539))]
    rpos4r = (600, 541)
    rpos4l = (600, 541)

    ramp5PositionsRight = [((171),(663)), ((171),(663)), ((254),(728)), ((254),(728))]
    ramp5PositionsLeft = [((172),(727)), ((172),(727)), ((222),(714)), ((222),(714))]
    rpos5r = (165, 663)
    rpos5l = (165, 663)

    ramp6PositionsRight = [((472),(664)), ((472),(664)), ((557),(728)), ((557),(728))]
    ramp6PositionsLeft = [((474),(729)), ((474),(729)), ((560),(659)), ((560),(659))]
    rpos6r = (467, 663)
    rpos6l = (467, 663)

    positionslist = [rpos1r, rpos2l, rpos3r, rpos4l, rpos5r, rpos6l]

    specialRamp1 = [((61),(211)), ((61),(211)), ((142),(276)), ((142),(276))]
    spos1 = (50, 210)

    specialRamp2 = [((210),(274)), ((210),(274)), ((292),(209)), ((292),(209))]
    spos2 = (200, 210)

    specialRamp3 = [((420),(210)), ((420),(210)), ((503),(274)), ((503),(274))]
    spos3 = (410, 210)

    specialRamp4 = [((608),(272)), ((608),(272)), ((690),(208)), ((690),(208))]
    spos4 = (600, 210)
    specialpositionslist = [spos1, spos2, spos3, spos4]

    rotational1Ramp0 = [((149),(443)), ((149),(443)), ((249),(443)), ((249),(443))]
    rotational1Ramp30 = [((157),(419)), ((157),(419)), ((243),(469)), ((243),(469))]
    rotational1Ramp60 = [((175),(402)), ((175),(402)), ((225),(491)), ((225),(491))]
    rotational1Ramp90 = [((199),(395)), ((199),(395)), ((199),(498)), ((199),(498))]
    rotational1Ramp120 = [((171),(487)), ((171),(487)), ((221),(401)), ((221),(401))]
    rotational1Ramp150 = [((155),(467)), ((155),(467)), ((241),(418)), ((241),(418))]
    rpos1 = (100,374)

    rotational2Ramp0 = [((499),(443)), ((499),(443)), ((599),(443)), ((599),(443))]
    rotational2Ramp30 = [((508),(420)), ((508),(420)), ((593),(469)), ((593),(469))]
    rotational2Ramp60 = [((526),(402)), ((526),(402)), ((576),(489)), ((576),(489))]
    rotational2Ramp90 = [((546),(397)), ((546),(397)), ((546),(495)), ((546),(495))]
    rotational2Ramp120 = [((520),(486)), ((520),(486)), ((570),(401)), ((570),(401))]
    rotational2Ramp150 = [((505),(467)), ((505),(467)), ((592),(418)), ((592),(418))]
    rpos2 = (450,374)

    rotationalpositionslist = [rpos1, rpos2]


    #Ramp body creation template
    ramps = [createRamp(space, ramp1PositionsLeft), createRamp(space, ramp2PositionsLeft), createRamp(space, ramp3PositionsLeft), createRamp(space, ramp4PositionsRight), createRamp(space, ramp5PositionsRight), createRamp(space, ramp6PositionsRight)]
    specialRamps = [createRamp(space, specialRamp1), createRamp(space, specialRamp2), createRamp(space, specialRamp3), createRamp(space, specialRamp4) ]
    rotationalRamps = [createRamp(space, rotational1Ramp0), createRamp(space, rotational2Ramp0)]
    #Right or left list
    rOrL = [1, 1, 1, 0, 0, 0]
    srOrL = [0, 1, 0, 1]

    counter = 6000 
    font = pygame.font.SysFont('Consolas', 50)

    #Display Loop
    rotateNum = 0
    movex = 0
    move2x = 0
    move3x = 0
    move4x = 0
    rorampImg = [ramp0, ramp0]
    characterX = 335
    cmove = 0
    while True:
        rotateNum += 1
        if dropped == False:
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                objects.append(createFallingObject(space, 75, 85, 0))
                objects.append(createFallingObject(space, 250, 85, 1))
                objects.append(createFallingObject(space, 425, 85, 1))
                objects.append(createFallingObject(space, 600, 85, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 75, 85, 0))
                        objects.append(createFallingObject(space, 250, 85, 1))
                        objects.append(createFallingObject(space, 425, 85, 1))
                        objects.append(createFallingObject(space, 600, 85, 0))
                        dropped = True
                
                #Example of how to make a hit box, including removing the ramps out of the space
                # and then adding a new one where the new position of the ramp is based off of
                # the positions above that you set by seeing the exact coordinated by clicking
                if 62 <= mousex <= 152 and 539 <= mousey <= 613:
                    if rOrL[0] ==  0:
                        rOrL[0] = 1
                        space.remove(ramps[0])
                        ramps[0] = (createRamp(space, ramp1PositionsLeft))
                        
                    else:
                        rOrL[0] = 0
                        space.remove(ramps[0])
                        ramps[0] = (createRamp(space, ramp1PositionsRight))
                        
                if 212 <= mousex <= 300 and 540 <= mousey <= 612:
                    if rOrL[1] ==  0:
                        rOrL[1] = 1
                        space.remove(ramps[1])
                        ramps[1] = (createRamp(space, ramp2PositionsLeft))
                        
                    else:
                        rOrL[1] = 0
                        space.remove(ramps[1])
                        ramps[1] = (createRamp(space, ramp2PositionsRight))
                
                if 410 <= mousex <= 497 and 540 <= mousey <= 612:
                    if rOrL[2] ==  0:
                        rOrL[2] = 1
                        space.remove(ramps[2])
                        ramps[2] = (createRamp(space, ramp3PositionsLeft))
                        
                    else:
                        rOrL[2] = 0
                        space.remove(ramps[2])
                        ramps[2] = (createRamp(space, ramp3PositionsRight))
                if 610 <= mousex <= 699 and 540 <= mousey <= 612:
                    if rOrL[3] ==  0:
                        rOrL[3] = 1
                        space.remove(ramps[3])
                        ramps[3] = (createRamp(space, ramp4PositionsLeft))
                        
                    else:
                        rOrL[3] = 0
                        space.remove(ramps[3])
                        ramps[3] = (createRamp(space, ramp4PositionsRight))
                if 163 <= mousex <= 254 and 661 <= mousey <= 735:
                    if rOrL[4] ==  0:
                        rOrL[4] = 1
                        space.remove(ramps[4])
                        ramps[4] = (createRamp(space, ramp5PositionsLeft))
                        
                    else:
                        rOrL[4] = 0
                        space.remove(ramps[4])
                        ramps[4] = (createRamp(space, ramp5PositionsRight))
                if 477 <= mousex <= 565 and 661 <= mousey <= 735:
                    if rOrL[5] ==  0:
                        rOrL[5] = 1
                        space.remove(ramps[5])
                        ramps[5] = (createRamp(space, ramp6PositionsLeft))
                        
                    else:
                        rOrL[5] = 0
                        space.remove(ramps[5])
                        ramps[5] = (createRamp(space, ramp6PositionsRight))
                
            
            # Example of how to make the object move by the arrow keys. It goes through the four positions in the list
            # and adds 10 or removes 10 depending on if you press the right or left key
            elif event.type == KEYDOWN:
                if (event.key == K_LEFT): #1 left movement
                  mouse = pygame.mouse.get_pos()
                  if (55 + movex) <= mouse[0] <= (144 + movex) and 207 <= mouse[1] <= 280:
                      if spos1[0] >= 0:
                          space.remove(specialRamps[0])
                          x, y = spos1
                          x -= 10
                          movex -= 10
                          spos1 = x, y
                          
                          specialRamps[0] = createRamp(space, specialRamp1)
                          specialpositionslist[0] = spos1
                          for i in range(0,4):
                              x, y = specialRamp1[i]
                              x -= 10
                              specialRamp1[i] = (x,y)
                    
                        
                elif (event.key == K_RIGHT): #1 right movement
                    mouse = pygame.mouse.get_pos()
                    if (67 + movex) <= mouse[0] <= (155 + movex) and 207 <= mouse[1] <= 280:
                        if spos1[0] <= 650:
                            space.remove(specialRamps[0])
                            x, y = spos1
                            x += 10
                            movex += 10
                            spos1 = x, y
                            
                            specialRamps[0] = createRamp(space, specialRamp1)
                            specialpositionslist[0] = spos1
                            for i in range(0,4):
                                x, y = specialRamp1[i]
                                x += 10
                                specialRamp1[i] = (x,y)
                
                if (event.key == K_LEFT): #2 left movement
                  mouse = pygame.mouse.get_pos()
                  if (210 + movex) <= mouse[0] <= (298 + movex) and 207 <= mouse[1] <= 280:
                      if spos2[0] >= 0:
                          space.remove(specialRamps[1])
                          x, y = spos2
                          x -= 10
                          move2x -= 10
                          spos2 = x, y
                          
                          specialRamps[1] = createRamp(space, specialRamp2)
                          specialpositionslist[1] = spos2
                          for i in range(0,4):
                              x, y = specialRamp2[i]
                              x -= 10
                              specialRamp2[i] = (x,y)
                        
                elif (event.key == K_RIGHT): #2 right movement
                    mouse = pygame.mouse.get_pos()
                    if (210 + movex) <= mouse[0] <= (298 + movex) and 207 <= mouse[1] <= 280:
                        if spos2[0] <= 650:
                            space.remove(specialRamps[1])
                            x, y = spos2
                            x += 10
                            move2x += 10
                            spos2 = x, y
                            
                            specialRamps[1] = createRamp(space, specialRamp2)
                            specialpositionslist[1] = spos2
                            for i in range(0,4):
                                x, y = specialRamp2[i]
                                x += 10
                                specialRamp2[i] = (x,y)
                            
                if (event.key == K_LEFT): #3 left movement
                  mouse = pygame.mouse.get_pos()
                  if (414 + movex) <= mouse[0] <= (506 + movex) and 207 <= mouse[1] <= 280:
                      if spos3[0] >= 0:
                          space.remove(specialRamps[2])
                          x, y = spos3
                          x -= 10
                          move3x -= 10
                          spos3 = x, y
                          
                          specialRamps[2] = createRamp(space, specialRamp3)
                          specialpositionslist[2] = spos3
                          for i in range(0,4):
                              x, y = specialRamp3[i]
                              x -= 10
                              specialRamp3[i] = (x,y)
                        
                elif (event.key == K_RIGHT): #3 right movement
                    mouse = pygame.mouse.get_pos()
                    if (414 + movex) <= mouse[0] <= (506 + movex) and 207 <= mouse[1] <= 280:
                        if spos3[0] <= 650:
                            space.remove(specialRamps[2])
                            x, y = spos3
                            x += 10
                            move3x += 10
                            spos3 = x, y
                            
                            specialRamps[2] = createRamp(space, specialRamp3)
                            specialpositionslist[2] = spos3
                            for i in range(0,4):
                                x, y = specialRamp3[i]
                                x += 10
                                specialRamp3[i] = (x,y)
                            
                if (event.key == K_LEFT): #4 left movement
                  mouse = pygame.mouse.get_pos()
                  if (610 + movex) <= mouse[0] <= (696 + movex) and 207 <= mouse[1] <= 280:
                      if spos4[0] >= 0:
                          space.remove(specialRamps[3])
                          x, y = spos4
                          x -= 10
                          move4x -= 10
                          spos4 = x, y
                          
                          specialRamps[3] = createRamp(space, specialRamp4)
                          specialpositionslist[3] = spos4
                          for i in range(0,4):
                              x, y = specialRamp4[i]
                              x -= 10
                              specialRamp4[i] = (x,y)
                        
                elif (event.key == K_RIGHT): #4 right movement
                    mouse = pygame.mouse.get_pos()
                    if (610 + movex) <= mouse[0] <= (696 + movex) and 207 <= mouse[1] <= 280:
                        if spos4[0] <= 650:
                            space.remove(specialRamps[3])
                            x, y = spos4
                            x += 10
                            move4x += 10
                            spos4 = x, y
                            
                            specialRamps[3] = createRamp(space, specialRamp4)
                            specialpositionslist[3] = spos4
                            for i in range(0,4):
                                x, y = specialRamp4[i]
                                x += 10
                                specialRamp4[i] = (x,y)
                mouse = pygame.mouse.get_pos()
                if (event.key == K_LEFT):
                    if 322 + cmove <= mouse[0] <= 411 + cmove and 729 <= mouse[1] <= 829:
                        if levels[8].getMover():
                            if characterX >= 0:
                                characterX -= 10 
                                cmove -= 10
    
                if (event.key == K_RIGHT):
                    if 322 + cmove <= mouse[0] <= 411 + cmove and 729 <= mouse[1] <= 829:
                        if levels[8].getMover():
                            if characterX <= 650:
                                characterX += 10 
                                cmove += 10  
                    
                    
        
        screen.blit(background, (0, 0))        
        #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left

        location = 0
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position
            if 322 <= bodyx <= 411 and 729 <= bodyy <= 829:
                if cOrL == 1:
                    earned += 1
                    if levels[8].getCoinsEarned() < 2:
                        levels[8].setCoinsEarned(levels[8].getCoinsEarned()+1)
                    objects.pop(location)
                    if earned == 2:
                        if counter >= 4500:
                            levels[8].setCompleted(True)
                            bonusOneScreens(coins, purchases, levels)#change third value
                        elif counter >= 3000:
                            if levels[7].isCompleted():
                                bonusOne(coins, purchases, levels)
                            elif levels[5].isCompleted():
                                levelSeven(coins, purchases, levels)
                            else:
                                levelThree(coins, purchases, levels)#change third value
                        elif counter >= 1500:
                            if levels[7].isCompleted():
                                bonusOne(coins, purchases, levels)
                            elif levels[5].isCompleted():
                                levelSeven(coins, purchases, levels)
                            else:
                                levelThree(coins, purchases, levels)#change third value
                        elif bodyy >= 750 or counter == 0:
                            if levels[7].isCompleted():
                                bonusOne(coins, purchases, levels)
                            elif levels[5].isCompleted():
                                levelSeven(coins, purchases, levels)
                            else:
                                levelThree(coins, purchases, levels)#change third value
                else:
                    if levels[7].isCompleted():
                        bonusOne(coins, purchases, levels)
                    elif levels[5].isCompleted():
                        levelSeven(coins, purchases, levels)
                    else:
                        levelThree(coins, purchases, levels)#change third value
            elif bodyy > 1000:
                objects.pop(location)
                if objects == []:
                    if levels[7].isCompleted():
                        bonusOne(coins, purchases, levels)
                    elif levels[5].isCompleted():
                        levelSeven(coins, purchases, levels)
                    else:
                         levelThree(coins, purchases, levels)#change third value
            elif bodyx > 730 or bodyx < 20:
                objects.pop(location)
                if objects == []:
                    if levels[7].isCompleted():
                        bonusOne(coins, purchases, levels)
                    elif levels[5].isCompleted():
                        levelSeven(coins, purchases, levels)
                    else:
                        levelThree(coins, purchases, levels)#change third value
            location += 1
        
        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(lavaCage, (50, 85))
            screen.blit(coinsCage, (202, 85))
            screen.blit(coinsCage, (400, 85))
            screen.blit(lavaCage, (600, 85))

        #Example of the rotation, at the top you would add one to rotateNum and
        # then after the rotation is over it restarts.
        if rotateNum == 0 :
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            
            rotatedramp1 = ramp0
            rotatedramp2 = ramp0
            
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            
            rotationalRamps[0] = createRamp(space, rotational1Ramp0)
            rotationalRamps[1] = createRamp(space, rotational2Ramp0)
            
        elif rotateNum == 3:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            
            rotatedramp1 = ramp30
            rotatedramp2 = ramp30
            
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            
            rotationalRamps[0] = createRamp(space, rotational1Ramp30)
            rotationalRamps[1] = createRamp(space, rotational2Ramp30)
        elif rotateNum == 6:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            
            rotatedramp1 = ramp60
            rotatedramp2 = ramp60
            
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            
            rotationalRamps[0] = createRamp(space, rotational1Ramp60)
            rotationalRamps[1] = createRamp(space, rotational2Ramp60)
        elif rotateNum == 9:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            
            rotatedramp1 = ramp90
            rotatedramp2 = ramp90
            
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            
            rotationalRamps[0] = createRamp(space, rotational1Ramp90)
            rotationalRamps[1] = createRamp(space, rotational2Ramp90)
        elif rotateNum == 12:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            
            rotatedramp1 = ramp120
            rotatedramp2 = ramp120
            
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            
            rotationalRamps[0] = createRamp(space, rotational1Ramp120)
            rotationalRamps[1] = createRamp(space, rotational2Ramp120)
        elif rotateNum == 15:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            
            rotatedramp1 = ramp150
            rotatedramp2 = ramp150
            
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            
            rotationalRamps[0] = createRamp(space, rotational1Ramp150)
            rotationalRamps[1] = createRamp(space, rotational2Ramp150)
        elif rotateNum == 18:
            space.remove(rotationalRamps[0])
            space.remove(rotationalRamps[1])
            
            rotatedramp1 = ramp0
            rotatedramp2 = ramp0
            
            rorampImg[0] = rotatedramp1
            rorampImg[1] = rotatedramp2
            
            rotationalRamps[0] = createRamp(space, rotational1Ramp0)
            rotationalRamps[1] = createRamp(space, rotational2Ramp0)
            rotateNum = 0

        screen.blit(dropLever, (330, 85))
        screen.blit(character, (characterX, 738))
        
        drawregramps(positionslist, ramps)
        drawspecialramps(specialpositionslist, specialRamps)
        drawrotationalramps(rotationalpositionslist, rotationalRamps, rorampImg)

        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)                          

def bonusTwo(coins, purchases, levels):
    if levels[9].Mover() and levels[9].getFlag() == 0: #code for activating powerup screen (activates if the flag is 0 and that the user has atleast 1 character mover)
      levels[9].setFlag(1) #sets flag to 1 so this appears only at beginning of level
      powerUp(coins, purchases, levels, 10) 
    def createFallingObject(space, startingPoint, cOrL): #creates the bodies of the falling objects using pymunk
        body = pymunk.Body(1, 25, body_type = pymunk.Body.DYNAMIC)
        body.position = (startingPoint, 50)
        shape = pymunk.Circle(body, 25)
        space.add(body, shape)
        cOrL = cOrL
        return shape, cOrL

    #Drawa the object
    def drawFallingObject(objects): #actually draws the image of the falling objects
        for ob in objects:
            body, cOrL = ob
            if cOrL == 0:
                screen.blit(lavaImg, body.body.position)
            else:
                screen.blit(coinsImg, body.body.position)

    #Creates a new static object body
    def createRamp(space, positions): #creates bodies of the ramps
        body = pymunk.Body(body_type = pymunk.Body.STATIC)
        shape = pymunk.Poly(body, positions)
        space.add(body, shape)
        return shape


    pygame.init()

    #Variables
    screen = pygame.display.set_mode((750,1000), 0, 32)
    clock = pygame.time.Clock() #clock timer initialise

    #space initalise
    space  = pymunk.Space() 
    space.gravity = (0, 25)

    #ramp images
    ramp0 = pygame.image.load('ramprotate0degrees.png')
    ramp30 = pygame.image.load('ramprotate30degrees.png')
    ramp60 = pygame.image.load('ramprotate60degrees.png')
    ramp90 = pygame.image.load('ramprotate90degrees.png')
    ramp120 = pygame.image.load('ramprotate120degrees.png')
    ramp150 = pygame.image.load('ramprotate150degrees.png')
    moveableRampRight = pygame.image.load('ramp2.0mover.png')
    moveableRampLeft = pygame.image.load('ramp2.0flippedmover.png')
    rightRampImg = pygame.image.load('smallRampToTheRight.png')
    leftRampImg = pygame.image.load('smallRampToTheLeft.png')
    rotatedRampTop = ramp0
    rotatedRampMiddle = ramp0
    rotatedRampBottom = ramp0

    #lava and coin imgs
    lavaImg = pygame.image.load('lava.png')
    coinsImg = pygame.image.load('coin.png')

    #leve and cage images
    dropLever = pygame.image.load('drop_lever_off.png')
    lavaCage = pygame.image.load('cagelavaSmall.png')
    coinsCage = pygame.image.load('cagecoinsSmall.png')

    #character img
    character = pygame.image.load('donkey_kong_character.png')
    #Background and retry button images
    background = pygame.image.load('donkey_kong.png')
    

    #value of dropped starts at false since the objects have yet to fall
    dropped = False
    
    #objects list used for adding lava and coin objects
    objects = []
    
    #counter of 1 minute
    counter = 6000

    #right or left list for the clickable(green ramps) 1 for left and 0 for right
    rOrL = [0, 1]
    #setting font for counter
    font = pygame.font.SysFont('Consolas', 50)

    #variable coords for the ramps
    moveableRampTopx = 150
    moveableRampTopy = 200
    moveableRampMiddlex = 350
    moveableRampMiddley = 500
    moveableRampBottomx = 375
    moveableRampBottomy = 775

    #bodies of the ramps coords (basically a straight line border is drawn so repeat the two coords twice to get the body 1d)
    positionsRamp1Right = [(148, 697), (148, 697), (223, 758), (223, 758)]
    positionsRamp1Left = [(131, 757), (131, 757), (205, 696), (205, 696)]

    positionsRamp2Right = [(619, 297), (619, 297), (698, 356), (698, 356)]
    positionsRamp2Left = [(606, 356), (606, 356), (682, 295), (682, 295)]

    posititionsRampMoverTop = [(175, 196), (175, 196), (254, 257), (254, 257)]
    posititionsRampMoverMiddle = [(351, 558), (351, 558), (433, 496), (433, 496)]
    posititionsRampMoverBottom = [(377, 830), (377, 830), (457, 770), (457, 770)]

    positionsSpinningRampOne0 = [(55, 312), (55, 312), (146, 313), (146, 313)]
    positionsSpinningRampOne30 = [(71, 292), (71, 292), (150, 336), (150, 336)]
    positionsSpinningRampOne60 = [(90, 281), (90, 281), (136, 360), (136, 360)]
    positionsSpinningRampOne90 = [(92, 271), (92, 271), (111, 279), (111, 279)]
    positionsSpinningRampOne120 = [(66, 355), (66, 355), (114, 277), (114, 277)]
    positionsSpinningRampOne150 = [(56, 333), (56, 333), (136, 288), (136, 288)]

    positionsSpinningRampTwo0 = [(431, 386), (431, 386), (526, 389), (526, 389)]
    positionsSpinningRampTwo30 = [(443, 368), (443, 368), (524, 413), (524, 413)]
    positionsSpinningRampTwo60 = [(464, 355), (464, 355), (511, 437), (511, 437)]
    positionsSpinningRampTwo90 = [(467, 345), (467, 345), (486, 354), (486, 354)]
    positionsSpinningRampTwo120 = [(443, 432), (443, 432), (489, 351), (489, 351)]
    positionsSpinningRampTwo150 = [(429, 408), (429, 408), (511, 363), (511, 363)]

    positionsSpinningRampThree0 = [(652, 560), (652, 560), (748, 561), (748, 561)]
    positionsSpinningRampThree30 = [(669, 541), (669, 541), (748, 587), (748, 587)]
    positionsSpinningRampThree60 = [(689, 531), (689, 531), (736, 611), (736, 611)]
    positionsSpinningRampThree90 = [(692, 520), (692, 520), (711, 532), (711, 532)]
    positionsSpinningRampThree120 = [(666, 606), (666, 606), (715, 526), (715, 526)]
    positionsSpinningRampThree150 = [(654, 585), (654, 585), (735, 540), (735, 540)]

    #drawing ramp bodies
    clickables = [createRamp(space, positionsRamp1Right), createRamp(space, positionsRamp2Left)]
    moveables = [createRamp(space, posititionsRampMoverTop), createRamp(space, posititionsRampMoverMiddle), createRamp(space, posititionsRampMoverBottom)]
    spinners = [createRamp(space, positionsSpinningRampOne30), createRamp(space, positionsSpinningRampTwo120), createRamp(space, positionsSpinningRampTwo150)]

    #setting the value of rotate num to 3 (this vairable "rotates" the ramp by switching the images of the ramp every 3 additions of rotatnum)
    rotateNum = 3

    #selections of the ramps set to false since they are not yet selected
    topSelected = False
    middleSelected = False
    bottomSelected = False

    #coins earned 
    earned = 0
    
    #character move avlue (adds to the x coord of the character so that the program can still check for coins dropping the same area when the character moves)
    cmove = 0
    #initial value of character x
    characterX = 300
    while True: #main loop
        rotateNum += 1 #updates rotate
        if dropped == False: #checks if timer is 0, when it is 0 it drops the lava and coin
            if counter > 0:
                counter -= 1
            elif counter == 0 and dropped == False:
                dropped = True
                #draws objects
                objects.append(createFallingObject(space, 50, 1))
                objects.append(createFallingObject(space, 200, 0))
                objects.append(createFallingObject(space, 350, 1))
                objects.append(createFallingObject(space, 500, 0))
                objects.append(createFallingObject(space, 650, 1))
        for event in pygame.event.get():
            if event.type == pygame.QUIT: #quits python program when you click X
                pygame.quit()
                sys.exit()                
            #Checking where the mouse was clicked to decide which ramp is flipped    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 334 <= mousex <= 425 and 86 <= mousey <= 157:
                    dropLever = pygame.image.load('drop_lever_on.png')
                    if dropped == False:
                        objects.append(createFallingObject(space, 50, 1))
                        objects.append(createFallingObject(space, 200, 0))
                        objects.append(createFallingObject(space, 350, 1))
                        objects.append(createFallingObject(space, 500, 0))
                        objects.append(createFallingObject(space, 650, 1))
                        dropped = True
                
               #clickable ramps changes appearance and bodies once the user clicks on the green ramp (numbers are max x and y values you click on to change them)
                if 124 <= mousex <= 222 and 700 <= mousey <= 770:
                    if rOrL[0] ==  0:
                        rOrL[0] = 1
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Left))
                        
                    else:
                        rOrL[0] = 0
                        space.remove(clickables[0])
                        clickables[0] = (createRamp(space, positionsRamp1Right))
                if 599 <= mousex <= 701 and 303 <= mousey <= 368:
                    if rOrL[1] ==  0:
                        rOrL[1] = 1
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp1Left))
                        
                    else:
                        rOrL[1] = 0
                        space.remove(clickables[1])
                        clickables[1] = (createRamp(space, positionsRamp1Right))
                    
                if moveableRampTopx <= mousex <= moveableRampTopx+100 and moveableRampTopy <= mousey <= moveableRampTopy+100:
                    topSelected = True
                    middleSelected = False
                    bottomSelected = False
                if moveableRampMiddlex <= mousex <= moveableRampMiddlex+100 and moveableRampMiddley <= mousey <= moveableRampMiddley+100:
                    topSelected = False
                    middleSelected = True
                    bottomSelected = False
                if moveableRampBottomx <= mousex <= moveableRampBottomx+100 and moveableRampBottomy <= mousey <= moveableRampBottomy+100:
                    topSelected = False
                    middleSelected = False
                    bottomSelected = True
                
            #movable ramps (left arrow key moves it left (negative) and right arrow key moves it right)
            elif event.type == KEYDOWN:
                    if (event.key == K_LEFT):
                        if topSelected: #checks if the top movable ramp is selected (runs if so)
                            space.remove(moveables[0])
                            for i in range(0,4): #gets x and y values for each tuple in the ramp bodies and subtracts 10 to the x of each value and then stores it in each tuple
                                x, y = posititionsRampMoverTop[i]
                                x -= 10
                                posititionsRampMoverTop[i] = (x,y)
                            moveables[0] = createRamp(space, posititionsRampMoverTop) #changes body to the new x values
                            moveableRampTopx -= 10 #subtracts the appearance of the image x value by 10
                        
                        #everything else follows same format with exception to right adding 10 rather than subtracting
                        if middleSelected: #same as top
                            space.remove(moveables[1])
                            for i in range(0,4):
                                x, y = posititionsRampMoverMiddle[i]
                                x -= 10
                                posititionsRampMoverMiddle[i] = (x,y)
                            moveables[1] = createRamp(space, posititionsRampMoverMiddle)
                            moveableRampMiddlex -= 10
                        if bottomSelected:
                            space.remove(moveables[2])
                            for i in range(0,4):
                                x, y = posititionsRampMoverBottom[i]
                                x -= 10
                                posititionsRampMoverBottom[i] = (x,y)
                            moveables[2] = createRamp(space, posititionsRampMoverBottom)
                            moveableRampBottomx -= 8
                        
                    elif (event.key == K_RIGHT):
                        
                        if topSelected:
                            space.remove(moveables[0])
                            for i in range(0,4):
                                x, y = posititionsRampMoverTop[i]
                                x += 10
                                posititionsRampMoverTop[i] = (x,y)
                            moveables[0] = createRamp(space, posititionsRampMoverTop)
                            moveableRampTopx += 10
                        if middleSelected:
                            space.remove(moveables[1])
                            for i in range(0,4):
                                x, y = posititionsRampMoverMiddle[i]
                                x += 10
                                posititionsRampMoverMiddle[i] = (x,y)
                            moveables[1] = createRamp(space, posititionsRampMoverMiddle)
                            moveableRampMiddlex += 10
                        if bottomSelected:
                            space.remove(moveables[2])
                            for i in range(0,4):
                                x, y = posititionsRampMoverBottom[i]
                                x += 10
                                posititionsRampMoverBottom[i] = (x,y)
                            moveables[2] = createRamp(space, posititionsRampMoverBottom)
                            moveableRampBottomx += 8
                    
                    mouse = pygame.mouse.get_pos()
                    if (event.key == K_LEFT):
                        
                        if 294 + cmove <= mouse[0] <= 354 + cmove and 835 <= mouse[1] <= 901:
                            if levels[9].getMover():
                                if characterX >= 0:
                                    characterX -= 10 
                                    cmove -= 10
    
                    if (event.key == K_RIGHT):
                        
                        if 294 + cmove <= mouse[0] <= 354 + cmove and 835 <= mouse[1] <= 901:
                            if levels[9].getMover():
                                if characterX <= 650:
                                    characterX += 10 
                                    cmove += 10 
                    
                    
                    
        
        screen.blit(background, (0,0)) #updates background
        
        #If the coin reaches the character, the end level screen is called with the amount of stars based off of the time left
        location = 0 #location in objects list
        for body in objects:
            body, cOrL = body
            bodyx, bodyy = body.body.position #x and y values of each object in objects lsit
            if 290 <= bodyx <= 370 and 830 <= bodyy <= 900: #collects the coin and adds one to earned
                if cOrL == 1:
                    earned += 1
                    objects.pop(location) #deletes item form list since its collected
                    if earned == 3: #level ends once all coins are earned (completed)
                        if counter >= 4500:
                            levels[9].setCompleted(True)
                            bonusTwoScreens(coins, purchases, levels)
                        elif counter >= 3000:
                            if levels[7].isCompleted():
                                bonusTwo(coins, purchases, levels)
                            else:
                                levelSeven(coins, purchases, levels)
                        elif counter >= 1500:
                            if levels[7].isCompleted():
                                bonusTwo(coins, purchases, levels)
                            else:
                                levelSeven(coins, purchases, levels)
                        elif bodyy >= 750 or counter == 0:
                            if levels[7].isCompleted():
                                bonusTwo(coins, purchases, levels)
                            else:
                                levelSeven(coins, purchases, levels)
                else: #if level is failed then got to level 8
                    if levels[7].isCompleted():
                        bonusTwo(coins, purchases, levels)
                    else:
                        levelSeven(coins, purchases, levels)
            elif bodyy > 1000: #deletes body if it goes off screen
                objects.pop(location)
            if objects == []: #ends level if all objects are deleted (failing)
                if levels[7].isCompleted():
                    bonusTwo(coins, purchases, levels)
                else:
                    levelSeven(coins, purchases, levels)
            elif bodyx > 730 or bodyx < 20: #deletes object if it goes pass left and right b
                objects.pop(location)
                if objects == []:
                    levelSeven(coins, purchases, levels)
            elif (354 <= bodyx <= 663) and 872 <= bodyy <= 951:
                objects.pop(location)
                if objects == []:
                    if levels[7].isCompleted():
                        bonusTwo(coins, purchases, levels)
                    else:
                        levelSeven(coins, purchases, levels)
            location += 1

        # If the items were dropped, they are drawn on the screen, and the lava and coin cages are not displayed                   
        if dropped:
            drawFallingObject(objects)
        else:
            screen.blit(coinsCage, (0, 0))
            screen.blit(lavaCage, (150, 0))
            screen.blit(coinsCage, (300, 0))
            screen.blit(lavaCage, (450, 0))
            screen.blit(coinsCage, (600, 0))
        
        #Depending on the value in rOrL, the ramp is placed at different heights
        if rOrL[0] == 0:
            screen.blit(rightRampImg, (125, 700))
        else:
            screen.blit(leftRampImg, (125, 700))
        
        if rOrL[1] == 0:
            screen.blit(rightRampImg, (600, 300))
        else:
            screen.blit(leftRampImg, (600, 300))
        
        screen.blit(moveableRampRight, (moveableRampTopx, moveableRampTopy))
        screen.blit(moveableRampLeft, (moveableRampMiddlex, moveableRampMiddley))
        screen.blit(moveableRampLeft, (moveableRampBottomx, moveableRampBottomy))
        screen.blit(rotatedRampTop, (0, 250))
        screen.blit(rotatedRampMiddle, (375, 325))
        screen.blit(rotatedRampBottom, (600, 500))
        
        
        #Example of the rotation, at the top you would add one to rotateNum and
        # then after the rotation is over it restarts.
        if rotateNum == 0 :
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampTop = ramp0
            rotatedRampMiddle = ramp90
            rotatedRampBottom = ramp0 
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
        elif rotateNum == 3:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampTop = ramp30
            rotatedRampMiddle = ramp120
            rotatedRampBottom = ramp150 
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
        elif rotateNum == 6:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampTop = ramp60
            rotatedRampMiddle = ramp150
            rotatedRampBottom = ramp120 
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
        elif rotateNum == 9:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampTop = ramp90
            rotatedRampMiddle = ramp0
            rotatedRampBottom = ramp90 
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
        elif rotateNum == 12:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampTop = ramp120
            rotatedRampMiddle = ramp30
            rotatedRampBottom = ramp60 
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
        elif rotateNum == 15:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampTop = ramp150
            rotatedRampMiddle = ramp60
            rotatedRampBottom = ramp30 
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
        elif rotateNum == 18:
            space.remove(spinners[0])
            space.remove(spinners[1])
            space.remove(spinners[2])
            rotatedRampTop = ramp0
            rotatedRampMiddle = ramp90
            rotatedRampBottom = ramp0 
            spinners[0] = createRamp(space, positionsSpinningRampOne0)
            spinners[1] = createRamp(space, positionsSpinningRampTwo0)
            spinners[2] = createRamp(space, positionsSpinningRampThree0)
            rotateNum = 0

        screen.blit(dropLever, (330, 100))
        screen.blit(character, (characterX, 825))

        # Displays the counter if the items have not been dropped        
        if dropped == False:
            screen.blit(font.render(str(counter/100), True, (255, 255, 255)), (300, 25))
        
        space.step(1/25)
        pygame.display.update()
        clock.tick(60)   

#end level screen
def endLevel(stars, coins, level, purchases, levels):
    #if level is not completed and the user got 3 stars on the level then the coins are rewarded to the user
    if levels[level - 1].getCompleted() != True:
        if stars == 3:
            coins += levels[level-1].coins()
            levels[level-1].setCompleted(True)
    
    #removes the character mover ucharge if the user used it on the prvious level
    if levels[level - 1].getMover() == True:
        levels[level - 1].setMover(False)
        purchases.setUses()
            
    pygame.init()
   
    #Display variables
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #button images and placement coords
    nextLevelButton = pygame.image.load('play_button.png')
    nextx = -120
    nexty = 415
    retryLevelButton = pygame.image.load('retry_button.png')
    retryx = 80
    retryy = 400
    homeButton = pygame.image.load('home_button.png')
    homex = 255
    homey = 415
    earnedStar = pygame.image.load('starEarned.png')
    emptyStar = pygame.image.load('emptyStar.png')
    star1x = 70
    star2x = 275
    star3x = 480
    starsy = 100
    
    mouseClicked = False

    # the main display loop
    while True: 
        DISPLAYSURF.fill((0, 0, 150))
        DISPLAYSURF.blit(nextLevelButton, (nextx, nexty))
        DISPLAYSURF.blit(retryLevelButton, (retryx, retryy))
        DISPLAYSURF.blit(homeButton, (homex, homey))
        pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (600, 0, 150, 50))
        font = pygame.font.Font('freesansbold.ttf', 32)
        text = font.render(str(coins), True, (125,255,255), (0,200,255))
        DISPLAYSURF.blit(text, (650, 10, 150, 25))
       
        if stars == 3:
            DISPLAYSURF.blit(earnedStar, (star1x, starsy))
            DISPLAYSURF.blit(earnedStar, (star2x, starsy))
            DISPLAYSURF.blit(earnedStar, (star3x, starsy))
        elif stars == 2:
            DISPLAYSURF.blit(earnedStar, (star1x, starsy))
            DISPLAYSURF.blit(earnedStar, (star2x, starsy))
            DISPLAYSURF.blit(emptyStar, (star3x, starsy))
        elif stars == 1:
            DISPLAYSURF.blit(earnedStar, (star1x, starsy))
            DISPLAYSURF.blit(emptyStar, (star2x, starsy))
            DISPLAYSURF.blit(emptyStar, (star3x, starsy))
        else:
            DISPLAYSURF.blit(emptyStar, (star1x, starsy))
            DISPLAYSURF.blit(emptyStar, (star2x, starsy))
            DISPLAYSURF.blit(emptyStar, (star3x, starsy))
            
        
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                mousex, mousey = event.pos
                print(mousex, mousey)
                #next level button (plays the next level based on what level was just completed or that level if it was not completed)
                if 120 <= mousex <= 238 and 577 <= mousey <= 685:
                    if levels[7].getCompleted():
                        if levels[8].getCompleted() == False:
                            bonusOneScreens(coins, purchases, levels)
                        elif levels[9].getCompleted() == False:
                            bonusTwoScreens(coins, purchases, levels)
                        else:
                            endGameScreen(coins, purchases, levels)
                            
                    elif levels[6].getCompleted():
                        levelEight(coins, purchases, levels)
                    elif levels[5].getCompleted():
                        if levels[8].isCompleted():
                            bonusTwoScreens(coins, purchases, levels)
                        else:
                            bonusOneScreens(coins, purchases, levels)
                    elif levels[4].getCompleted():
                        levelSix(coins, purchases, levels)
                    elif levels[3].getCompleted():
                        levelFive(coins, purchases, levels)
                    elif levels[2].getCompleted():
                        levelFour(coins, purchases, levels)
                    elif levels[1].getCompleted():
                        bonusOneScreens(coins, purchases, levels)
                    elif levels[0].getCompleted():
                        levelTwo(coins, purchases, levels)
                    else:
                        levelOne(coins, purchases, levels)
                
                #retry button retries the level the user was on
                if 315 <= mousex <= 458 and 566 <= mousey <= 694:
                    if level == 1:
                        levelOne(coins, purchases, levels)
                    elif level == 2:
                        levelTwo(coins, purchases, levels)
                    elif level == 3:
                        levelThree(coins, purchases, levels)
                    elif level == 4:
                        levelFour(coins, purchases, levels)
                    elif level == 5:
                        levelFive(coins, purchases, levels)
                    elif level == 6:
                        levelSix(coins, purchases, levels)
                    elif level == 7:
                        levelSeven(coins, purchases, levels)
                    elif level == 8:
                        levelEight(coins, purchases, levels)
                    elif level == 10:
                        bonusTwo(coins, purchases, levels)


                if 511 <= mousex <= 632 and 575 <= mousey <= 685:
                    main(coins, purchases, levels)
        pygame.display.update()

#Our shop screen
def shopScreen(coins, purchases, levels):
    pygame.init()
    background = pygame.image.load("actualbackground.png")
   
    # set up the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #Variables for our button pictures and placements coords
    knight = pygame.image.load('medieval_thumbnail.png')
    knightx = 150
    knighty = 0
    wizard = pygame.image.load('magical_thumbnail.png')
    wizx = 450
    wizy = 0
    basketball = pygame.image.load('basketball_shop_thumbnail.png')
    ballx = 150
    bally = 300
    spidey = pygame.image.load('spidey_shop_thumbnail.png')
    spideyx = 450
    spideyy = 300
    if levels[9].getCompleted() == False:
        bonus = pygame.image.load('mystery_thumbnail.png')
    else:
        bonus = pygame.image.load('donkey_kong_thumbnail.png')
    bonusx = 315
    bonusy = 550
    bonusEarnedx = 215
    bonusEarnedy = 600
    oneCoin = pygame.image.load('1coins.png')
    one1x = 75
    one2x = 375
    oney = 50
    twoCoin = pygame.image.load('2coins.png')
    two1x = 75
    two2x = 375
    twoy = 350
    purchased = pygame.image.load('purchased.png')
    homeButton = pygame.image.load('home_button.png')
    homex = -200
    homey = 500
    nextButton = pygame.image.load('play_button.png')
    nextx = 350
    nexty = 500
    selected = pygame.image.load('selected.png')
    mouseClicked = False
    
    

    # Display Loop
    while True:
        #displaying various images from the variables above
        DISPLAYSURF.fill((0, 0, 150))
        DISPLAYSURF.blit(background, (0,0))
        DISPLAYSURF.blit(homeButton, (homex, homey))
        DISPLAYSURF.blit(knight, (knightx, knighty))
        DISPLAYSURF.blit(wizard, (wizx, wizy))
        DISPLAYSURF.blit(basketball, (ballx, bally))
        DISPLAYSURF.blit(spidey, (spideyx, spideyy))
        DISPLAYSURF.blit(nextButton, (nextx, nexty))
        DISPLAYSURF.blit(bonus, (bonusx, bonusy))
        
        

        for event in pygame.event.get(): #quits pygame when python is exited
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function (subtracts coins from user if the user has enough coins to buy the item  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 121 <= mousex <= 332 and 140 <= mousey <= 205:
                    if coins >= 1 and purchases.getPos1() == 0:
                        purchases.setPos1(1)
                        coins -= 1
                    elif purchases.getPos1() == 1:
                        if purchases.getPos2() == 2:
                           purchases.setPos2(1)
                        if purchases.getPos3() == 2:
                            purchases.setPos3(1)
                        if purchases.getPos4() == 2:
                            purchases.setPos4(1)
                        if purchases.getBonus() == 2:
                            purchases.setBonus(1)
                        purchases.setPos1(2)
                    else:
                        for i in range(0, 25):
                            pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (650, 0, 150, 50))
                            text = font.render(str(coins), True, (255,0,0), (0,200,255))
                            DISPLAYSURF.blit(text, (710, 10, 150, 25))
                            pygame.display.update()
                       
                if 423 <= mousex <= 630 and 141 <= mousey <= 208:
                    if coins >= 1 and purchases.getPos2() == 0:
                        purchases.setPos2(1)
                        coins -= 1
                    elif purchases.getPos2() == 1:
                        if purchases.getPos1() == 2:
                           purchases.setPos1(1)
                        if purchases.getPos3() == 2:
                            purchases.setPos3(1)
                        if purchases.getPos4() == 2:
                            purchases.setPos4(1)
                        if purchases.getBonus() == 2:
                            purchases.setBonus(1)
                        purchases.setPos2(2)
                    else:
                        for i in range(0, 25):
                            pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (650, 0, 150, 50))
                            text = font.render(str(coins), True, (255,0,0), (0,200,255))
                            DISPLAYSURF.blit(text, (710, 10, 150, 25))
                            pygame.display.update()
                if 119 <= mousex <= 331 and 442 <= mousey <= 508:
                    if coins >= 2 and purchases.getPos3() == 0:
                        purchases.setPos3(1)
                        coins -= 2
                    elif purchases.getPos3() == 1:
                        if purchases.getPos1() == 2:
                           purchases.setPos1(1)
                        if purchases.getPos2() == 2:
                            purchases.setPos2(1)
                        if purchases.getPos4() == 2:
                            purchases.setPos4(1)
                        if purchases.getBonus() == 2:
                            purchases.setBonus(1)
                        purchases.setPos3(2)
                    else:
                        for i in range(0, 25):
                            pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (650, 0, 150, 50))
                            text = font.render(str(coins), True, (255,0,0), (0,200,255))
                            DISPLAYSURF.blit(text, (710, 10, 150, 25))
                            pygame.display.update()
                if 425 <= mousex <= 635 and 438 <= mousey <= 511:
                    if coins >= 1 and purchases.getPos4() == 0:
                        purchases.setPos4(1)
                        coins -= 2
                    elif purchases.getPos4() == 1:
                        if purchases.getPos1() == 2:
                           purchases.setPos1(1)
                        if purchases.getPos2() == 2:
                            purchases.setPos2(1)
                        if purchases.getPos3() == 2:
                            purchases.setPos3(1)
                        if purchases.getBonus() == 2:
                            purchases.setBonus(1)
                        purchases.setPos4(2)
                    else:
                        for i in range(0, 25):
                            pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (650, 0, 150, 50))
                            text = font.render(str(coins), True, (255,0,0), (0,200,255))
                            DISPLAYSURF.blit(text, (710, 10, 150, 25))
                            pygame.display.update()
                if 266 <= mousex <= 468 and 694 <= mousey <= 754:
                    if purchases.getBonus() == 1:
                        if purchases.getPos1() == 2:
                           purchases.setPos1(1)
                        if purchases.getPos2() == 2:
                            purchases.setPos2(1)
                        if purchases.getPos3() == 2:
                            purchases.setPos3(1)
                        if purchases.getPos4() == 2:
                            purchases.setPos4(1)
                        purchases.setBonus(2)
                if 34 <= mousex <= 157 and 656 <= mousey <= 767: 
                    main(coins, purchases, levels)
                if 588 <= mousex <= 707 and 656 <= mousey <= 767: 
                    powerups(coins, purchases, levels)
                    
        #shows amount of coins in top right                    
        font = pygame.font.Font('freesansbold.ttf', 32)
        text = font.render(str(coins), True, (125,255,255), (0,200,255))
        pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (650, 0, 150, 50))
        DISPLAYSURF.blit(text, (710, 10, 150, 25))
        
        #changes display of button to purchased if the item is purchased
        if purchases.getPos1() == 0:
            DISPLAYSURF.blit(oneCoin, (one1x, oney))
        elif purchases.getPos1() == 1:
            DISPLAYSURF.blit(purchased, (one1x, oney))
        else:
            DISPLAYSURF.blit(selected, (one1x, oney))
        
        if purchases.getPos2() == 0:
            DISPLAYSURF.blit(oneCoin, (one2x, oney))
        elif purchases.getPos2() == 1:
            DISPLAYSURF.blit(purchased, (one2x, oney))
        else:
            DISPLAYSURF.blit(selected, (one2x, oney))
        
        if purchases.getPos3() == 0:
            DISPLAYSURF.blit(twoCoin, (two1x, twoy))
        elif purchases.getPos3() == 1:
            DISPLAYSURF.blit(purchased, (two1x, twoy))
        else:
            DISPLAYSURF.blit(selected, (two1x, twoy))
        
        if purchases.getPos4() == 0:
            DISPLAYSURF.blit(twoCoin, (two2x, twoy))
        elif purchases.getPos4() == 1:
            DISPLAYSURF.blit(purchased, (two2x, twoy))
        else:
            DISPLAYSURF.blit(selected, (two2x, twoy))
        
        if purchases.getBonus() == 1:
            DISPLAYSURF.blit(purchased, (bonusEarnedx, bonusEarnedy))
        elif purchases.getBonus() == 2:
            DISPLAYSURF.blit(selected, (bonusEarnedx, bonusEarnedy))
        
        
        pygame.display.update()
        
def powerups(coins, purchases, levels): #talk breifly about this is power up shop code
    pygame.init()
    
    background = pygame.image.load("actualbackground.png") #background png
    thumbnail = pygame.image.load("character_mover_thumbnail.png") #character mover thumbnail
   
    # set up the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32) #display surface of the screen
    pygame.display.set_caption("Where's My Money") #window caption
    
    #Variables for our button pictures and placements
    oneCoin = pygame.image.load('1coins.png') #one coin img
    #one coin coords
    one1x = 75
    oney = 125
    twoCoin = pygame.image.load('2coins.png') #two coin img
    #two coin coords
    two1x = 75
    twoy = 375
    nextButton = pygame.image.load('playbuttonreversed.png') #next button img
    #next button coords
    nextx = -200
    nexty = 500
    purchased = pygame.image.load('purchased.png') #purchased img
    homeButton = pygame.image.load('home_button.png') #homebutton img
    #home coords
    homex = 350
    homey = 500
    selected = pygame.image.load('selected.png') #selected img
    rect1 = pygame.image.load('multiplierempty.png') #progress bar empty img
    rect2 = pygame.image.load('multiplierfill.png') #progress bar full img
    m = pygame.image.load('1x.png') #multiplier icon
    
    
    

    # Display Loop
    while True:
        multiplier = purchases.getMulti() #the actual multiplier the user owns
        DISPLAYSURF.fill((0, 0, 150)) #surface of screen
        DISPLAYSURF.blit(background, (0,0)) #background
        DISPLAYSURF.blit(thumbnail, (162,321)) #thumbnail load
        DISPLAYSURF.blit(nextButton, (nextx, nexty)) #nextbutton load
        DISPLAYSURF.blit(homeButton, (homex, homey)) #home button load
        
        
        if multiplier < 3: #sets the buy icon to one coin since it can still be bought
            DISPLAYSURF.blit(oneCoin, (one1x, oney))
        else:
            DISPLAYSURF.blit(purchased, (one1x, oney))
        DISPLAYSURF.blit(twoCoin, (two1x, twoy)) #displaying two coin
        font = pygame.font.Font('freesansbold.ttf', 32) #font of inventory number
        text = font.render(str(purchases.getUses()), True, (125,255,255)) #text representation of inventory number
        pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (two1x + 295, twoy + 110, 30, 30)) #background rectangle of that number
        DISPLAYSURF.blit(text, (two1x + 300, twoy + 110)) #loading text
        
        DISPLAYSURF.blit(m, (75, 90)) #displaying the icon
        
        #sets the icon based on if the tnext tier is bought and the previous one was bought
        if multiplier == 0:
            DISPLAYSURF.blit(rect1, (200, 100))
        else:
            DISPLAYSURF.blit(rect2, (200, 100))
        if multiplier == 1:
            DISPLAYSURF.blit(rect1, (250, 100))
        else:
            DISPLAYSURF.blit(rect2, (250, 100))
            m = pygame.image.load('2x.png')
        if multiplier < 3:
            DISPLAYSURF.blit(rect1, (300, 100))
        elif multiplier == 3:
            DISPLAYSURF.blit(rect2, (300, 100))
            m = pygame.image.load('3x.png')
            
        
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                mousex, mousey = event.pos
                print(mousex, mousey)
                if 127 <= mousex <= 321 and 216 <= mousey <= 276: #buying multiplier tier 2
                    if multiplier == 1 and coins >= 1:
                        purchases.shopMulti(2)
                        for i in range(len(levels)):
                            Level.multiplier(levels[i], purchases)
                        coins -= 1
                    if multiplier == 2 and coins >= 1: #buying multiplier tier 3
                        purchases.shopMulti(3)
                        for i in range(len(levels)):
                            Level.multiplier(levels[i], purchases)
                        coins -= 1
                if 125 <= mousex <= 321 and 321 <= mousey <= 526: #buying character mover
                    if coins >= 2:
                        purchases.characterMover()
                        coins -= 2
                        
                if 588 <= mousex <= 706 and 661 <= mousey <= 768: #back to main button
                    main(coins, purchases, levels)
                if 40 <= mousex <= 154 and 661 <= mousey <= 768: #back to shop screen button
                    shopScreen(coins, purchases, levels)
                            
        font = pygame.font.Font('freesansbold.ttf', 32)
        text = font.render(str(coins), True, (125,255,255), (0,200,255))
        pygame.draw.rect(DISPLAYSURF, (100, 200, 255), (650, 0, 150, 50))
        DISPLAYSURF.blit(text, (710, 10, 150, 25))
        
        pygame.display.update()

def bonusOneScreens(coins, purchases, levels):
    pygame.init()

    # set up the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #If the first bonus level has not been completed
    if levels[8].getCompleted():
        #Sets the background to the completed bonus level one screen
        background = pygame.image.load("announcement_screen_1.png")
    #If it is is completed
    else:
        #Sets the background to the pre bonus level one screen
        background = pygame.image.load("bonus_pre_screen.png")
    
    while True: 
        #Displays the background image
        DISPLAYSURF.blit(background, (0, 0))
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                #Gets the x and y coordinates of where the mouse was clicked
                mousex, mousey = event.pos
                #If bonus level one is completed
                if levels[8].getCompleted():
                    #if the home button is pressed
                    if 75 <= mousex <= 194 and 860 <= mousey <= 960:
                        main(coins, purchases, levels)
                    #If the shop button is pressed
                    if 276 <= mousex <= 480 and 880 <= mousey <= 940:
                        shopScreen(coins, purchases, levels)
                    #If the next level button is pressed
                    if 550 <= mousex <= 670 and 860 <= mousey <= 960:
                        #If level 6 was completed you go directly to bonus level two
                        if levels[5].getCompleted():
                            bonusTwoScreens(coins, purchases, levels)
                        else:
                            levelThree(coins, purchases, levels)
                else:
                    #If the play button is pressed call the bonusOne function
                    if 305 <= mousex <= 430 and 860 <= mousey <= 960:
                      bonusOne(coins, purchases, levels)
                      
        pygame.display.update()
    
    
    
def bonusTwoScreens(coins, purchases, levels):
    pygame.init()

    # set up the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #if the second bonus level has been completed
    if levels[9].getCompleted():
        background = pygame.image.load("announcement_screen_2.png")
    #if the second bonus level has not been completed 
    else:
        background = pygame.image.load("bonus_pre_screen2.png")
    
    while True: 
        #Displaying the background
        DISPLAYSURF.blit(background, (0, 0))
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                mousex, mousey = event.pos
                print(mousex, mousey)
                #If the first bonus level has been completed
                if levels[8].isCompleted():
                    #if the second bonus level has been completed
                    if levels[9].getCompleted():
                        purchases.setBonus(1)
                        #if the home button is pressed
                        if 75 <= mousex <= 194 and 860 <= mousey <= 960:
                            main(coins, purchases, levels)
                        #If the shop button is pressed
                        if 276 <= mousex <= 480 and 880 <= mousey <= 940:
                            shopScreen(coins, purchases, levels)
                        #If the next level button is pressed
                        if 550 <= mousex <= 670 and 860 <= mousey <= 960:
                            #if the eighth level has been completed call endGameScreen
                            if levels[7].getCompleted():
                                endGameScreen(coins, purchases, levels)
                            #If the 7th level had been completed call levelEight
                            elif levels[6].getCompleted():
                                levelEight(coins, purchases, levels)
                            #otherwise call levelSeven
                            else:
                                levelSeven(coins, purchases, levels)
                    #Otherwuse call bonusTwo
                    else:
                        bonusTwo(coins, purchases, levels)
                #If the first bonus level has not yet been completed call that
                else:
                    if 305 <= mousex <= 430 and 860 <= mousey <= 960:
                        bonusOne(coins, purchases, levels)
        pygame.display.update()

def endGameScreen(coins, purchases, levels):
    #Creating the window
    DISPLAYSURF = pygame.display.set_mode((750, 1000), 0, 32)
    pygame.display.set_caption("Where's My Money")
    
    #setting the background 
    background = pygame.image.load("end_game_screen.png")
    
    while True: 
        #displaying the background
        DISPLAYSURF.blit(background, (0, 0))
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            #Gets the location of where the mouse was clicked, and depending on that it will call a different function  
            if event.type == pygame.MOUSEBUTTONDOWN:   
                mousex, mousey = event.pos
                #If the home button was pressed call main
                if 300 <= mousex <= 440 and 860 <= mousey <= 970:
                    main(coins, purchases, levels)
        pygame.display.update()
if __name__ == "__main__":
    levels = [Level(1), Level(1), Level(2), Level(2), Level(2), Level(2), Level(2), Level(2), Level(2), Level(3)] #levels list
    purchases = Shop() #shop object
    main(10, purchases, levels)  #run game


